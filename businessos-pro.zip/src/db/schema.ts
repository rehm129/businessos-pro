/**
 * BusinessOS Pro - Database Schema & DDL Definitions
 * SQLite-compatible standard SQL with foreign keys, constraints, and indexes.
 */

export const CURRENT_SCHEMA_VERSION = 1;

export const INITIAL_SCHEMA_SQL = `
-- Enforce foreign key constraints
PRAGMA foreign_keys = ON;

-- 1. Schema Migrations table
CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL
);

-- 2. Business Profile Settings
CREATE TABLE IF NOT EXISTS business_profile (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  legal_name TEXT,
  tagline TEXT,
  business_type TEXT NOT NULL DEFAULT 'general_store',
  phone TEXT NOT NULL,
  email TEXT NOT NULL,
  address TEXT NOT NULL,
  currency_code TEXT NOT NULL DEFAULT 'USD',
  currency_symbol TEXT NOT NULL DEFAULT '$',
  tax_rate_percent REAL NOT NULL DEFAULT 0.0,
  tax_number TEXT,
  enable_tax INTEGER NOT NULL DEFAULT 1,
  receipt_footer_message TEXT NOT NULL DEFAULT 'Thank you for your business! Please visit again.',
  allow_negative_stock INTEGER NOT NULL DEFAULT 0,
  enable_split_payments INTEGER NOT NULL DEFAULT 1,
  barcode_scanner_prefix TEXT DEFAULT '',
  low_stock_threshold_default INTEGER NOT NULL DEFAULT 5,
  updated_at TEXT NOT NULL
);

-- 3. Users and Authentication (PBKDF2 salted hash, zero plaintext)
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin', 'manager', 'cashier')),
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  last_login TEXT
);

-- 4. Categories
CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  description TEXT,
  color TEXT DEFAULT '#3b82f6'
);

-- 5. Products & Inventory
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  sku TEXT UNIQUE NOT NULL,
  barcode TEXT UNIQUE NOT NULL,
  category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
  unit TEXT NOT NULL DEFAULT 'pcs',
  purchase_cost REAL NOT NULL CHECK(purchase_cost >= 0),
  selling_price REAL NOT NULL CHECK(selling_price >= 0),
  current_stock REAL NOT NULL DEFAULT 0,
  min_stock_threshold REAL NOT NULL DEFAULT 5,
  is_archived INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_products_sku ON products(sku);
CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_archived ON products(is_archived);

-- 6. Stock Movement Audit Trail
CREATE TABLE IF NOT EXISTS stock_movements (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  movement_type TEXT NOT NULL,
  quantity_change REAL NOT NULL,
  stock_after REAL NOT NULL,
  unit_cost REAL NOT NULL DEFAULT 0,
  reference_id TEXT,
  notes TEXT,
  created_by_name TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_stock_movements_product ON stock_movements(product_id);
CREATE INDEX IF NOT EXISTS idx_stock_movements_type ON stock_movements(movement_type);
CREATE INDEX IF NOT EXISTS idx_stock_movements_created ON stock_movements(created_at);

-- 7. Customers
CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  address TEXT,
  credit_limit REAL NOT NULL DEFAULT 0,
  current_balance REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);

-- 8. Customer Payments & Account Ledger
CREATE TABLE IF NOT EXISTS customer_payments (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
  amount REAL NOT NULL CHECK(amount > 0),
  payment_method TEXT NOT NULL,
  reference_number TEXT,
  notes TEXT,
  received_by TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_customer_payments_cust ON customer_payments(customer_id);

-- 9. Sales (Transaction-safe)
CREATE TABLE IF NOT EXISTS sales (
  id TEXT PRIMARY KEY,
  receipt_number TEXT UNIQUE NOT NULL,
  customer_id TEXT REFERENCES customers(id) ON DELETE SET NULL,
  subtotal REAL NOT NULL,
  discount_total REAL NOT NULL DEFAULT 0,
  tax_total REAL NOT NULL DEFAULT 0,
  grand_total REAL NOT NULL,
  cost_total REAL NOT NULL,
  estimated_profit REAL NOT NULL,
  payment_method TEXT NOT NULL,
  payment_details TEXT,
  amount_paid REAL NOT NULL,
  change_given REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'completed' CHECK(status IN ('completed', 'refunded', 'partially_refunded', 'cancelled')),
  cashier_id TEXT NOT NULL REFERENCES users(id),
  cashier_name TEXT NOT NULL,
  notes TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sales_receipt ON sales(receipt_number);
CREATE INDEX IF NOT EXISTS idx_sales_created ON sales(created_at);
CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales(customer_id);

-- 10. Sale Line Items
CREATE TABLE IF NOT EXISTS sale_items (
  id TEXT PRIMARY KEY,
  sale_id TEXT NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  product_name TEXT NOT NULL,
  sku TEXT NOT NULL,
  quantity REAL NOT NULL CHECK(quantity > 0),
  unit_cost REAL NOT NULL,
  unit_price REAL NOT NULL,
  discount_percent REAL NOT NULL DEFAULT 0,
  discount_amount REAL NOT NULL DEFAULT 0,
  tax_amount REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id);
CREATE INDEX IF NOT EXISTS idx_sale_items_product ON sale_items(product_id);

-- 11. Sales Returns / Refunds
CREATE TABLE IF NOT EXISTS sale_returns (
  id TEXT PRIMARY KEY,
  sale_id TEXT NOT NULL REFERENCES sales(id) ON DELETE RESTRICT,
  receipt_number TEXT NOT NULL,
  refund_total REAL NOT NULL,
  restock_items INTEGER NOT NULL DEFAULT 1,
  reason TEXT NOT NULL,
  processed_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  items_json TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_returns_sale ON sale_returns(sale_id);

-- 12. Suppliers
CREATE TABLE IF NOT EXISTS suppliers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  contact_person TEXT,
  email TEXT,
  phone TEXT NOT NULL,
  address TEXT,
  tax_id TEXT,
  total_purchased REAL NOT NULL DEFAULT 0,
  outstanding_balance REAL NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

-- 13. Purchases / Receiving Stock
CREATE TABLE IF NOT EXISTS purchases (
  id TEXT PRIMARY KEY,
  purchase_number TEXT UNIQUE NOT NULL,
  supplier_id TEXT NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  order_date TEXT NOT NULL,
  received_date TEXT,
  status TEXT NOT NULL CHECK(status IN ('ordered', 'received', 'partially_received', 'cancelled')),
  subtotal REAL NOT NULL,
  tax_total REAL NOT NULL DEFAULT 0,
  grand_total REAL NOT NULL,
  amount_paid REAL NOT NULL DEFAULT 0,
  payment_status TEXT NOT NULL DEFAULT 'paid' CHECK(payment_status IN ('paid', 'partial', 'unpaid')),
  notes TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_purchases_number ON purchases(purchase_number);
CREATE INDEX IF NOT EXISTS idx_purchases_supplier ON purchases(supplier_id);

-- 14. Purchase Items
CREATE TABLE IF NOT EXISTS purchase_items (
  id TEXT PRIMARY KEY,
  purchase_id TEXT NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  product_name TEXT NOT NULL,
  sku TEXT NOT NULL,
  quantity REAL NOT NULL CHECK(quantity > 0),
  unit_cost REAL NOT NULL,
  total_cost REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_purchase_items_purchase ON purchase_items(purchase_id);

-- 15. Expense Categories & Expenses
CREATE TABLE IF NOT EXISTS expense_categories (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS expenses (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL REFERENCES expense_categories(id) ON DELETE RESTRICT,
  amount REAL NOT NULL CHECK(amount > 0),
  payment_method TEXT NOT NULL,
  description TEXT NOT NULL,
  paid_to TEXT,
  recorded_by TEXT NOT NULL,
  receipt_url TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(category_id);
CREATE INDEX IF NOT EXISTS idx_expenses_created ON expenses(created_at);

-- 16. Daily Cash Register Reconciliation
CREATE TABLE IF NOT EXISTS cash_reconciliations (
  id TEXT PRIMARY KEY,
  date TEXT UNIQUE NOT NULL,
  opening_float REAL NOT NULL DEFAULT 0,
  cash_sales_total REAL NOT NULL DEFAULT 0,
  cash_payments_received_total REAL NOT NULL DEFAULT 0,
  cash_expenses_total REAL NOT NULL DEFAULT 0,
  expected_cash_total REAL NOT NULL,
  actual_counted_cash REAL NOT NULL,
  variance REAL NOT NULL,
  reconciled_by TEXT NOT NULL,
  notes TEXT,
  created_at TEXT NOT NULL
);

-- 17. Security & Audit Trail
CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  details TEXT NOT NULL,
  user_id TEXT NOT NULL,
  user_name TEXT NOT NULL,
  timestamp TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id);

-- 18. Commercial Licensing Storage
CREATE TABLE IF NOT EXISTS license_storage (
  machine_id TEXT PRIMARY KEY,
  license_key TEXT,
  licensed_to TEXT,
  status TEXT NOT NULL DEFAULT 'trial',
  plan_type TEXT NOT NULL DEFAULT 'Business Pro Single',
  valid_until TEXT NOT NULL,
  features_json TEXT NOT NULL
);

-- Mark migration 1 as applied
INSERT OR IGNORE INTO schema_migrations (version, applied_at)
VALUES (1, datetime('now'));
`;
