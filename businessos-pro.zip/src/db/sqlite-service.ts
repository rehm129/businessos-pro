import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import { INITIAL_SCHEMA_SQL } from './schema';
import { generateSalt, hashPassword } from '../utils/crypto';
import { DatabaseBackupMeta } from '../types';

const DB_STORAGE_KEY = 'businessos_pro_sqlite_db';
const BACKUPS_STORAGE_KEY = 'businessos_pro_backups_list';

class SqliteService {
  private SQL: SqlJsStatic | null = null;
  private db: Database | null = null;
  private isInitialized = false;
  private isSaving = false;

  public async init(): Promise<void> {
    if (this.isInitialized && this.db) {
      return;
    }

    try {
      const initFn = typeof initSqlJs === 'function' ? initSqlJs : (initSqlJs as any)?.default;
      if (typeof initFn !== 'function') {
        throw new Error('SQLite library initialization function could not be loaded.');
      }

      try {
        this.SQL = await initFn({
          locateFile: (file: string) => {
            if (typeof window !== 'undefined') {
              return `/${file}`;
            }
            return `node_modules/sql.js/dist/${file}`;
          },
        });
      } catch (localWasmErr) {
        console.warn('Local wasm load failed, trying CDN fallback:', localWasmErr);
        this.SQL = await initFn({
          locateFile: (file: string) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.12.0/${file}`,
        });
      }

      // Attempt to load existing database binary from storage
      const existingData = await this.loadFromStorage();
      if (existingData && existingData.byteLength > 0) {
        try {
          this.db = new this.SQL.Database(existingData);
          this.db.run('PRAGMA foreign_keys = ON;');
        } catch (err) {
          console.warn('Could not load existing DB file, starting fresh:', err);
          this.db = new this.SQL.Database();
        }
      } else {
        this.db = new this.SQL.Database();
      }

      this.db.run(INITIAL_SCHEMA_SQL);
      await this.ensureSeedData();
      await this.saveToStorage();

      this.isInitialized = true;
    } catch (err) {
      console.error('Failed to initialize SQLite service:', err);
      throw err;
    }
  }

  public async resetDatabase(): Promise<void> {
    if (typeof window !== 'undefined') {
      try {
        localStorage.removeItem(DB_STORAGE_KEY);
        const db = await this.openIdb();
        const tx = db.transaction('keyvalue', 'readwrite');
        tx.objectStore('keyvalue').delete(DB_STORAGE_KEY);
      } catch (err) {
        console.warn('Reset error:', err);
      }
    }
    this.db = null;
    this.isInitialized = false;
    await this.init();
  }

  public getRawDb(): Database {
    if (!this.db) {
      throw new Error('Database is not initialized. Call init() first.');
    }
    return this.db;
  }

  /**
   * Execute an INSERT, UPDATE, DELETE or DDL statement with parameters
   */
  public run(sql: string, params: any[] = []): void {
    const db = this.getRawDb();
    db.run(sql, params);
    this.scheduleSave();
  }

  /**
   * Execute a SELECT query and return array of objects
   */
  public query<T = any>(sql: string, params: any[] = []): T[] {
    const db = this.getRawDb();
    const stmt = db.prepare(sql);
    try {
      stmt.bind(params);
      const results: T[] = [];
      while (stmt.step()) {
        results.push(stmt.getAsObject() as unknown as T);
      }
      return results;
    } finally {
      stmt.free();
    }
  }

  /**
   * Execute a SELECT query returning single row or null
   */
  public queryOne<T = any>(sql: string, params: any[] = []): T | null {
    const rows = this.query<T>(sql, params);
    return rows.length > 0 ? rows[0] : null;
  }

  /**
   * Execute transaction block safely with BEGIN and COMMIT/ROLLBACK
   */
  public transaction<T>(callback: () => T): T {
    const db = this.getRawDb();
    db.run('BEGIN TRANSACTION;');
    try {
      const result = callback();
      db.run('COMMIT;');
      this.scheduleSave();
      return result;
    } catch (error) {
      try {
        db.run('ROLLBACK;');
      } catch (rollbackErr) {
        console.error('Error during transaction rollback:', rollbackErr);
      }
      throw error;
    }
  }

  /**
   * Export the entire database as a standard SQLite 3 binary byte array
   */
  public exportBinary(): Uint8Array {
    const db = this.getRawDb();
    return db.export();
  }

  /**
   * Validate SQLite binary header (first 16 bytes: "SQLite format 3\0")
   */
  public validateSqliteHeader(bytes: Uint8Array): boolean {
    if (bytes.byteLength < 100) return false;
    const headerStr = new TextDecoder().decode(bytes.slice(0, 16));
    return headerStr.startsWith('SQLite format 3');
  }

  /**
   * Check integrity of the database using PRAGMA integrity_check
   */
  public checkIntegrity(): { ok: boolean; rows: string[] } {
    try {
      const rows = this.query<{ integrity_check: string }>('PRAGMA integrity_check;');
      const checks = rows.map((r) => r.integrity_check);
      const ok = checks.length === 1 && checks[0].toLowerCase() === 'ok';
      return { ok, rows: checks };
    } catch (err: any) {
      return { ok: false, rows: [err.message || 'Integrity check failed'] };
    }
  }

  /**
   * Create a timestamped safety backup in local storage
   */
  public async createSafetyBackup(
    reason: 'manual' | 'pre_restore_safety' | 'migration' | 'daily_auto' = 'manual'
  ): Promise<DatabaseBackupMeta> {
    const binary = this.exportBinary();
    const backupId = 'backup_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const nowIso = new Date().toISOString();
    const dateFormatted = nowIso.replace(/[:.]/g, '-');
    const filename = `businessos_backup_${reason}_${dateFormatted}.sqlite`;

    // Calculate record counts for auditing
    const productsCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM products')?.c ?? 0;
    const salesCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM sales')?.c ?? 0;
    const customersCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM customers')?.c ?? 0;
    const suppliersCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM suppliers')?.c ?? 0;
    const purchasesCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM purchases')?.c ?? 0;
    const expensesCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM expenses')?.c ?? 0;

    const meta: DatabaseBackupMeta = {
      backupId,
      filename,
      createdAt: nowIso,
      fileSizeBytes: binary.byteLength,
      reason,
      recordCounts: {
        products: productsCount,
        sales: salesCount,
        customers: customersCount,
        suppliers: suppliersCount,
        purchases: purchasesCount,
        expenses: expensesCount,
      },
    };

    // Store binary in indexedDB / local storage
    await this.saveBackupBinary(backupId, binary);

    // Save meta
    const existingList = this.getSafetyBackups();
    existingList.unshift(meta);
    if (typeof window !== 'undefined') {
      localStorage.setItem(BACKUPS_STORAGE_KEY, JSON.stringify(existingList.slice(0, 20))); // Keep last 20
    }

    return meta;
  }

  public getSafetyBackups(): DatabaseBackupMeta[] {
    if (typeof window === 'undefined') return [];
    try {
      const stored = localStorage.getItem(BACKUPS_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  /**
   * Restore database from raw SQLite binary with safety backup guarantee
   */
  public async importBinaryWithSafety(newBinary: Uint8Array): Promise<void> {
    if (!this.validateSqliteHeader(newBinary)) {
      throw new Error('Invalid SQLite file header. File does not appear to be a valid SQLite 3 database.');
    }

    // Step 1: Create automated pre-restore safety backup
    await this.createSafetyBackup('pre_restore_safety');

    // Step 2: Open and test integrity of the new binary
    if (!this.SQL) {
      throw new Error('SQL engine is not ready.');
    }

    const testDb = new this.SQL.Database(newBinary);
    const integrity = testDb.exec('PRAGMA integrity_check;');
    const integrityOk =
      integrity.length > 0 &&
      integrity[0].values &&
      integrity[0].values[0] &&
      String(integrity[0].values[0][0]).toLowerCase() === 'ok';

    if (!integrityOk) {
      testDb.close();
      throw new Error('Safety verification failed: Provided SQLite database failed integrity check.');
    }

    // Verify critical tables exist in the restored database
    const tables = testDb.exec("SELECT name FROM sqlite_master WHERE type='table';");
    const tableNames = tables[0]?.values?.map((v) => v[0]) ?? [];
    if (!tableNames.includes('products') || !tableNames.includes('sales')) {
      testDb.close();
      throw new Error('Restored database is missing required BusinessOS Pro tables (products/sales).');
    }

    // Step 3: Switch to the newly verified database
    if (this.db) {
      this.db.close();
    }
    this.db = testDb;
    this.db.run('PRAGMA foreign_keys = ON;');

    await this.saveToStorage();
  }

  /**
   * Restore directly from one of the internal safety backups
   */
  public async restoreFromBackupId(backupId: string): Promise<void> {
    const binary = await this.loadBackupBinary(backupId);
    if (!binary) {
      throw new Error(`Backup with ID ${backupId} could not be found.`);
    }
    await this.importBinaryWithSafety(binary);
  }

  // --- Storage Internals ---

  private scheduleSave(): void {
    if (this.isSaving) return;
    this.isSaving = true;
    setTimeout(async () => {
      try {
        await this.saveToStorage();
      } finally {
        this.isSaving = false;
      }
    }, 150);
  }

  private async saveToStorage(): Promise<void> {
    if (!this.db || typeof window === 'undefined') return;
    try {
      const binary = this.db.export();
      await this.setIndexedDb(DB_STORAGE_KEY, binary);
    } catch (err) {
      console.warn('Failed to save DB binary to IndexedDB:', err);
    }
  }

  private async loadFromStorage(): Promise<Uint8Array | null> {
    if (typeof window === 'undefined') return null;
    try {
      return await this.getIndexedDb(DB_STORAGE_KEY);
    } catch {
      return null;
    }
  }

  private async saveBackupBinary(backupId: string, data: Uint8Array): Promise<void> {
    if (typeof window === 'undefined') return;
    await this.setIndexedDb(`backup_data_${backupId}`, data);
  }

  public async loadBackupBinary(backupId: string): Promise<Uint8Array | null> {
    if (typeof window === 'undefined') return null;
    return await this.getIndexedDb(`backup_data_${backupId}`);
  }

  private openIdb(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open('BusinessOS_Pro_DB', 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('keyvalue')) {
          db.createObjectStore('keyvalue');
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  private async getIndexedDb(key: string): Promise<Uint8Array | null> {
    const db = await this.openIdb();
    return new Promise((resolve) => {
      const tx = db.transaction('keyvalue', 'readonly');
      const store = tx.objectStore('keyvalue');
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result instanceof Uint8Array ? req.result : null);
      req.onerror = () => resolve(null);
    });
  }

  private async setIndexedDb(key: string, value: Uint8Array): Promise<void> {
    const db = await this.openIdb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('keyvalue', 'readwrite');
      const store = tx.objectStore('keyvalue');
      const req = store.put(value, key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  /**
   * Seed initial store profile, default admin account, categories & starter items if empty
   */
  private async ensureSeedData(): Promise<void> {
    const db = this.getRawDb();

    // 1. Business Profile
    const profileCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM business_profile')?.c ?? 0;
    if (profileCount === 0) {
      db.run(
        `INSERT INTO business_profile (
          id, name, legal_name, tagline, business_type, phone, email, address,
          currency_code, currency_symbol, tax_rate_percent, tax_number, enable_tax,
          receipt_footer_message, allow_negative_stock, enable_split_payments,
          barcode_scanner_prefix, low_stock_threshold_default, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          'profile_default',
          'Metro Supermart & Tech Hub',
          'Metro Enterprise Global LLC',
          'Everything for your business & lifestyle',
          'supermarket',
          '+1 (555) 234-5678',
          'contact@metroos.internal',
          '742 Evergreen Terrace, Suite 100, Metro City',
          'USD',
          '$',
          8.5,
          'US-TAX-892401',
          1,
          'Thank you for shopping with us! Returns accepted within 14 days with original receipt.',
          0, // disallow negative stock by default for accuracy
          1,
          '',
          5,
          new Date().toISOString(),
        ]
      );
    }

    // 2. Default Users: Admin (admin / admin123) and Cashier (cashier / cashier123)
    const userCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM users')?.c ?? 0;
    if (userCount === 0) {
      const adminSalt = generateSalt();
      const adminHash = await hashPassword('admin123', adminSalt);
      db.run(
        `INSERT INTO users (id, username, display_name, password_hash, password_salt, role, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        ['usr_admin', 'admin', 'Administrator', adminHash, adminSalt, 'admin', 1, new Date().toISOString()]
      );

      const cashierSalt = generateSalt();
      const cashierHash = await hashPassword('cashier123', cashierSalt);
      db.run(
        `INSERT INTO users (id, username, display_name, password_hash, password_salt, role, is_active, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        ['usr_cashier', 'cashier', 'Alex Morgan', cashierHash, cashierSalt, 'cashier', 1, new Date().toISOString()]
      );
    }

    // 3. Default Categories
    const catCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM categories')?.c ?? 0;
    if (catCount === 0) {
      const defaultCats = [
        ['cat_grocery', 'Groceries & Foods', 'Daily packaged foods, snacks & beverages', '#10b981'],
        ['cat_electronics', 'Electronics & Mobiles', 'Smartphones, cables, accessories, tech gadgets', '#6366f1'],
        ['cat_apparel', 'Garments & Fashion', 'Shirts, denim, jackets, footwear', '#f59e0b'],
        ['cat_household', 'Household & Utilities', 'Cleaning, cookware, storage goods', '#06b6d4'],
      ];
      for (const cat of defaultCats) {
        db.run('INSERT INTO categories (id, name, description, color) VALUES (?, ?, ?, ?)', cat);
      }
    }

    // 4. Default Supplier
    const supplierCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM suppliers')?.c ?? 0;
    if (supplierCount === 0) {
      db.run(
        `INSERT INTO suppliers (id, name, contact_person, email, phone, address, tax_id, total_purchased, outstanding_balance, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          'sup_prime',
          'Apex Wholesale Distributors',
          'David Miller',
          'orders@apexwholesale.example',
          '+1 (555) 890-1234',
          '900 Industrial Parkway, Dist 4',
          'TAX-SUP-9912',
          1450.0,
          0.0,
          new Date().toISOString(),
        ]
      );
    }

    // 5. Default Customers
    const custCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM customers')?.c ?? 0;
    if (custCount === 0) {
      db.run(
        `INSERT INTO customers (id, name, phone, email, address, credit_limit, current_balance, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          'cust_walkin',
          'Walk-in Retail Customer',
          '000-000-0000',
          'walkin@internal.store',
          'Counter Sale',
          0,
          0,
          new Date().toISOString(),
        ]
      );
      db.run(
        `INSERT INTO customers (id, name, phone, email, address, credit_limit, current_balance, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          'cust_sarah',
          'Sarah Connor',
          '+1 (555) 432-8765',
          'sarah.c@sky.example',
          '14 Highland Ave, Apt 3B',
          500,
          0,
          new Date().toISOString(),
        ]
      );
    }

    // 6. Default Expense Categories
    const expCatCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM expense_categories')?.c ?? 0;
    if (expCatCount === 0) {
      const defaultExpCats = [
        ['exp_rent', 'Shop Rent & Utilities', 'Store lease, electricity, water & internet'],
        ['exp_wages', 'Staff Wages & Lunches', 'Daily staff stipends and wages'],
        ['exp_packaging', 'Packaging & Bags', 'Carry bags, receipt thermal paper rolls'],
        ['exp_maint', 'Repairs & Maintenance', 'POS hardware, shelf repairs, general store upkeep'],
      ];
      for (const exp of defaultExpCats) {
        db.run('INSERT INTO expense_categories (id, name, description) VALUES (?, ?, ?)', exp);
      }
    }

    // 7. Initial Products
    const prodCount = this.queryOne<{ c: number }>('SELECT count(*) as c FROM products')?.c ?? 0;
    if (prodCount === 0) {
      const now = new Date().toISOString();
      const productsData = [
        [
          'prod_organic_coffee',
          'Artisan Dark Roast Coffee 500g',
          'GRO-COF-01',
          '8901001001',
          'cat_grocery',
          'bag',
          8.5,
          14.99,
          42,
          10,
          now,
        ],
        [
          'prod_almond_milk',
          'Organic Almond Milk 1L',
          'GRO-MLK-02',
          '8901001002',
          'cat_grocery',
          'carton',
          2.1,
          4.49,
          18,
          6,
          now,
        ],
        [
          'prod_fast_charger',
          '65W GaN Fast Charger USB-C',
          'ELE-CHG-01',
          '8902002001',
          'cat_electronics',
          'pcs',
          16.0,
          32.5,
          25,
          5,
          now,
        ],
        [
          'prod_usbc_braided_cable',
          'Heavy Duty Braided USB-C Cable 2m',
          'ELE-CBL-02',
          '8902002002',
          'cat_electronics',
          'pcs',
          3.2,
          9.99,
          60,
          15,
          now,
        ],
        [
          'prod_cotton_tee',
          'Heavyweight Premium Cotton T-Shirt',
          'APP-TEE-01',
          '8903003001',
          'cat_apparel',
          'pcs',
          9.0,
          24.0,
          30,
          8,
          now,
        ],
        [
          'prod_denim_jacket',
          'Vintage Wash Denim Jacket (M/L)',
          'APP-JKT-02',
          '8903003002',
          'cat_apparel',
          'pcs',
          28.0,
          68.0,
          4, // low stock trigger
          6,
          now,
        ],
        [
          'prod_cleaning_kit',
          'All-in-One Electronics Screen Cleaning Kit',
          'HOU-CLN-01',
          '8904004001',
          'cat_household',
          'kit',
          4.5,
          11.99,
          35,
          5,
          now,
        ],
      ];

      for (const p of productsData) {
        db.run(
          `INSERT INTO products (
            id, name, sku, barcode, category_id, unit, purchase_cost, selling_price,
            current_stock, min_stock_threshold, is_archived, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`,
          [p[0], p[1], p[2], p[3], p[4], p[5], p[6], p[7], p[8], p[9], p[10], p[10]]
        );

        // Record opening stock movement
        db.run(
          `INSERT INTO stock_movements (
            id, product_id, movement_type, quantity_change, stock_after, unit_cost, reference_id, notes, created_by_name, created_at
          ) VALUES (?, ?, 'opening_stock', ?, ?, ?, 'INIT', 'Initial catalog inventory setup', 'System Admin', ?)`,
          ['sm_init_' + p[0], p[0], p[8], p[8], p[6], p[10]]
        );
      }
    }
  }
}

export const sqliteService = new SqliteService();
