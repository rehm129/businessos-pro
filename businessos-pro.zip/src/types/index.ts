export type BusinessType =
  | 'general_store'
  | 'supermarket'
  | 'clothing_apparel'
  | 'electronics_mobile'
  | 'wholesale_distributor'
  | 'small_retail'
  | 'service_business';

export interface BusinessProfile {
  id: string;
  name: string;
  legalName?: string;
  tagline?: string;
  businessType: BusinessType;
  phone: string;
  email: string;
  address: string;
  currencyCode: string;
  currencySymbol: string;
  taxRatePercent: number;
  taxNumber?: string;
  enableTax: boolean;
  receiptFooterMessage: string;
  allowNegativeStock: boolean;
  enableSplitPayments: boolean;
  barcodeScannerPrefix?: string;
  lowStockThresholdDefault: number;
  updatedAt: string;
}

export type UserRole = 'admin' | 'manager' | 'cashier';

export interface User {
  id: string;
  username: string;
  displayName: string;
  role: UserRole;
  isActive: boolean;
  createdAt: string;
  lastLogin?: string;
}

export interface UserWithPassword extends User {
  passwordHash: string;
  passwordSalt: string;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  color?: string;
  itemCount?: number;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode: string;
  categoryId: string;
  categoryName?: string;
  unit: string;
  purchaseCost: number;
  sellingPrice: number;
  currentStock: number;
  minStockThreshold: number;
  isArchived: boolean;
  createdAt: string;
  updatedAt: string;
}

export type StockMovementType =
  | 'opening_stock'
  | 'sale'
  | 'sale_return'
  | 'purchase'
  | 'purchase_return'
  | 'manual_adjustment'
  | 'damaged_loss';

export interface StockMovement {
  id: string;
  productId: string;
  productName?: string;
  productSku?: string;
  movementType: StockMovementType;
  quantityChange: number; // positive or negative
  stockAfter: number;
  unitCost: number;
  referenceId?: string; // saleId, purchaseId, or adjustment note
  notes?: string;
  createdByName: string;
  createdAt: string;
}

export type PaymentMethod = 'cash' | 'card' | 'bank_transfer' | 'store_credit' | 'split';

export interface SaleItem {
  id: string;
  saleId: string;
  productId: string;
  productName: string;
  sku: string;
  quantity: number;
  unitCost: number;
  unitPrice: number;
  discountPercent: number;
  discountAmount: number;
  taxAmount: number;
  total: number;
}

export type SaleStatus = 'completed' | 'refunded' | 'partially_refunded' | 'cancelled';

export interface SalePaymentSplit {
  method: PaymentMethod;
  amount: number;
  reference?: string;
}

export interface Sale {
  id: string;
  receiptNumber: string;
  customerId?: string;
  customerName?: string;
  subtotal: number;
  discountTotal: number;
  taxTotal: number;
  grandTotal: number;
  costTotal: number; // For exact profit calculation
  estimatedProfit: number; // grandTotal - taxTotal - costTotal
  paymentMethod: PaymentMethod;
  paymentDetails?: string; // JSON of SalePaymentSplit[]
  amountPaid: number;
  changeGiven: number;
  status: SaleStatus;
  cashierId: string;
  cashierName: string;
  notes?: string;
  items?: SaleItem[];
  createdAt: string;
}

export interface SaleReturn {
  id: string;
  saleId: string;
  receiptNumber: string;
  refundTotal: number;
  restockItems: boolean;
  reason: string;
  processedBy: string;
  createdAt: string;
  items: {
    productId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
    refundAmount: number;
  }[];
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson?: string;
  email?: string;
  phone: string;
  address?: string;
  taxId?: string;
  totalPurchased: number;
  outstandingBalance: number;
  createdAt: string;
}

export interface PurchaseItem {
  id: string;
  purchaseId: string;
  productId: string;
  productName: string;
  sku: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
}

export type PurchaseStatus = 'ordered' | 'received' | 'partially_received' | 'cancelled';

export interface Purchase {
  id: string;
  purchaseNumber: string;
  supplierId: string;
  supplierName: string;
  orderDate: string;
  receivedDate?: string;
  status: PurchaseStatus;
  subtotal: number;
  taxTotal: number;
  grandTotal: number;
  amountPaid: number;
  paymentStatus: 'paid' | 'partial' | 'unpaid';
  notes?: string;
  items?: PurchaseItem[];
  createdAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  creditLimit: number;
  currentBalance: number; // positive = customer owes store
  totalSalesCount: number;
  totalSpent: number;
  createdAt: string;
}

export interface CustomerPayment {
  id: string;
  customerId: string;
  customerName: string;
  amount: number;
  paymentMethod: PaymentMethod;
  referenceNumber?: string;
  notes?: string;
  receivedBy: string;
  createdAt: string;
}

export interface ExpenseCategory {
  id: string;
  name: string;
  description?: string;
}

export interface Expense {
  id: string;
  categoryId: string;
  categoryName?: string;
  amount: number;
  paymentMethod: PaymentMethod;
  description: string;
  paidTo?: string;
  recordedBy: string;
  receiptUrl?: string;
  createdAt: string;
}

export interface CashReconciliation {
  id: string;
  date: string;
  openingFloat: number;
  cashSalesTotal: number;
  cashPaymentsReceivedTotal: number;
  cashExpensesTotal: number;
  expectedCashTotal: number;
  actualCountedCash: number;
  variance: number; // actual - expected
  reconciledBy: string;
  notes?: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
  userId: string;
  userName: string;
  timestamp: string;
}

export interface LicenseInfo {
  machineId: string;
  licenseKey?: string;
  licensedTo?: string;
  status: 'trial' | 'active' | 'expired' | 'community';
  planType: 'Business Pro Single' | 'Business Pro Multi' | 'Enterprise Offline';
  validUntil: string;
  features: string[];
}

export interface DatabaseBackupMeta {
  backupId: string;
  filename: string;
  createdAt: string;
  fileSizeBytes: number;
  reason: 'manual' | 'pre_restore_safety' | 'migration' | 'daily_auto';
  recordCounts: {
    products: number;
    sales: number;
    customers: number;
    suppliers: number;
    purchases: number;
    expenses: number;
  };
}
