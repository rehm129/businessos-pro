import React, { useState, useEffect } from 'react';
import {
  Boxes,
  Plus,
  Search,
  Filter,
  AlertTriangle,
  History,
  Layers,
  Edit2,
  SlidersHorizontal,
  X,
  CheckCircle,
  Archive,
  ArrowUpDown,
  Download,
} from 'lucide-react';
import { BusinessProfile, Category, Product, StockMovement, StockMovementType, User } from '../../types';
import { inventoryService, CreateProductInput, UpdateProductInput } from '../../services/inventory-service';
import { reportingService } from '../../services/reporting-service';

interface InventoryViewProps {
  business: BusinessProfile | null;
  currentUser: User | null;
}

export const InventoryView: React.FC<InventoryViewProps> = ({ business, currentUser }) => {
  const currency = business?.currencySymbol || '$';

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [lowStockOnly, setLowStockOnly] = useState(false);
  const [includeArchived, setIncludeArchived] = useState(false);

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const [showAdjustModal, setShowAdjustModal] = useState(false);
  const [adjustProductId, setAdjustProductId] = useState('');
  const [adjustDelta, setAdjustDelta] = useState<number>(0);
  const [adjustType, setAdjustType] = useState<StockMovementType>('manual_adjustment');
  const [adjustNotes, setAdjustNotes] = useState('');

  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [historyProductId, setHistoryProductId] = useState<string | undefined>(undefined);
  const [stockMovements, setStockMovements] = useState<StockMovement[]>([]);

  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');
  const [newCatColor, setNewCatColor] = useState('#6366f1');

  // Add/Edit Form State
  const [formName, setFormName] = useState('');
  const [formSku, setFormSku] = useState('');
  const [formBarcode, setFormBarcode] = useState('');
  const [formCatId, setFormCatId] = useState('');
  const [formUnit, setFormUnit] = useState('pcs');
  const [formCost, setFormCost] = useState<number>(0);
  const [formPrice, setFormPrice] = useState<number>(0);
  const [formStock, setFormStock] = useState<number>(0);
  const [formMinThreshold, setFormMinThreshold] = useState<number>(5);
  const [formError, setFormError] = useState('');

  const refreshData = () => {
    setProducts(
      inventoryService.getProducts({
        search,
        categoryId: categoryFilter,
        lowStockOnly,
        includeArchived,
      })
    );
    setCategories(inventoryService.getCategories());
  };

  useEffect(() => {
    refreshData();
  }, [search, categoryFilter, lowStockOnly, includeArchived]);

  const handleOpenAdd = () => {
    setFormName('');
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    setFormSku(`SKU-${randomSuffix}`);
    setFormBarcode(`890${Date.now().toString().slice(-7)}`);
    setFormCatId(categories[0]?.id || '');
    setFormUnit('pcs');
    setFormCost(0);
    setFormPrice(0);
    setFormStock(10);
    setFormMinThreshold(business?.lowStockThresholdDefault || 5);
    setFormError('');
    setShowAddModal(true);
  };

  const handleOpenEdit = (p: Product) => {
    setSelectedProduct(p);
    setFormName(p.name);
    setFormSku(p.sku);
    setFormBarcode(p.barcode);
    setFormCatId(p.categoryId);
    setFormUnit(p.unit);
    setFormCost(p.purchaseCost);
    setFormPrice(p.sellingPrice);
    setFormMinThreshold(p.minStockThreshold);
    setFormError('');
    setShowEditModal(true);
  };

  const handleOpenAdjust = (p: Product) => {
    setAdjustProductId(p.id);
    setSelectedProduct(p);
    setAdjustDelta(0);
    setAdjustType('manual_adjustment');
    setAdjustNotes('');
    setShowAdjustModal(true);
  };

  const handleOpenHistory = (productId?: string) => {
    setHistoryProductId(productId);
    setStockMovements(inventoryService.getStockMovements(productId, 100));
    setShowHistoryModal(true);
  };

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    try {
      const input: CreateProductInput = {
        name: formName,
        sku: formSku,
        barcode: formBarcode,
        categoryId: formCatId,
        unit: formUnit,
        purchaseCost: formCost,
        sellingPrice: formPrice,
        initialStock: formStock,
        minStockThreshold: formMinThreshold,
      };
      inventoryService.createProduct(input, currentUser?.displayName || 'Admin');
      setShowAddModal(false);
      refreshData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to save product.');
    }
  };

  const handleUpdateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProduct) return;
    setFormError('');
    try {
      const input: UpdateProductInput = {
        name: formName,
        sku: formSku,
        barcode: formBarcode,
        categoryId: formCatId,
        unit: formUnit,
        purchaseCost: formCost,
        sellingPrice: formPrice,
        minStockThreshold: formMinThreshold,
      };
      inventoryService.updateProduct(selectedProduct.id, input);
      setShowEditModal(false);
      refreshData();
    } catch (err: any) {
      setFormError(err.message || 'Failed to update product.');
    }
  };

  const handleSaveAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (adjustDelta === 0) {
      alert('Adjustment quantity cannot be 0.');
      return;
    }
    try {
      inventoryService.adjustStock(
        adjustProductId,
        adjustDelta,
        adjustType,
        adjustNotes || 'Manual stock reconciliation',
        currentUser?.displayName || 'Admin'
      );
      setShowAdjustModal(false);
      refreshData();
    } catch (err: any) {
      alert(err.message || 'Failed to adjust stock.');
    }
  };

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      inventoryService.createCategory(newCatName, newCatDesc, newCatColor);
      setNewCatName('');
      setNewCatDesc('');
      setCategories(inventoryService.getCategories());
    } catch (err: any) {
      alert(err.message || 'Failed to create category.');
    }
  };

  const handleDeleteCategory = (id: string) => {
    if (!confirm('Are you sure you want to remove this category?')) return;
    try {
      inventoryService.deleteCategory(id);
      setCategories(inventoryService.getCategories());
      refreshData();
    } catch (err: any) {
      alert(err.message || 'Could not delete category.');
    }
  };

  const handleExportCsv = () => {
    const headers = ['SKU', 'Barcode', 'Product Name', 'Category', 'Unit', 'Stock', 'Min Threshold', 'Cost', 'Price', 'Margin %'];
    const rows = products.map((p) => {
      const margin = p.sellingPrice > 0 ? (((p.sellingPrice - p.purchaseCost) / p.sellingPrice) * 100).toFixed(1) : '0.0';
      return [
        p.sku,
        p.barcode,
        p.name,
        p.categoryName,
        p.unit,
        p.currentStock,
        p.minStockThreshold,
        p.purchaseCost.toFixed(2),
        p.sellingPrice.toFixed(2),
        `${margin}%`,
      ];
    });
    reportingService.downloadCsv('inventory_catalog_export.csv', headers, rows);
  };

  return (
    <div className="space-y-6 text-white pb-10">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
            <Boxes className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">Products & Inventory Management</h2>
            <p className="text-xs text-slate-400">
              Track multi-department stock, price margins, barcodes, and audit movements.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => handleOpenHistory()}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200"
          >
            <History className="w-3.5 h-3.5 text-slate-400" />
            <span>Audit Trail</span>
          </button>

          <button
            onClick={() => setShowCategoryModal(true)}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200"
          >
            <Layers className="w-3.5 h-3.5 text-slate-400" />
            <span>Categories</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200"
          >
            <Download className="w-3.5 h-3.5 text-slate-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-semibold text-xs text-white shadow-md shadow-indigo-600/30 transition transform active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Product (F3)</span>
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="w-full md:w-80 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by name, SKU, or barcode..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 focus:outline-hidden focus:border-indigo-500"
          />
        </div>

        <div className="w-full md:w-auto flex flex-wrap items-center gap-2.5 text-xs">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-300 focus:outline-hidden"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <button
            onClick={() => setLowStockOnly(!lowStockOnly)}
            className={`px-3 py-1.5 rounded-lg border font-medium flex items-center space-x-1.5 transition ${
              lowStockOnly
                ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                : 'bg-slate-950 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Low Stock Alert</span>
          </button>

          <label className="flex items-center space-x-1.5 text-slate-400 cursor-pointer ml-1">
            <input
              type="checkbox"
              checked={includeArchived}
              onChange={(e) => setIncludeArchived(e.target.checked)}
              className="rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0"
            />
            <span>Include Archived</span>
          </label>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="px-5 py-3.5">SKU / Barcode</th>
                <th className="px-5 py-3.5">Product Title</th>
                <th className="px-5 py-3.5">Category</th>
                <th className="px-5 py-3.5 text-center">Current Stock</th>
                <th className="px-5 py-3.5 text-right">Cost</th>
                <th className="px-5 py-3.5 text-right">Selling Price</th>
                <th className="px-5 py-3.5 text-right">Margin</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {products.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-10 text-center text-slate-400">
                    No products found matching filters.
                  </td>
                </tr>
              ) : (
                products.map((p) => {
                  const isLow = p.currentStock <= p.minStockThreshold;
                  const isOut = p.currentStock <= 0;
                  const marginPercent =
                    p.sellingPrice > 0
                      ? (((p.sellingPrice - p.purchaseCost) / p.sellingPrice) * 100).toFixed(1)
                      : '0.0';

                  return (
                    <tr key={p.id} className="hover:bg-slate-800/40 transition">
                      <td className="px-5 py-3 font-mono">
                        <div className="text-indigo-400 font-semibold">{p.sku}</div>
                        <div className="text-[10px] text-slate-400">{p.barcode}</div>
                      </td>
                      <td className="px-5 py-3 text-slate-100 font-semibold max-w-xs">
                        {p.name}
                        {p.isArchived && (
                          <span className="ml-2 px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-400">
                            Archived
                          </span>
                        )}
                      </td>
                      <td className="px-5 py-3 text-slate-400">{p.categoryName}</td>
                      <td className="px-5 py-3 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold font-mono ${
                            isOut
                              ? 'bg-rose-950 text-rose-400 border border-rose-500/30'
                              : isLow
                              ? 'bg-amber-950 text-amber-400 border border-amber-500/30'
                              : 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/30'
                          }`}
                        >
                          {p.currentStock} {p.unit}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-right font-mono text-slate-400">
                        {currency}{p.purchaseCost.toFixed(2)}
                      </td>
                      <td className="px-5 py-3 text-right font-mono font-bold text-slate-100">
                        {currency}{p.sellingPrice.toFixed(2)}
                      </td>
                      <td className="px-5 py-3 text-right font-mono text-emerald-400">
                        {marginPercent}%
                      </td>
                      <td className="px-5 py-3 text-right space-x-1.5">
                        <button
                          onClick={() => handleOpenAdjust(p)}
                          title="Adjust stock quantity"
                          className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-amber-400 transition"
                        >
                          <SlidersHorizontal className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleOpenHistory(p.id)}
                          title="View product stock movements"
                          className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-indigo-400 transition"
                        >
                          <History className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleOpenEdit(p)}
                          title="Edit product"
                          className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {(showAddModal || showEditModal) && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100">
                {showAddModal ? 'Add New Product to Catalog' : 'Edit Product Details'}
              </h3>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setShowEditModal(false);
                }}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={showAddModal ? handleCreateProduct : handleUpdateProduct} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Product Name / Title *
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g., Organic Dark Roast Coffee 500g"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    SKU Identifier *
                  </label>
                  <input
                    type="text"
                    required
                    value={formSku}
                    onChange={(e) => setFormSku(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-100 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Barcode Identifier *
                  </label>
                  <input
                    type="text"
                    required
                    value={formBarcode}
                    onChange={(e) => setFormBarcode(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-100 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Category *
                  </label>
                  <select
                    value={formCatId}
                    onChange={(e) => setFormCatId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Unit of Measure
                  </label>
                  <input
                    type="text"
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    placeholder="pcs, kg, box, pack..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Purchase Cost ({currency})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={formCost}
                    onChange={(e) => setFormCost(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-100 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Selling Price ({currency})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={formPrice}
                    onChange={(e) => setFormPrice(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-100 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {showAddModal && (
                  <div>
                    <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                      Initial Opening Stock
                    </label>
                    <input
                      type="number"
                      step="1"
                      min="0"
                      value={formStock}
                      onChange={(e) => setFormStock(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-100 focus:outline-hidden"
                    />
                  </div>
                )}
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Low Stock Threshold
                  </label>
                  <input
                    type="number"
                    step="1"
                    min="1"
                    value={formMinThreshold}
                    onChange={(e) => setFormMinThreshold(parseFloat(e.target.value) || 5)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-slate-100 focus:outline-hidden"
                  />
                </div>
              </div>

              {formError && (
                <div className="p-2.5 rounded-xl bg-rose-950/70 border border-rose-500/50 text-rose-300 text-xs">
                  {formError}
                </div>
              )}

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setShowEditModal(false);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-md shadow-indigo-600/30"
                >
                  {showAddModal ? 'Save New Item' : 'Update Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Stock Adjustment Modal */}
      {showAdjustModal && selectedProduct && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100">Adjust Stock Quantity</h3>
                <p className="text-xs text-slate-400">{selectedProduct.name}</p>
              </div>
              <button onClick={() => setShowAdjustModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAdjustment} className="mt-4 space-y-4">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center text-xs">
                <span className="text-slate-400">Current Stock on Record</span>
                <span className="font-mono font-bold text-sm text-slate-100">
                  {selectedProduct.currentStock} {selectedProduct.unit}
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Quantity Change (+ to add, - to deduct) *
                </label>
                <input
                  type="number"
                  step="1"
                  required
                  value={adjustDelta || ''}
                  placeholder="e.g. +5 or -2"
                  onChange={(e) => setAdjustDelta(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm font-mono text-white focus:outline-hidden"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Resulting Stock: <span className="font-bold text-indigo-400">{selectedProduct.currentStock + adjustDelta}</span>
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Reason for Adjustment
                </label>
                <select
                  value={adjustType}
                  onChange={(e) => setAdjustType(e.target.value as StockMovementType)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden"
                >
                  <option value="manual_adjustment">Manual Inventory Reconciliation</option>
                  <option value="damaged_loss">Damaged / Expired / Lost</option>
                  <option value="opening_stock">Initial Setup Correction</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Notes / Audit Explanation
                </label>
                <input
                  type="text"
                  placeholder="e.g., Found 2 extra boxes during weekly physical shelf count"
                  value={adjustNotes}
                  onChange={(e) => setAdjustNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAdjustModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-xs font-bold text-white shadow-md shadow-amber-600/30"
                >
                  Apply & Record Movement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Stock Movement Audit History Modal */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-3xl w-full p-6 text-white shadow-2xl flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <History className="w-5 h-5 text-indigo-400" />
                <h3 className="text-base font-bold text-slate-100">
                  Stock Movement Audit Log {historyProductId ? `(Filtered)` : '(All Movements)'}
                </h3>
              </div>
              <button onClick={() => setShowHistoryModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto mt-4">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 sticky top-0">
                  <tr>
                    <th className="px-4 py-2.5">Date & Time</th>
                    <th className="px-4 py-2.5">Product</th>
                    <th className="px-4 py-2.5">Movement Type</th>
                    <th className="px-4 py-2.5 text-center">Change</th>
                    <th className="px-4 py-2.5 text-center">Stock After</th>
                    <th className="px-4 py-2.5">Reference / Notes</th>
                    <th className="px-4 py-2.5">Logged By</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-medium">
                  {stockMovements.map((m) => (
                    <tr key={m.id} className="hover:bg-slate-800/30">
                      <td className="px-4 py-2.5 text-slate-400 whitespace-nowrap">
                        {new Date(m.createdAt).toLocaleString()}
                      </td>
                      <td className="px-4 py-2.5 text-slate-100 font-semibold">{m.productName}</td>
                      <td className="px-4 py-2.5 uppercase text-[10px] text-slate-300">
                        {m.movementType.replace('_', ' ')}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono font-bold">
                        <span className={m.quantityChange > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          {m.quantityChange > 0 ? `+${m.quantityChange}` : m.quantityChange}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono text-slate-300">{m.stockAfter}</td>
                      <td className="px-4 py-2.5 text-slate-400 truncate max-w-xs">{m.referenceId}: {m.notes}</td>
                      <td className="px-4 py-2.5 text-slate-400">{m.createdByName}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowHistoryModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Categories Management Modal */}
      {showCategoryModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100">Manage Store Categories</h3>
              <button onClick={() => setShowCategoryModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Existing Categories */}
            <div className="mt-4 space-y-2 max-h-56 overflow-y-auto">
              {categories.map((c) => (
                <div
                  key={c.id}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center space-x-2.5">
                    <span className="w-3 h-3 rounded-full" style={{ backgroundColor: c.color }} />
                    <span className="font-semibold text-slate-200">{c.name}</span>
                    <span className="text-[11px] text-slate-400">({c.itemCount ?? 0} items)</span>
                  </div>
                  <button
                    onClick={() => handleDeleteCategory(c.id)}
                    className="text-slate-400 hover:text-rose-400 px-2 py-1 text-xs"
                  >
                    Delete
                  </button>
                </div>
              ))}
            </div>

            {/* Create Category Form */}
            <form onSubmit={handleCreateCategory} className="mt-5 pt-4 border-t border-slate-800 space-y-3">
              <h4 className="text-xs font-semibold text-slate-300 uppercase">Create New Category</h4>
              <div className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  required
                  placeholder="Category Name"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="col-span-2 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-hidden"
                />
                <input
                  type="color"
                  value={newCatColor}
                  onChange={(e) => setNewCatColor(e.target.value)}
                  className="w-full h-8 bg-slate-950 border border-slate-700 rounded-lg cursor-pointer"
                />
              </div>
              <input
                type="text"
                placeholder="Optional description"
                value={newCatDesc}
                onChange={(e) => setNewCatDesc(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-hidden"
              />
              <button
                type="submit"
                className="w-full py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 font-semibold text-xs text-white shadow-sm"
              >
                Save Category
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
