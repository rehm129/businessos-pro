import React, { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  ShoppingBag,
  AlertTriangle,
  Receipt,
  Users,
  Wallet,
  ArrowUpRight,
  PackageCheck,
  PlusCircle,
  Eye,
  RotateCcw,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import { BusinessProfile, Sale } from '../../types';
import { reportingService, DashboardMetrics, SalesChartPoint, CategorySalesPoint } from '../../services/reporting-service';
import { posService } from '../../services/pos-service';

interface DashboardViewProps {
  business: BusinessProfile | null;
  onNavigateToPos: () => void;
  onNavigateToInventory: () => void;
  onNavigateToExpenses: () => void;
  onSelectSaleReceipt: (saleId: string) => void;
  onSelectSaleReturn: (saleId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  business,
  onNavigateToPos,
  onNavigateToInventory,
  onNavigateToExpenses,
  onSelectSaleReceipt,
  onSelectSaleReturn,
}) => {
  const currency = business?.currencySymbol || '$';
  const metrics: DashboardMetrics = reportingService.getDashboardMetrics();
  const salesTrend: SalesChartPoint[] = reportingService.getSalesTrend(7);
  const categorySales: CategorySalesPoint[] = reportingService.getSalesByCategory();
  const recentSales: Sale[] = posService.getSales(8);

  return (
    <div className="space-y-6 text-white pb-10">
      {/* Top Banner & Quick Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-100">
            Welcome back to {business?.name || 'BusinessOS Pro'}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Real-time local ledger, offline POS terminal, and instant profit reconciliation.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={onNavigateToPos}
            className="flex items-center space-x-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-semibold text-sm text-white shadow-lg shadow-indigo-600/30 transition transform active:scale-95"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Open POS Register (F2)</span>
          </button>

          <button
            onClick={onNavigateToInventory}
            className="flex items-center space-x-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-sm font-medium text-slate-200 transition"
          >
            <PlusCircle className="w-4 h-4 text-slate-400" />
            <span>Manage Items</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Sales Today */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl hover:border-slate-700 transition">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Today's Sales</span>
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-white tracking-tight">
              {currency}{metrics.salesToday.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <span className="text-xs text-slate-400 font-medium">
              {metrics.ordersCountToday} {metrics.ordersCountToday === 1 ? 'order' : 'orders'}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2 flex items-center">
            <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400 mr-1" />
            Live register counter
          </p>
        </div>

        {/* Card 2: Estimated Gross Profit */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl hover:border-slate-700 transition">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Gross Profit (Today)</span>
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-emerald-400 tracking-tight">
              {currency}{metrics.grossProfitToday.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <span className="text-xs text-slate-400">Accrual Costing</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2 truncate" title="Net sales revenue minus product purchase acquisition cost">
            Method: Net Sales - Cost of Goods
          </p>
        </div>

        {/* Card 3: Net Operating Profit */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl hover:border-slate-700 transition">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Net Profit (Today)</span>
            <div className="p-2 rounded-lg bg-teal-500/10 text-teal-400">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className={`text-2xl font-bold tracking-tight ${metrics.netProfitToday >= 0 ? 'text-teal-400' : 'text-rose-400'}`}>
              {currency}{metrics.netProfitToday.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <span className="text-xs text-slate-400 font-mono">
              - {currency}{metrics.expensesToday.toFixed(2)} exp
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            After deducting daily operating expenses
          </p>
        </div>

        {/* Card 4: Low Stock Alerts */}
        <div
          onClick={onNavigateToInventory}
          className="bg-slate-900 border border-slate-800 p-5 rounded-xl hover:border-amber-500/50 cursor-pointer transition group"
        >
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-semibold uppercase tracking-wider">Low Stock Warnings</span>
            <div className={`p-2 rounded-lg ${metrics.lowStockItemsCount > 0 ? 'bg-amber-500/10 text-amber-400' : 'bg-slate-800 text-slate-400'}`}>
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className={`text-2xl font-bold tracking-tight ${metrics.lowStockItemsCount > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
              {metrics.lowStockItemsCount} {metrics.lowStockItemsCount === 1 ? 'item' : 'items'}
            </span>
            <span className="text-xs text-amber-400/80 group-hover:underline">View All</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            At or below safety threshold
          </p>
        </div>
      </div>

      {/* Secondary Metrics Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/60 border border-slate-800/80 px-4 py-3 rounded-xl flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
              <PackageCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs text-slate-400">Inventory Valuation (Cost)</div>
              <div className="text-sm font-semibold text-slate-200">
                {currency}{metrics.inventoryValuationCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 px-4 py-3 rounded-xl flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs text-slate-400">Customer Due (Receivables)</div>
              <div className="text-sm font-semibold text-slate-200">
                {currency}{metrics.totalReceivables.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 px-4 py-3 rounded-xl flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-rose-500/10 text-rose-400">
              <Receipt className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs text-slate-400">Today's Expenses</div>
              <div className="text-sm font-semibold text-slate-200">
                {currency}{metrics.expensesToday.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>
          <button
            onClick={onNavigateToExpenses}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium"
          >
            + Record
          </button>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 7-Day Revenue & Profit Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-semibold text-slate-100">7-Day Sales & Profit Performance</h3>
              <p className="text-xs text-slate-400">Daily gross revenue and accrual gross profit</p>
            </div>
            <div className="flex items-center space-x-4 text-xs">
              <div className="flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-500"></span>
                <span className="text-slate-300">Revenue</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                <span className="text-slate-300">Profit</span>
              </div>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={salesTrend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="date" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }}
                  itemStyle={{ fontSize: '12px' }}
                  formatter={(val: any) => [`${currency}${Number(val).toFixed(2)}`]}
                />
                <Area
                  type="monotone"
                  dataKey="sales"
                  name="Sales Revenue"
                  stroke="#6366f1"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorSales)"
                />
                <Area
                  type="monotone"
                  dataKey="profit"
                  name="Gross Profit"
                  stroke="#10b981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorProfit)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Sales Breakdown */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-slate-100">Top Categories</h3>
            <p className="text-xs text-slate-400">Sales volume by department</p>
          </div>

          <div className="space-y-4 mt-2">
            {categorySales.map((cat, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-slate-300">{cat.name}</span>
                  <span className="text-slate-200 font-mono">
                    {currency}{cat.total.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(100, (cat.total / (categorySales[0]?.total || 1)) * 100)}%`,
                      backgroundColor: cat.color || '#6366f1',
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Sales Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-base font-semibold text-slate-100">Recent Completed Sales</h3>
            <p className="text-xs text-slate-400">Latest transactions at this terminal</p>
          </div>
          <button
            onClick={onNavigateToPos}
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300"
          >
            Open POS Register →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/60 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="px-5 py-3">Receipt #</th>
                <th className="px-5 py-3">Customer</th>
                <th className="px-5 py-3">Payment</th>
                <th className="px-5 py-3 text-right">Grand Total</th>
                <th className="px-5 py-3 text-right">Est. Profit</th>
                <th className="px-5 py-3 text-center">Status</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {recentSales.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-8 text-center text-slate-400">
                    No transactions recorded yet. Click "Open POS Register" to start your first sale!
                  </td>
                </tr>
              ) : (
                recentSales.map((sale) => (
                  <tr key={sale.id} className="hover:bg-slate-800/30 transition">
                    <td className="px-5 py-3.5 font-mono text-indigo-400 font-semibold">
                      {sale.receiptNumber}
                    </td>
                    <td className="px-5 py-3.5 text-slate-200">
                      {sale.customerName || 'Walk-in Retail Customer'}
                    </td>
                    <td className="px-5 py-3.5 uppercase text-[11px] text-slate-400">
                      {sale.paymentMethod}
                    </td>
                    <td className="px-5 py-3.5 text-right font-mono font-bold text-slate-100">
                      {currency}{sale.grandTotal.toFixed(2)}
                    </td>
                    <td className="px-5 py-3.5 text-right font-mono text-emerald-400">
                      {currency}{sale.estimatedProfit.toFixed(2)}
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                          sale.status === 'completed'
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                            : sale.status === 'refunded'
                            ? 'bg-rose-950 text-rose-400 border border-rose-500/30'
                            : 'bg-amber-950 text-amber-400 border border-amber-500/30'
                        }`}
                      >
                        {sale.status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right space-x-2">
                      <button
                        onClick={() => onSelectSaleReceipt(sale.id)}
                        title="View printable receipt"
                        className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      {sale.status === 'completed' && (
                        <button
                          onClick={() => onSelectSaleReturn(sale.id)}
                          title="Process refund or return"
                          className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-amber-400 transition"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
