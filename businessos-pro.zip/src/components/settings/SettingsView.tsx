import React, { useState, useEffect } from 'react';
import {
  Settings,
  Building2,
  HardDrive,
  KeyRound,
  Download,
  Upload,
  CheckCircle,
  AlertTriangle,
  RotateCcw,
  ShieldCheck,
  Cpu,
  FileCheck2,
  Info,
} from 'lucide-react';
import { BusinessProfile, BusinessType, DatabaseBackupMeta, LicenseInfo } from '../../types';
import { businessService } from '../../services/business-service';
import { sqliteService } from '../../db/sqlite-service';
import { licensingService } from '../../services/licensing-service';

interface SettingsViewProps {
  onProfileUpdated: (profile: BusinessProfile) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onProfileUpdated }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'database' | 'licensing'>('profile');

  // Business Profile Form State
  const [profile, setProfile] = useState<BusinessProfile | null>(null);
  const [name, setName] = useState('');
  const [legalName, setLegalName] = useState('');
  const [tagline, setTagline] = useState('');
  const [businessType, setBusinessType] = useState<BusinessType>('supermarket');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [currencyCode, setCurrencyCode] = useState('USD');
  const [currencySymbol, setCurrencySymbol] = useState('$');
  const [taxRatePercent, setTaxRatePercent] = useState<number>(8.5);
  const [taxNumber, setTaxNumber] = useState('');
  const [enableTax, setEnableTax] = useState(true);
  const [receiptFooter, setReceiptFooter] = useState('');
  const [allowNegativeStock, setAllowNegativeStock] = useState(false);
  const [enableSplitPayments, setEnableSplitPayments] = useState(true);
  const [lowStockThreshold, setLowStockThreshold] = useState<number>(5);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Database Backup & Restore State
  const [safetyBackups, setSafetyBackups] = useState<DatabaseBackupMeta[]>([]);
  const [integrityStatus, setIntegrityStatus] = useState<{ ok: boolean; rows: string[] } | null>(null);
  const [isVerifyingIntegrity, setIsVerifyingIntegrity] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);

  // Licensing State
  const [license, setLicense] = useState<LicenseInfo | null>(null);
  const [licenseKeyInput, setLicenseKeyInput] = useState('');
  const [licenseOrgInput, setLicenseOrgInput] = useState('');
  const [licenseMessage, setLicenseMessage] = useState('');

  const loadData = async () => {
    try {
      const p = businessService.getProfile();
      setProfile(p);
      setName(p.name);
      setLegalName(p.legalName || '');
      setTagline(p.tagline || '');
      setBusinessType(p.businessType);
      setPhone(p.phone);
      setEmail(p.email);
      setAddress(p.address);
      setCurrencyCode(p.currencyCode);
      setCurrencySymbol(p.currencySymbol);
      setTaxRatePercent(p.taxRatePercent);
      setTaxNumber(p.taxNumber || '');
      setEnableTax(p.enableTax);
      setReceiptFooter(p.receiptFooterMessage);
      setAllowNegativeStock(p.allowNegativeStock);
      setEnableSplitPayments(p.enableSplitPayments);
      setLowStockThreshold(p.lowStockThresholdDefault);

      // Backups
      setSafetyBackups(sqliteService.getSafetyBackups());

      // License
      const lic = await licensingService.getLicense();
      setLicense(lic);
      setLicenseOrgInput(lic.licensedTo || p.name);
    } catch (err) {
      console.error('Error loading settings:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const updated = businessService.updateProfile({
        name,
        legalName,
        tagline,
        businessType,
        phone,
        email,
        address,
        currencyCode,
        currencySymbol,
        taxRatePercent,
        taxNumber,
        enableTax,
        receiptFooterMessage: receiptFooter,
        allowNegativeStock,
        enableSplitPayments,
        lowStockThresholdDefault: lowStockThreshold,
      });
      setProfile(updated);
      onProfileUpdated(updated);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      alert(err.message || 'Failed to save business settings.');
    }
  };

  const handleDownloadBackup = () => {
    try {
      const bytes = sqliteService.exportBinary();
      const blob = new Blob([bytes as unknown as BlobPart], { type: 'application/x-sqlite3' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const dateStr = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `businessos_pro_backup_${dateStr}.sqlite`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      // Also record in internal backup history
      sqliteService.createSafetyBackup('manual').then(() => {
        setSafetyBackups(sqliteService.getSafetyBackups());
      });
    } catch (err: any) {
      alert('Failed to generate backup: ' + err.message);
    }
  };

  const handleRestoreFromFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!confirm('CAUTION: Restoring will overwrite existing data. An automated safety backup will be created first. Proceed?')) {
      e.target.value = '';
      return;
    }

    setIsRestoring(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const uint8 = new Uint8Array(arrayBuffer);
      await sqliteService.importBinaryWithSafety(uint8);
      alert('Database restored successfully from backup!');
      window.location.reload();
    } catch (err: any) {
      alert('Restore failed: ' + err.message);
    } finally {
      setIsRestoring(false);
      e.target.value = '';
    }
  };

  const handleRestoreSafetyBackup = async (backupId: string) => {
    if (!confirm('Restore database from this safety backup? A safety snapshot of the current state will be taken first.')) {
      return;
    }

    setIsRestoring(true);
    try {
      await sqliteService.restoreFromBackupId(backupId);
      alert('Restored successfully from safety backup!');
      window.location.reload();
    } catch (err: any) {
      alert('Restore failed: ' + err.message);
    } finally {
      setIsRestoring(false);
    }
  };

  const handleRunIntegrityCheck = () => {
    setIsVerifyingIntegrity(true);
    setTimeout(() => {
      const res = sqliteService.checkIntegrity();
      setIntegrityStatus(res);
      setIsVerifyingIntegrity(false);
    }, 400);
  };

  const handleActivateLicense = async (e: React.FormEvent) => {
    e.preventDefault();
    setLicenseMessage('');
    try {
      const updated = await licensingService.activateKey(licenseKeyInput, licenseOrgInput);
      setLicense(updated);
      setLicenseMessage('Commercial license activated successfully!');
      setLicenseKeyInput('');
    } catch (err: any) {
      setLicenseMessage('Activation error: ' + err.message);
    }
  };

  return (
    <div className="space-y-6 text-white pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">Settings, Database & Licensing</h2>
            <p className="text-xs text-slate-400">
              Configure store preferences, taxes, SQLite backups, integrity audits, and commercial licensing.
            </p>
          </div>
        </div>
      </div>

      {/* Settings Navigation Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
        {[
          { id: 'profile', label: 'Business Profile & Rules', icon: Building2 },
          { id: 'database', label: 'Database Backup & Integrity', icon: HardDrive },
          { id: 'licensing', label: 'Commercial Licensing & Desktop', icon: KeyRound },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center space-x-2 transition ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab 1: Business Profile & Rules */}
      {activeTab === 'profile' && (
        <form onSubmit={handleSaveProfile} className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 border-b border-slate-800 pb-3">
              Store Identity & Business Profile
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Business Store Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Legal Registered Entity
                </label>
                <input
                  type="text"
                  value={legalName}
                  onChange={(e) => setLegalName(e.target.value)}
                  placeholder="e.g., Metro Retail LLC"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Business Type Template
                </label>
                <select
                  value={businessType}
                  onChange={(e) => setBusinessType(e.target.value as BusinessType)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                >
                  <option value="supermarket">Supermarket / Grocery</option>
                  <option value="clothing_apparel">Garments & Apparel Fashion</option>
                  <option value="electronics_mobile">Mobile Phones & Electronics</option>
                  <option value="wholesale_distributor">Wholesale & Distribution</option>
                  <option value="small_retail">Small Retail & Convenience</option>
                  <option value="service_business">Service & Repair Business</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Phone *
                </label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Store Address
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* Currency & Tax Rules */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 border-b border-slate-800 pb-3">
              Currency, Taxes & Printing
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Currency Symbol
                </label>
                <input
                  type="text"
                  required
                  value={currencySymbol}
                  onChange={(e) => setCurrencySymbol(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-center text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Currency Code
                </label>
                <input
                  type="text"
                  required
                  value={currencyCode}
                  onChange={(e) => setCurrencyCode(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-center text-white uppercase"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Sales Tax Rate (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={taxRatePercent}
                  onChange={(e) => setTaxRatePercent(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Tax Registration #
                </label>
                <input
                  type="text"
                  value={taxNumber}
                  onChange={(e) => setTaxNumber(e.target.value)}
                  placeholder="e.g. TAX-89241"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Printed Receipt Footer Message
                </label>
                <textarea
                  rows={2}
                  value={receiptFooter}
                  onChange={(e) => setReceiptFooter(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-3 pt-3">
                <label className="flex items-center space-x-2.5 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableTax}
                    onChange={(e) => setEnableTax(e.target.checked)}
                    className="rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0"
                  />
                  <span>Enable Sales Tax calculation at checkout</span>
                </label>

                <label className="flex items-center space-x-2.5 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowNegativeStock}
                    onChange={(e) => setAllowNegativeStock(e.target.checked)}
                    className="rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0"
                  />
                  <span>
                    Allow Negative Inventory (Unchecked = strict prevention of sales when out of stock)
                  </span>
                </label>

                <label className="flex items-center space-x-2.5 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableSplitPayments}
                    onChange={(e) => setEnableSplitPayments(e.target.checked)}
                    className="rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0"
                  />
                  <span>Enable Split Payments (Cash + Card tender)</span>
                </label>
              </div>
            </div>
          </div>

          {saveSuccess && (
            <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-300 text-xs flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Business settings saved successfully!</span>
            </div>
          )}

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-bold text-xs text-white shadow-md shadow-indigo-600/30"
            >
              Save Changes
            </button>
          </div>
        </form>
      )}

      {/* Tab 2: Database Backup & Restore & Integrity */}
      {activeTab === 'database' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Backup Box */}
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-100">Export SQLite Database</h4>
                  <p className="text-xs text-slate-400">Download clean binary .sqlite file</p>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                Creates a verified snapshot of the entire local SQLite database (products, sales, customers, suppliers, expenses, and migrations).
              </p>

              <button
                onClick={handleDownloadBackup}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-bold text-xs text-white flex items-center justify-center space-x-2 shadow-md shadow-emerald-600/20"
              >
                <Download className="w-4 h-4" />
                <span>Download Database File (.sqlite)</span>
              </button>
            </div>

            {/* Restore Box */}
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-100">Restore Database</h4>
                  <p className="text-xs text-slate-400">Validated restore with safety snapshot</p>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                Before applying any restored file, BusinessOS Pro creates an automated safety snapshot of the existing database to prevent any data loss.
              </p>

              <label className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 font-bold text-xs text-slate-200 flex items-center justify-center space-x-2 cursor-pointer transition">
                <Upload className="w-4 h-4 text-indigo-400" />
                <span>Select .sqlite File to Restore</span>
                <input
                  type="file"
                  accept=".sqlite,.db"
                  disabled={isRestoring}
                  onChange={handleRestoreFromFile}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Database Integrity Check Tool */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
                  <FileCheck2 className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-100">SQLite Engine Integrity Audit</h4>
                  <p className="text-xs text-slate-400">Execute low-level PRAGMA integrity_check</p>
                </div>
              </div>

              <button
                disabled={isVerifyingIntegrity}
                onClick={handleRunIntegrityCheck}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-sm"
              >
                {isVerifyingIntegrity ? 'Auditing...' : 'Run Integrity Check'}
              </button>
            </div>

            {integrityStatus && (
              <div
                className={`p-4 rounded-xl border text-xs font-mono space-y-1 ${
                  integrityStatus.ok
                    ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-950/60 border-rose-500/40 text-rose-300'
                }`}
              >
                <div className="flex items-center space-x-2 font-bold">
                  {integrityStatus.ok ? (
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                  )}
                  <span>Status: {integrityStatus.ok ? 'PASSED (ok)' : 'INTEGRITY WARNINGS DETECTED'}</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  SQLite PRAGMA result: {integrityStatus.rows.join('; ')}
                </div>
              </div>
            )}
          </div>

          {/* Automated Safety Backups Log */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
            <div className="p-4 border-b border-slate-800">
              <h4 className="font-bold text-sm text-slate-100">Internal Safety Snapshots</h4>
              <p className="text-xs text-slate-400">
                Created before every restore or manual backup to guarantee zero silent overwrites.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="px-5 py-3">Timestamp</th>
                    <th className="px-5 py-3">Reason</th>
                    <th className="px-5 py-3">Size</th>
                    <th className="px-5 py-3">Record Breakdown</th>
                    <th className="px-5 py-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-medium">
                  {safetyBackups.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-5 py-6 text-center text-slate-400">
                        No safety backups recorded yet. Click "Download Database File" above to create one.
                      </td>
                    </tr>
                  ) : (
                    safetyBackups.map((b) => (
                      <tr key={b.backupId} className="hover:bg-slate-800/40">
                        <td className="px-5 py-3 text-slate-400">{new Date(b.createdAt).toLocaleString()}</td>
                        <td className="px-5 py-3 uppercase text-[10px] font-semibold text-indigo-400">
                          {b.reason}
                        </td>
                        <td className="px-5 py-3 font-mono text-slate-300">
                          {(b.fileSizeBytes / 1024).toFixed(1)} KB
                        </td>
                        <td className="px-5 py-3 text-[11px] text-slate-400">
                          {b.recordCounts.products} items, {b.recordCounts.sales} sales, {b.recordCounts.customers} customers
                        </td>
                        <td className="px-5 py-3 text-right">
                          <button
                            onClick={() => handleRestoreSafetyBackup(b.backupId)}
                            className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium"
                          >
                            Restore This Snapshot
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Commercial Licensing & Windows Desktop */}
      {activeTab === 'licensing' && license && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Machine Identifier & Status */}
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-100">Machine Hardware Identifier</h4>
                  <p className="text-xs text-slate-400">Unique cryptographic device binding</p>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-sm text-indigo-300 font-bold tracking-wider select-all">
                {license.machineId}
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>Current License Status:</span>
                  <span
                    className={`font-semibold uppercase px-2 py-0.5 rounded text-[10px] ${
                      license.status === 'active'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-950 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    {license.status}
                  </span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Plan Edition:</span>
                  <span className="font-semibold text-slate-100">{license.planType}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Registered To:</span>
                  <span className="text-slate-100">{license.licensedTo}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Valid Until:</span>
                  <span className="text-slate-400">{new Date(license.validUntil).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            {/* Offline Key Activation */}
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 rounded-xl bg-teal-500/10 text-teal-400">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-100">Commercial Activation</h4>
                  <p className="text-xs text-slate-400">Activate license key offline</p>
                </div>
              </div>

              <form onSubmit={handleActivateLicense} className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Licensed Business Name
                  </label>
                  <input
                    type="text"
                    required
                    value={licenseOrgInput}
                    onChange={(e) => setLicenseOrgInput(e.target.value)}
                    placeholder="Your Company Name"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    License Activation Key
                  </label>
                  <input
                    type="text"
                    required
                    value={licenseKeyInput}
                    onChange={(e) => setLicenseKeyInput(e.target.value)}
                    placeholder="BOS-PRO-2035-XXXX-XXXX"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono uppercase text-white"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Example key format: <span className="font-mono text-indigo-400">BOS-PRO-2035-9941</span>
                  </p>
                </div>

                {licenseMessage && (
                  <div className="p-2.5 rounded-xl bg-indigo-950/70 border border-indigo-500/40 text-indigo-300 text-xs">
                    {licenseMessage}
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-bold text-xs text-white shadow-md shadow-indigo-600/30"
                >
                  Activate License Offline
                </button>
              </form>
            </div>
          </div>

          {/* Windows Desktop & Offline Documentation */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <h4 className="font-bold text-sm text-slate-100 flex items-center">
              <Info className="w-4 h-4 text-indigo-400 mr-2" />
              Windows Desktop Deployment & Data Safety Architecture
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-300 leading-relaxed">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <strong className="text-slate-100 block">1. Local Storage Location</strong>
                <p className="text-slate-400">
                  Live SQLite database is always saved outside the installation directory at:
                  <code className="block mt-1 font-mono text-[10px] text-indigo-300 bg-slate-900 p-1.5 rounded">
                    %APPDATA%\BusinessOS-Pro\businessos-pro.sqlite
                  </code>
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <strong className="text-slate-100 block">2. Upgrade Preservation</strong>
                <p className="text-slate-400">
                  Application upgrades, reinstalls, and ordinary uninstalls never touch or delete the AppData database. Your transaction history remains 100% intact.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <strong className="text-slate-100 block">3. Offline-First Guarantee</strong>
                <p className="text-slate-400">
                  Zero cloud telemetry, zero remote dependencies, zero mandatory internet connection. All sales, barcodes, printing, and reports run locally.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
