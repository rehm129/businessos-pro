import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Barcode,
  Plus,
  Minus,
  Trash2,
  DollarSign,
  CreditCard,
  Building,
  User,
  Printer,
  RotateCcw,
  CheckCircle,
  X,
  AlertCircle,
  Sparkles,
  ShoppingBag,
} from 'lucide-react';
import {
  BusinessProfile,
  Category,
  Customer,
  PaymentMethod,
  Product,
  Sale,
  SaleItem,
  User as UserType,
} from '../../types';
import { inventoryService } from '../../services/inventory-service';
import { customerService } from '../../services/customer-service';
import { posService, CheckoutInput } from '../../services/pos-service';

interface CartItem {
  product: Product;
  quantity: number;
  unitPrice: number;
  discountPercent: number;
}

interface PosViewProps {
  business: BusinessProfile | null;
  currentUser: UserType | null;
  onSaleCompleted?: (sale: Sale) => void;
  externalSelectedReceiptSaleId?: string | null;
  onCloseExternalReceipt?: () => void;
  externalSelectedReturnSaleId?: string | null;
  onCloseExternalReturn?: () => void;
}

export const PosView: React.FC<PosViewProps> = ({
  business,
  currentUser,
  onSaleCompleted,
  externalSelectedReceiptSaleId,
  onCloseExternalReceipt,
  externalSelectedReturnSaleId,
  onCloseExternalReturn,
}) => {
  const currency = business?.currencySymbol || '$';
  const taxRate = business?.enableTax ? (business?.taxRatePercent ?? 0) / 100 : 0;
  const allowNegativeStock = Boolean(business?.allowNegativeStock);

  // Products and categories
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);

  // Filters & Cart
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [barcodeInput, setBarcodeInput] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('cust_walkin');

  // Checkout modal state
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [amountPaid, setAmountPaid] = useState<number>(0);
  const [checkoutNotes, setCheckoutNotes] = useState('');
  const [checkoutError, setCheckoutError] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Split payment state
  const [splitCash, setSplitCash] = useState<number>(0);
  const [splitCard, setSplitCard] = useState<number>(0);

  // Receipt Modal state
  const [completedSale, setCompletedSale] = useState<Sale | null>(null);

  // Return Modal state
  const [returnSale, setReturnSale] = useState<Sale | null>(null);
  const [returnQuantities, setReturnQuantities] = useState<Record<string, number>>({});
  const [returnReason, setReturnReason] = useState('Customer returned item');
  const [restockChecked, setRestockChecked] = useState(true);
  const [returnError, setReturnError] = useState('');

  const barcodeInputRef = useRef<HTMLInputElement>(null);

  const loadData = () => {
    setProducts(inventoryService.getProducts());
    setCategories(inventoryService.getCategories());
    setCustomers(customerService.getCustomers());
  };

  useEffect(() => {
    loadData();
  }, []);

  // Handle external receipt trigger from dashboard
  useEffect(() => {
    if (externalSelectedReceiptSaleId) {
      const sale = posService.getSaleWithItems(externalSelectedReceiptSaleId);
      if (sale) {
        setCompletedSale(sale);
      }
    }
  }, [externalSelectedReceiptSaleId]);

  // Handle external return trigger from dashboard
  useEffect(() => {
    if (externalSelectedReturnSaleId) {
      const sale = posService.getSaleWithItems(externalSelectedReturnSaleId);
      if (sale) {
        setReturnSale(sale);
        const initQtys: Record<string, number> = {};
        sale.items?.forEach((i) => {
          initQtys[i.productId] = 0;
        });
        setReturnQuantities(initQtys);
      }
    }
  }, [externalSelectedReturnSaleId]);

  // Barcode entry handler (instant scanner support)
  const handleBarcodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!barcodeInput.trim()) return;
    const found = inventoryService.getProductByBarcodeOrSku(barcodeInput.trim());
    if (found) {
      addToCart(found);
      setBarcodeInput('');
    } else {
      alert(`No product found with Barcode or SKU "${barcodeInput.trim()}".`);
    }
  };

  // Add to cart
  const addToCart = (product: Product) => {
    if (!allowNegativeStock && product.currentStock <= 0) {
      alert(`Cannot add "${product.name}". Available stock is 0 and negative inventory is disabled.`);
      return;
    }

    setCart((prev) => {
      const existingIdx = prev.findIndex((item) => item.product.id === product.id);
      if (existingIdx >= 0) {
        const item = prev[existingIdx];
        if (!allowNegativeStock && item.quantity + 1 > product.currentStock) {
          alert(`Cannot add more than available stock (${product.currentStock}) for "${product.name}".`);
          return prev;
        }
        const updated = [...prev];
        updated[existingIdx] = {
          ...item,
          quantity: item.quantity + 1,
        };
        return updated;
      } else {
        return [
          ...prev,
          {
            product,
            quantity: 1,
            unitPrice: product.sellingPrice,
            discountPercent: 0,
          },
        ];
      }
    });
  };

  const updateQuantity = (productId: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(productId);
      return;
    }

    const prod = products.find((p) => p.id === productId);
    if (!allowNegativeStock && prod && newQty > prod.currentStock) {
      alert(`Requested quantity (${newQty}) exceeds current stock (${prod.currentStock}).`);
      return;
    }

    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity: newQty } : item))
    );
  };

  const updateDiscount = (productId: string, discPercent: number) => {
    const clamped = Math.max(0, Math.min(100, discPercent));
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, discountPercent: clamped } : item))
    );
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Cart Totals Calculation
  const subtotal = cart.reduce((sum, item) => {
    const gross = item.unitPrice * item.quantity;
    const discount = (gross * item.discountPercent) / 100;
    return sum + (gross - discount);
  }, 0);

  const discountTotal = cart.reduce((sum, item) => {
    const gross = item.unitPrice * item.quantity;
    return sum + (gross * item.discountPercent) / 100;
  }, 0);

  const taxTotal = subtotal * taxRate;
  const grandTotal = subtotal + taxTotal;

  // Open Checkout
  const handleOpenCheckout = () => {
    if (cart.length === 0) return;
    setAmountPaid(grandTotal);
    setSplitCash(Number((grandTotal / 2).toFixed(2)));
    setSplitCard(Number((grandTotal - Number((grandTotal / 2).toFixed(2))).toFixed(2)));
    setCheckoutError('');
    setShowCheckoutModal(true);
  };

  // Submit Sale Checkout
  const handleConfirmCheckout = () => {
    setCheckoutError('');
    setIsProcessing(true);

    try {
      const splits =
        paymentMethod === 'split'
          ? [
              { method: 'cash' as PaymentMethod, amount: splitCash },
              { method: 'card' as PaymentMethod, amount: splitCard },
            ]
          : undefined;

      const paidVal = paymentMethod === 'split' ? splitCash + splitCard : amountPaid;

      if (paidVal < grandTotal && paymentMethod !== 'store_credit') {
        throw new Error(`Amount paid (${paidVal.toFixed(2)}) is less than total (${grandTotal.toFixed(2)}).`);
      }

      const input: CheckoutInput = {
        customerId: selectedCustomerId !== 'cust_walkin' ? selectedCustomerId : undefined,
        items: cart.map((i) => ({
          productId: i.product.id,
          quantity: i.quantity,
          unitPrice: i.unitPrice,
          discountPercent: i.discountPercent,
        })),
        paymentMethod,
        splits,
        amountPaid: paidVal,
        notes: checkoutNotes,
        cashierId: currentUser?.id || 'usr_cashier',
        cashierName: currentUser?.displayName || 'Cashier',
      };

      const sale = posService.checkout(input);
      setCompletedSale(sale);
      setShowCheckoutModal(false);
      clearCart();
      loadData();
      if (onSaleCompleted) {
        onSaleCompleted(sale);
      }
    } catch (err: any) {
      setCheckoutError(err.message || 'Checkout failed.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Process Return
  const handleProcessReturn = () => {
    if (!returnSale) return;
    setReturnError('');

    try {
      const itemsToReturn = Object.entries(returnQuantities)
        .filter(([_, qty]) => qty > 0)
        .map(([productId, quantity]) => ({ productId, quantity }));

      if (itemsToReturn.length === 0) {
        throw new Error('Please select at least one item quantity to refund.');
      }

      posService.processReturn({
        saleId: returnSale.id,
        items: itemsToReturn,
        reason: returnReason,
        restockItems: restockChecked,
        processedBy: currentUser?.displayName || 'Admin',
      });

      alert('Return processed successfully. Stock and financials reconciled.');
      setReturnSale(null);
      if (onCloseExternalReturn) onCloseExternalReturn();
      loadData();
    } catch (err: any) {
      setReturnError(err.message || 'Failed to process return.');
    }
  };

  const filteredProducts = products.filter((p) => {
    if (selectedCategory !== 'all' && p.categoryId !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.barcode.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="h-[calc(100vh-5.5rem)] flex flex-col lg:flex-row gap-4 text-white overflow-hidden select-none">
      {/* Left: Product Catalog & Fast Barcode Search */}
      <div className="flex-1 flex flex-col bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        {/* Top Search & Barcode Bar */}
        <div className="p-4 border-b border-slate-800 space-y-3 bg-slate-900/90">
          <div className="flex items-center gap-3">
            {/* Barcode Scanner Input */}
            <form onSubmit={handleBarcodeSubmit} className="flex-1 relative">
              <Barcode className="w-5 h-5 text-indigo-400 absolute left-3 top-2.5" />
              <input
                ref={barcodeInputRef}
                type="text"
                placeholder="Scan barcode or type SKU & hit Enter..."
                value={barcodeInput}
                onChange={(e) => setBarcodeInput(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 focus:border-indigo-500 rounded-xl pl-10 pr-4 py-2 text-sm text-slate-100 placeholder-slate-400 focus:outline-hidden font-mono"
              />
            </form>

            {/* Keyword Search */}
            <div className="flex-1 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search products by title..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 focus:border-indigo-500 rounded-xl pl-9 pr-4 py-2 text-sm text-slate-100 placeholder-slate-400 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                selectedCategory === 'all'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              All Categories
            </button>
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCategory(c.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                  selectedCategory === c.id
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="flex-1 overflow-y-auto p-4">
          {filteredProducts.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400">
              <ShoppingBag className="w-12 h-12 text-slate-600 mb-2" />
              <p className="text-sm">No items found matching your filter</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
              {filteredProducts.map((p) => {
                const isLow = p.currentStock <= p.minStockThreshold;
                const isOutOfStock = p.currentStock <= 0;

                return (
                  <div
                    key={p.id}
                    onClick={() => addToCart(p)}
                    className="bg-slate-950/70 border border-slate-800 hover:border-indigo-500/70 rounded-xl p-3.5 flex flex-col justify-between cursor-pointer transition transform active:scale-98 group"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <span className="text-[10px] font-mono text-slate-400 truncate">{p.sku}</span>
                        <span
                          className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                            isOutOfStock
                              ? 'bg-rose-950 text-rose-400 border border-rose-500/30'
                              : isLow
                              ? 'bg-amber-950 text-amber-400 border border-amber-500/30'
                              : 'bg-slate-800 text-emerald-400'
                          }`}
                        >
                          {p.currentStock} {p.unit}
                        </span>
                      </div>
                      <h4 className="font-medium text-xs text-slate-100 group-hover:text-indigo-300 transition line-clamp-2 mt-1">
                        {p.name}
                      </h4>
                    </div>

                    <div className="mt-3 flex items-center justify-between border-t border-slate-800/80 pt-2">
                      <span className="font-mono font-bold text-sm text-indigo-400">
                        {currency}{p.sellingPrice.toFixed(2)}
                      </span>
                      <span className="p-1 rounded-md bg-indigo-600/20 text-indigo-400 group-hover:bg-indigo-600 group-hover:text-white transition">
                        <Plus className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Right: Cart & Checkout Register */}
      <div className="w-full lg:w-96 flex flex-col bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shrink-0">
        {/* Customer Select Header */}
        <div className="p-4 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs text-slate-300">
            <User className="w-4 h-4 text-indigo-400" />
            <select
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-hidden"
            >
              <option value="cust_walkin">Walk-in Retail Customer</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.phone})
                </option>
              ))}
            </select>
          </div>

          {cart.length > 0 && (
            <button
              onClick={clearCart}
              title="Empty entire cart"
              className="text-xs text-slate-400 hover:text-rose-400 transition"
            >
              Clear
            </button>
          )}
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400">
              <ShoppingBag className="w-10 h-10 text-slate-700 mb-2" />
              <p className="text-xs">Cart is empty</p>
              <p className="text-[11px] text-slate-400 mt-1">Scan barcode or click items to add</p>
            </div>
          ) : (
            cart.map((item) => {
              const lineGross = item.unitPrice * item.quantity;
              const lineDiscount = (lineGross * item.discountPercent) / 100;
              const lineNet = lineGross - lineDiscount;

              return (
                <div
                  key={item.product.id}
                  className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h5 className="text-xs font-semibold text-slate-100 line-clamp-1">
                        {item.product.name}
                      </h5>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {currency}{item.unitPrice.toFixed(2)} / {item.product.unit}
                      </span>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.product.id)}
                      className="text-slate-400 hover:text-rose-400 p-0.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="mt-2.5 flex items-center justify-between">
                    {/* Stepper */}
                    <div className="flex items-center space-x-1.5 bg-slate-900 border border-slate-800 rounded-lg p-0.5">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-8 text-center font-mono text-xs font-bold text-slate-100">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Discount Control */}
                    <div className="flex items-center space-x-1 text-[11px] text-slate-400">
                      <span>Disc:</span>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={item.discountPercent || ''}
                        placeholder="0"
                        onChange={(e) =>
                          updateDiscount(item.product.id, parseFloat(e.target.value) || 0)
                        }
                        className="w-10 bg-slate-900 border border-slate-800 rounded px-1 py-0.5 text-center font-mono text-slate-200"
                      />
                      <span>%</span>
                    </div>

                    {/* Line Total */}
                    <span className="font-mono font-bold text-xs text-indigo-300">
                      {currency}{lineNet.toFixed(2)}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Cart Financial Summary & Checkout Button */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 space-y-3">
          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-400">
              <span>Subtotal</span>
              <span className="font-mono text-slate-200">
                {currency}{subtotal.toFixed(2)}
              </span>
            </div>
            {discountTotal > 0 && (
              <div className="flex justify-between text-amber-400">
                <span>Discounts</span>
                <span className="font-mono">- {currency}{discountTotal.toFixed(2)}</span>
              </div>
            )}
            {business?.enableTax && (
              <div className="flex justify-between text-slate-400">
                <span>Tax ({business.taxRatePercent}%)</span>
                <span className="font-mono text-slate-200">
                  {currency}{taxTotal.toFixed(2)}
                </span>
              </div>
            )}
            <div className="border-t border-slate-800 pt-2 flex justify-between text-base font-bold text-white">
              <span>Grand Total</span>
              <span className="font-mono text-emerald-400">
                {currency}{grandTotal.toFixed(2)}
              </span>
            </div>
          </div>

          <button
            disabled={cart.length === 0}
            onClick={handleOpenCheckout}
            className={`w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center space-x-2 transition shadow-lg ${
              cart.length === 0
                ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20 active:scale-98'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>Charge {currency}{grandTotal.toFixed(2)} (F4)</span>
          </button>
        </div>
      </div>

      {/* Checkout Modal */}
      {showCheckoutModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100">Finalize Payment & Checkout</h3>
                <p className="text-xs text-slate-400">Select payment method & tender amount</p>
              </div>
              <button
                onClick={() => setShowCheckoutModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4">
              {/* Payment Methods Tabs */}
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-2">
                  Payment Method
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'cash', label: 'Cash', icon: DollarSign },
                    { id: 'card', label: 'Card / POS', icon: CreditCard },
                    { id: 'bank_transfer', label: 'Transfer', icon: Building },
                    { id: 'store_credit', label: 'Due / Credit', icon: User },
                  ].map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPaymentMethod(m.id as PaymentMethod)}
                      className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition text-xs font-medium ${
                        paymentMethod === m.id
                          ? 'bg-indigo-600 border-indigo-500 text-white shadow-sm'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <m.icon className="w-4 h-4" />
                      <span>{m.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Total Due Display */}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <span className="text-sm font-semibold text-slate-400">Total Amount Due</span>
                <span className="text-xl font-bold font-mono text-emerald-400">
                  {currency}{grandTotal.toFixed(2)}
                </span>
              </div>

              {/* Amount Tendered Input */}
              {paymentMethod === 'cash' && (
                <div className="space-y-2">
                  <label className="block text-xs font-semibold uppercase text-slate-400">
                    Amount Received from Customer
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={amountPaid || ''}
                    onChange={(e) => setAmountPaid(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 font-mono text-lg text-white font-bold focus:outline-hidden focus:border-indigo-500"
                  />

                  {/* Quick Cash Buttons */}
                  <div className="flex gap-2">
                    {[
                      { label: 'Exact', val: grandTotal },
                      { label: '+10', val: Math.ceil(grandTotal / 10) * 10 },
                      { label: '+50', val: Math.ceil(grandTotal / 50) * 50 },
                      { label: '+100', val: Math.ceil(grandTotal / 100) * 100 },
                    ].map((btn, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setAmountPaid(btn.val)}
                        className="flex-1 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-300"
                      >
                        {btn.label === 'Exact' ? 'Exact' : `${currency}${btn.val}`}
                      </button>
                    ))}
                  </div>

                  {amountPaid >= grandTotal && (
                    <div className="p-2.5 rounded-lg bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex justify-between font-semibold">
                      <span>Change to Return:</span>
                      <span className="font-mono text-sm">
                        {currency}{(amountPaid - grandTotal).toFixed(2)}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Split Payment Options */}
              {business?.enableSplitPayments && (
                <div className="pt-2 border-t border-slate-800">
                  <label className="flex items-center space-x-2 text-xs text-slate-400 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={paymentMethod === 'split'}
                      onChange={(e) => setPaymentMethod(e.target.checked ? 'split' : 'cash')}
                      className="rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0"
                    />
                    <span>Split Payment (Cash + Card)</span>
                  </label>

                  {paymentMethod === 'split' && (
                    <div className="grid grid-cols-2 gap-3 mt-2.5">
                      <div>
                        <span className="text-[11px] text-slate-400">Cash Portion</span>
                        <input
                          type="number"
                          step="0.01"
                          value={splitCash}
                          onChange={(e) => setSplitCash(parseFloat(e.target.value) || 0)}
                          className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-white mt-1"
                        />
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400">Card Portion</span>
                        <input
                          type="number"
                          step="0.01"
                          value={splitCard}
                          onChange={(e) => setSplitCard(parseFloat(e.target.value) || 0)}
                          className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-white mt-1"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Notes */}
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Optional Sale Notes
                </label>
                <input
                  type="text"
                  placeholder="Order note, table number, PO ref..."
                  value={checkoutNotes}
                  onChange={(e) => setCheckoutNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden"
                />
              </div>

              {checkoutError && (
                <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/50 text-rose-300 text-xs">
                  {checkoutError}
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCheckoutModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isProcessing}
                  onClick={handleConfirmCheckout}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-lg shadow-indigo-600/30 active:scale-98"
                >
                  {isProcessing ? 'Recording Sale...' : 'Complete & Generate Receipt'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Printable Thermal Receipt Modal */}
      {completedSale && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-6 text-white shadow-2xl flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold text-emerald-400 flex items-center">
                <CheckCircle className="w-4 h-4 mr-1.5" />
                Sale Recorded Successfully
              </span>
              <button
                onClick={() => {
                  setCompletedSale(null);
                  if (onCloseExternalReceipt) onCloseExternalReceipt();
                }}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Receipt Preview Box (Thermal 80mm format) */}
            <div className="my-4 bg-white text-slate-900 p-5 rounded-lg shadow-inner font-mono text-xs leading-relaxed space-y-3">
              <div className="text-center space-y-0.5 border-b border-dashed border-slate-400 pb-3">
                <h4 className="font-bold text-base uppercase tracking-wider">{business?.name}</h4>
                <p className="text-[11px] text-slate-600">{business?.address}</p>
                <p className="text-[11px] text-slate-600">Tel: {business?.phone}</p>
                {business?.taxNumber && (
                  <p className="text-[10px] text-slate-500">Tax Reg: {business.taxNumber}</p>
                )}
              </div>

              <div className="text-[10px] space-y-0.5 text-slate-600 border-b border-dashed border-slate-400 pb-2">
                <div className="flex justify-between">
                  <span>Receipt #:</span>
                  <span className="font-bold text-slate-900">{completedSale.receiptNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span>Date/Time:</span>
                  <span>{new Date(completedSale.createdAt).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Cashier:</span>
                  <span>{completedSale.cashierName}</span>
                </div>
                <div className="flex justify-between">
                  <span>Customer:</span>
                  <span>{completedSale.customerName || 'Walk-in'}</span>
                </div>
              </div>

              {/* Items Table */}
              <div className="space-y-1.5 border-b border-dashed border-slate-400 pb-2 text-[11px]">
                {completedSale.items?.map((item, idx) => (
                  <div key={idx} className="flex justify-between items-start">
                    <div className="pr-2">
                      <div className="font-semibold text-slate-900">{item.productName}</div>
                      <div className="text-[10px] text-slate-500">
                        {item.quantity} x {currency}{item.unitPrice.toFixed(2)}
                      </div>
                    </div>
                    <span className="font-bold font-mono text-slate-900">
                      {currency}{item.total.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="space-y-1 text-[11px] text-slate-700">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>{currency}{completedSale.subtotal.toFixed(2)}</span>
                </div>
                {completedSale.discountTotal > 0 && (
                  <div className="flex justify-between text-slate-500">
                    <span>Discount</span>
                    <span>- {currency}{completedSale.discountTotal.toFixed(2)}</span>
                  </div>
                )}
                {completedSale.taxTotal > 0 && (
                  <div className="flex justify-between">
                    <span>Tax</span>
                    <span>{currency}{completedSale.taxTotal.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-bold text-slate-900 pt-1 border-t border-slate-300">
                  <span>Total</span>
                  <span>{currency}{completedSale.grandTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[10px] pt-1">
                  <span className="uppercase">{completedSale.paymentMethod} Paid:</span>
                  <span>{currency}{completedSale.amountPaid.toFixed(2)}</span>
                </div>
                {completedSale.changeGiven > 0 && (
                  <div className="flex justify-between text-[10px] font-semibold text-slate-900">
                    <span>Change Returned:</span>
                    <span>{currency}{completedSale.changeGiven.toFixed(2)}</span>
                  </div>
                )}
              </div>

              <div className="text-center pt-2 text-[10px] text-slate-500 border-t border-dashed border-slate-400">
                <p>{business?.receiptFooterMessage || 'Thank you for your visit!'}</p>
                <p className="mt-1 font-mono tracking-widest text-[9px]">*** CUSTOMER COPY ***</p>
              </div>
            </div>

            {/* Print & Close */}
            <div className="flex items-center space-x-3">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-semibold text-xs text-white flex items-center justify-center space-x-2 shadow-md"
              >
                <Printer className="w-4 h-4" />
                <span>Print Receipt</span>
              </button>
              <button
                onClick={() => {
                  setCompletedSale(null);
                  if (onCloseExternalReceipt) onCloseExternalReceipt();
                }}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
              >
                Done / Next Sale
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sale Return / Refund Modal */}
      {returnSale && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <RotateCcw className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-base font-bold text-slate-100">Process Sale Return / Refund</h3>
                  <p className="text-xs text-slate-400">Receipt: {returnSale.receiptNumber}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setReturnSale(null);
                  if (onCloseExternalReturn) onCloseExternalReturn();
                }}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3.5">
              <p className="text-xs text-slate-300 font-medium">
                Specify quantities to return for each item:
              </p>

              <div className="space-y-2 max-h-48 overflow-y-auto">
                {returnSale.items?.map((item) => (
                  <div
                    key={item.productId}
                    className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold text-slate-200">{item.productName}</div>
                      <div className="text-[10px] text-slate-400">
                        Sold: {item.quantity} @ {currency}{item.unitPrice.toFixed(2)}
                      </div>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <span className="text-[11px] text-slate-400">Return:</span>
                      <input
                        type="number"
                        min="0"
                        max={item.quantity}
                        value={returnQuantities[item.productId] ?? 0}
                        onChange={(e) =>
                          setReturnQuantities({
                            ...returnQuantities,
                            [item.productId]: Math.min(item.quantity, Math.max(0, parseInt(e.target.value) || 0)),
                          })
                        }
                        className="w-12 bg-slate-900 border border-slate-700 rounded px-1.5 py-1 text-center font-mono text-white"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Reason for Return
                </label>
                <input
                  type="text"
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden"
                />
              </div>

              <label className="flex items-center space-x-2 text-xs text-slate-300 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={restockChecked}
                  onChange={(e) => setRestockChecked(e.target.checked)}
                  className="rounded bg-slate-950 border-slate-700 text-indigo-600 focus:ring-0"
                />
                <span>Restock returned items back into store inventory</span>
              </label>

              {returnError && (
                <div className="p-2.5 rounded bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs">
                  {returnError}
                </div>
              )}

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setReturnSale(null);
                    if (onCloseExternalReturn) onCloseExternalReturn();
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleProcessReturn}
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-xs font-bold text-white shadow-md shadow-amber-600/30"
                >
                  Process Return & Refund
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
