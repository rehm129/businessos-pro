import React, { useState, useEffect } from 'react';
import {
  Truck,
  Plus,
  Search,
  CheckCircle,
  Clock,
  DollarSign,
  PackageCheck,
  Building2,
  X,
  FileText,
  AlertCircle,
} from 'lucide-react';
import { BusinessProfile, Product, Purchase, Supplier, User } from '../../types';
import { supplierService, CreateSupplierInput, CreatePurchaseInput } from '../../services/supplier-service';
import { inventoryService } from '../../services/inventory-service';

interface PurchasesViewProps {
  business: BusinessProfile | null;
  currentUser: User | null;
}

export const PurchasesView: React.FC<PurchasesViewProps> = ({ business, currentUser }) => {
  const currency = business?.currencySymbol || '$';

  const [activeTab, setActiveTab] = useState<'orders' | 'suppliers'>('orders');
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState('');

  // Modals
  const [showAddSupplierModal, setShowAddSupplierModal] = useState(false);
  const [supName, setSupName] = useState('');
  const [supContact, setSupContact] = useState('');
  const [supEmail, setSupEmail] = useState('');
  const [supPhone, setSupPhone] = useState('');
  const [supAddress, setSupAddress] = useState('');
  const [supTaxId, setSupTaxId] = useState('');

  const [showAddPurchaseModal, setShowAddPurchaseModal] = useState(false);
  const [poSupplierId, setPoSupplierId] = useState('');
  const [poOrderDate, setPoOrderDate] = useState(new Date().toISOString().slice(0, 10));
  const [poStatus, setPoStatus] = useState<'ordered' | 'received'>('received');
  const [poItems, setPoItems] = useState<{ productId: string; quantity: number; unitCost: number }[]>([]);
  const [poAmountPaid, setPoAmountPaid] = useState<number>(0);
  const [poNotes, setPoNotes] = useState('');
  const [poError, setPoError] = useState('');

  const [viewingPurchase, setViewingPurchase] = useState<Purchase | null>(null);

  const refresh = () => {
    setPurchases(supplierService.getPurchases(50));
    setSuppliers(supplierService.getSuppliers(search));
    setProducts(inventoryService.getProducts());
  };

  useEffect(() => {
    refresh();
  }, [search]);

  const handleCreateSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const input: CreateSupplierInput = {
        name: supName,
        contactPerson: supContact,
        email: supEmail,
        phone: supPhone,
        address: supAddress,
        taxId: supTaxId,
      };
      supplierService.createSupplier(input);
      setShowAddSupplierModal(false);
      setSupName('');
      setSupContact('');
      setSupEmail('');
      setSupPhone('');
      setSupAddress('');
      setSupTaxId('');
      refresh();
    } catch (err: any) {
      alert(err.message || 'Failed to create supplier.');
    }
  };

  const handleOpenAddPurchase = () => {
    if (suppliers.length === 0) {
      alert('Please add at least one supplier before creating a purchase order.');
      setShowAddSupplierModal(true);
      return;
    }
    setPoSupplierId(suppliers[0]?.id || '');
    setPoOrderDate(new Date().toISOString().slice(0, 10));
    setPoStatus('received');
    setPoItems(
      products.length > 0
        ? [{ productId: products[0].id, quantity: 10, unitCost: products[0].purchaseCost }]
        : []
    );
    setPoAmountPaid(0);
    setPoNotes('');
    setPoError('');
    setShowAddPurchaseModal(true);
  };

  const handleAddItemToPo = () => {
    if (products.length === 0) return;
    setPoItems((prev) => [
      ...prev,
      { productId: products[0].id, quantity: 10, unitCost: products[0].purchaseCost },
    ]);
  };

  const handleRemovePoItem = (index: number) => {
    setPoItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleCreatePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    setPoError('');
    try {
      if (poItems.length === 0) {
        throw new Error('Please add at least one product line item.');
      }

      const input: CreatePurchaseInput = {
        supplierId: poSupplierId,
        orderDate: poOrderDate,
        items: poItems,
        status: poStatus,
        amountPaid: poAmountPaid,
        notes: poNotes,
        receivedByName: currentUser?.displayName || 'Admin',
      };

      supplierService.createPurchase(input);
      setShowAddPurchaseModal(false);
      refresh();
    } catch (err: any) {
      setPoError(err.message || 'Failed to create purchase.');
    }
  };

  const handleReceiveStock = (purchaseId: string) => {
    if (!confirm('Receive this purchase order and replenish inventory on hand?')) return;
    try {
      supplierService.receiveStock(purchaseId, currentUser?.displayName || 'Admin');
      refresh();
    } catch (err: any) {
      alert(err.message || 'Failed to receive stock.');
    }
  };

  const handleViewPurchaseDetails = (id: string) => {
    const full = supplierService.getPurchaseWithItems(id);
    if (full) {
      setViewingPurchase(full);
    }
  };

  return (
    <div className="space-y-6 text-white pb-10">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">Purchases & Supplier Management</h2>
            <p className="text-xs text-slate-400">
              Manage vendor catalogs, purchase orders, inventory receiving, and payable balances.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={() => setShowAddSupplierModal(true)}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200"
          >
            <Building2 className="w-3.5 h-3.5 text-slate-400" />
            <span>+ New Supplier</span>
          </button>

          <button
            onClick={handleOpenAddPurchase}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-semibold text-xs text-white shadow-md shadow-indigo-600/30"
          >
            <Plus className="w-4 h-4" />
            <span>Create Purchase Order</span>
          </button>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
            activeTab === 'orders'
              ? 'bg-indigo-600 text-white'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          Purchase Orders & Stock Received
        </button>
        <button
          onClick={() => setActiveTab('suppliers')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
            activeTab === 'suppliers'
              ? 'bg-indigo-600 text-white'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          Suppliers Directory ({suppliers.length})
        </button>
      </div>

      {/* Content for Orders */}
      {activeTab === 'orders' ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="px-5 py-3.5">PO Number</th>
                  <th className="px-5 py-3.5">Supplier</th>
                  <th className="px-5 py-3.5">Order Date</th>
                  <th className="px-5 py-3.5 text-center">Status</th>
                  <th className="px-5 py-3.5 text-right">Grand Total</th>
                  <th className="px-5 py-3.5 text-right">Amount Paid</th>
                  <th className="px-5 py-3.5 text-center">Payment Status</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {purchases.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-5 py-10 text-center text-slate-400">
                      No purchase orders recorded yet.
                    </td>
                  </tr>
                ) : (
                  purchases.map((po) => (
                    <tr key={po.id} className="hover:bg-slate-800/40 transition">
                      <td className="px-5 py-3.5 font-mono text-indigo-400 font-semibold">
                        {po.purchaseNumber}
                      </td>
                      <td className="px-5 py-3.5 text-slate-100 font-medium">{po.supplierName}</td>
                      <td className="px-5 py-3.5 text-slate-400">{po.orderDate}</td>
                      <td className="px-5 py-3.5 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                            po.status === 'received'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                              : 'bg-amber-950 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          {po.status}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right font-mono font-bold text-slate-100">
                        {currency}{po.grandTotal.toFixed(2)}
                      </td>
                      <td className="px-5 py-3.5 text-right font-mono text-slate-300">
                        {currency}{po.amountPaid.toFixed(2)}
                      </td>
                      <td className="px-5 py-3.5 text-center">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                            po.paymentStatus === 'paid'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-950 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {po.paymentStatus}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-right space-x-2">
                        {po.status === 'ordered' && (
                          <button
                            onClick={() => handleReceiveStock(po.id)}
                            className="px-2 py-1 rounded bg-emerald-600/20 hover:bg-emerald-600 text-emerald-400 hover:text-white text-[11px] font-semibold transition"
                          >
                            Receive Stock
                          </button>
                        )}
                        <button
                          onClick={() => handleViewPurchaseDetails(po.id)}
                          className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Content for Suppliers */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="px-5 py-3.5">Company Name</th>
                  <th className="px-5 py-3.5">Contact Person</th>
                  <th className="px-5 py-3.5">Phone & Email</th>
                  <th className="px-5 py-3.5">Address</th>
                  <th className="px-5 py-3.5 text-right">Total Purchased</th>
                  <th className="px-5 py-3.5 text-right">Outstanding Due</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {suppliers.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-800/40 transition">
                    <td className="px-5 py-3.5 text-slate-100 font-bold">{s.name}</td>
                    <td className="px-5 py-3.5 text-slate-300">{s.contactPerson || '-'}</td>
                    <td className="px-5 py-3.5 text-slate-400">
                      <div>{s.phone}</div>
                      <div className="text-[10px]">{s.email || '-'}</div>
                    </td>
                    <td className="px-5 py-3.5 text-slate-400 truncate max-w-xs">{s.address || '-'}</td>
                    <td className="px-5 py-3.5 text-right font-mono text-slate-300">
                      {currency}{s.totalPurchased.toFixed(2)}
                    </td>
                    <td className="px-5 py-3.5 text-right font-mono font-bold text-rose-400">
                      {currency}{s.outstandingBalance.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add Supplier Modal */}
      {showAddSupplierModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100">Add New Supplier Profile</h3>
              <button onClick={() => setShowAddSupplierModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSupplier} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Supplier Company Name *
                </label>
                <input
                  type="text"
                  required
                  value={supName}
                  onChange={(e) => setSupName(e.target.value)}
                  placeholder="e.g., Apex Wholesale Distributors"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Contact Person
                </label>
                <input
                  type="text"
                  value={supContact}
                  onChange={(e) => setSupContact(e.target.value)}
                  placeholder="e.g., David Miller"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Phone *
                  </label>
                  <input
                    type="text"
                    required
                    value={supPhone}
                    onChange={(e) => setSupPhone(e.target.value)}
                    placeholder="+1 555-0192"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={supEmail}
                    onChange={(e) => setSupEmail(e.target.value)}
                    placeholder="sales@vendor.com"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Warehouse / Physical Address
                </label>
                <input
                  type="text"
                  value={supAddress}
                  onChange={(e) => setSupAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddSupplierModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-md shadow-indigo-600/30"
                >
                  Save Supplier
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create Purchase Order Modal */}
      {showAddPurchaseModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 text-white shadow-2xl flex flex-col max-h-[90vh]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100">Create Purchase Order / Receive Stock</h3>
              <button onClick={() => setShowAddPurchaseModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePurchase} className="flex-1 overflow-y-auto mt-4 space-y-4 pr-1">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Select Supplier *
                  </label>
                  <select
                    value={poSupplierId}
                    onChange={(e) => setPoSupplierId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-hidden"
                  >
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Order Date
                  </label>
                  <input
                    type="date"
                    required
                    value={poOrderDate}
                    onChange={(e) => setPoOrderDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Stock Receiving Status
                  </label>
                  <select
                    value={poStatus}
                    onChange={(e) => setPoStatus(e.target.value as 'ordered' | 'received')}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-hidden"
                  >
                    <option value="received">Received (Replenish stock now)</option>
                    <option value="ordered">Ordered (Awaiting delivery)</option>
                  </select>
                </div>
              </div>

              {/* Items Line list */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold uppercase text-slate-400">
                    Product Line Items
                  </label>
                  <button
                    type="button"
                    onClick={handleAddItemToPo}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
                  >
                    + Add Item Line
                  </button>
                </div>

                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {poItems.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-3 text-xs"
                    >
                      <select
                        value={item.productId}
                        onChange={(e) => {
                          const prod = products.find((p) => p.id === e.target.value);
                          const updated = [...poItems];
                          updated[idx].productId = e.target.value;
                          if (prod) updated[idx].unitCost = prod.purchaseCost;
                          setPoItems(updated);
                        }}
                        className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                      >
                        {products.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.name} ({p.sku})
                          </option>
                        ))}
                      </select>

                      <div className="flex items-center space-x-1">
                        <span className="text-[10px] text-slate-400">Qty:</span>
                        <input
                          type="number"
                          min="1"
                          required
                          value={item.quantity}
                          onChange={(e) => {
                            const updated = [...poItems];
                            updated[idx].quantity = parseFloat(e.target.value) || 1;
                            setPoItems(updated);
                          }}
                          className="w-16 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-center font-mono text-white"
                        />
                      </div>

                      <div className="flex items-center space-x-1">
                        <span className="text-[10px] text-slate-400">Cost:</span>
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          required
                          value={item.unitCost}
                          onChange={(e) => {
                            const updated = [...poItems];
                            updated[idx].unitCost = parseFloat(e.target.value) || 0;
                            setPoItems(updated);
                          }}
                          className="w-20 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-right font-mono text-white"
                        />
                      </div>

                      <span className="w-20 text-right font-mono font-bold text-indigo-300">
                        {currency}{(item.quantity * item.unitCost).toFixed(2)}
                      </span>

                      <button
                        type="button"
                        onClick={() => handleRemovePoItem(idx)}
                        className="text-slate-400 hover:text-rose-400 p-1"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total & Payment */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Amount Paid to Supplier Now ({currency})
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={poAmountPaid || ''}
                    placeholder="0.00"
                    onChange={(e) => setPoAmountPaid(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Notes / Reference
                  </label>
                  <input
                    type="text"
                    value={poNotes}
                    onChange={(e) => setPoNotes(e.target.value)}
                    placeholder="e.g. Invoice #9941"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              {poError && (
                <div className="p-2.5 rounded-xl bg-rose-950/70 border border-rose-500/50 text-rose-300 text-xs">
                  {poError}
                </div>
              )}

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddPurchaseModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-md shadow-indigo-600/30"
                >
                  Confirm & Save Purchase
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Viewing Purchase Order Details Modal */}
      {viewingPurchase && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100">{viewingPurchase.purchaseNumber}</h3>
                <p className="text-xs text-slate-400">Supplier: {viewingPurchase.supplierName}</p>
              </div>
              <button onClick={() => setViewingPurchase(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Order Date:</span>
                <span className="text-slate-200">{viewingPurchase.orderDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Status:</span>
                <span className="uppercase text-emerald-400 font-semibold">{viewingPurchase.status}</span>
              </div>

              <div className="border-t border-b border-slate-800 py-2 space-y-1.5">
                <span className="text-[11px] font-semibold uppercase text-slate-400">Items Received:</span>
                {viewingPurchase.items?.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-slate-300">
                    <span>{item.quantity}x {item.productName}</span>
                    <span className="font-mono text-slate-200">{currency}{item.totalCost.toFixed(2)}</span>
                  </div>
                ))}
              </div>

              <div className="flex justify-between font-bold text-sm text-slate-100 pt-1">
                <span>Grand Total:</span>
                <span className="font-mono text-emerald-400">{currency}{viewingPurchase.grandTotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Amount Paid:</span>
                <span className="font-mono">{currency}{viewingPurchase.amountPaid.toFixed(2)}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setViewingPurchase(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
