import React from 'react';
import {
  LayoutDashboard,
  ShoppingCart,
  Boxes,
  Truck,
  Users,
  ReceiptText,
  CircleDollarSign,
  BarChart3,
  Shield,
  Settings,
  HelpCircle,
} from 'lucide-react';
import { UserRole } from '../../types';

export type NavTab =
  | 'dashboard'
  | 'pos'
  | 'inventory'
  | 'purchases'
  | 'customers'
  | 'expenses'
  | 'cash-register'
  | 'reports'
  | 'users'
  | 'settings';

interface SidebarProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  userRole?: UserRole;
  lowStockCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onTabChange,
  userRole = 'admin',
  lowStockCount = 0,
}) => {
  const isCashier = userRole === 'cashier';

  const navItems: {
    id: NavTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    shortcut?: string;
    adminOnly?: boolean;
  }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, shortcut: 'F1' },
    { id: 'pos', label: 'POS Register', icon: ShoppingCart, shortcut: 'F2' },
    { id: 'inventory', label: 'Inventory & Items', icon: Boxes, badge: lowStockCount, shortcut: 'F3' },
    { id: 'purchases', label: 'Purchases & Suppliers', icon: Truck, adminOnly: true },
    { id: 'customers', label: 'Customers & Due', icon: Users },
    { id: 'expenses', label: 'Expenses', icon: ReceiptText, adminOnly: true },
    { id: 'cash-register', label: 'Cash Reconciliation', icon: CircleDollarSign },
    { id: 'reports', label: 'Reports & Analytics', icon: BarChart3, adminOnly: true },
    { id: 'users', label: 'Users & Roles', icon: Shield, adminOnly: true },
    { id: 'settings', label: 'Settings & Backups', icon: Settings, adminOnly: true },
  ];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800 flex flex-col justify-between shrink-0 select-none">
      <div className="p-3 space-y-1">
        <div className="px-3 py-2 text-[11px] font-semibold tracking-wider uppercase text-slate-400">
          Main Navigation
        </div>

        {navItems.map((item) => {
          if (item.adminOnly && isCashier) {
            return null;
          }

          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <div className="flex items-center space-x-3">
                <item.icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>

              <div className="flex items-center space-x-1.5">
                {item.badge && item.badge > 0 ? (
                  <span className="px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-rose-500 text-white">
                    {item.badge}
                  </span>
                ) : null}

                {item.shortcut && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded ${
                      isActive ? 'bg-indigo-700 text-indigo-100' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {item.shortcut}
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Footer Info */}
      <div className="p-4 border-t border-slate-800 text-xs text-slate-400 space-y-2">
        <div className="flex items-center justify-between">
          <span>Release Edition</span>
          <span className="text-slate-300 font-mono text-[11px]">v1.0.0 Pro</span>
        </div>
        <div className="flex items-center justify-between">
          <span>Engine</span>
          <span className="text-emerald-400 font-medium">SQLite 3 WASM</span>
        </div>
      </div>
    </aside>
  );
};
