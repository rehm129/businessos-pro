import React, { useState } from 'react';
import {
  Building2,
  HardDrive,
  User as UserIcon,
  LogOut,
  ShieldCheck,
  CheckCircle2,
  KeyRound,
  RotateCcw,
} from 'lucide-react';
import { BusinessProfile, User } from '../../types';
import { authService } from '../../services/auth-service';

interface NavbarProps {
  business: BusinessProfile | null;
  currentUser: User | null;
  onUserChanged: () => void;
  onNavigateToSettings: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  business,
  currentUser,
  onUserChanged,
  onNavigateToSettings,
}) => {
  const [showSwitchModal, setShowSwitchModal] = useState(false);
  const [selectedUsername, setSelectedUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const allUsers = authService.listUsers();

  const handleSwitchUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsSubmitting(true);
    try {
      await authService.login(selectedUsername, password);
      setShowSwitchModal(false);
      setPassword('');
      onUserChanged();
    } catch (err: any) {
      setLoginError(err.message || 'Login failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getBusinessTypeLabel = (type?: string) => {
    switch (type) {
      case 'supermarket':
        return 'Supermarket & Grocery';
      case 'clothing_apparel':
        return 'Garments & Fashion';
      case 'electronics_mobile':
        return 'Electronics & Mobile';
      case 'wholesale_distributor':
        return 'Wholesale & Distribution';
      case 'service_business':
        return 'Service Enterprise';
      default:
        return 'Retail Store';
    }
  };

  return (
    <>
      <header className="h-16 bg-slate-900 border-b border-slate-800 px-6 flex items-center justify-between text-white shrink-0 select-none">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-lg shadow-md shadow-indigo-500/20">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="font-semibold text-slate-100 tracking-tight text-base">
                  {business?.name || 'BusinessOS Pro'}
                </h1>
                <span className="text-[10px] font-medium tracking-wide uppercase px-2 py-0.5 rounded bg-slate-800 text-indigo-300 border border-indigo-500/30">
                  {getBusinessTypeLabel(business?.businessType)}
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-sm">
                {business?.tagline || 'Local-First Enterprise Engine'}
              </p>
            </div>
          </div>
        </div>

        {/* Center / Right Status & User Switcher */}
        <div className="flex items-center space-x-4">
          {/* SQLite Local-First Badge */}
          <div
            onClick={onNavigateToSettings}
            title="Local SQLite storage active. 100% offline-ready with safety backup protocol."
            className="hidden sm:flex items-center space-x-2 px-3 py-1.5 rounded-md bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs cursor-pointer hover:bg-emerald-900/60 transition"
          >
            <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-medium">SQLite Local-First</span>
            <CheckCircle2 className="w-3 h-3 text-emerald-400 ml-1" />
          </div>

          {/* Current User & Role */}
          <div className="flex items-center space-x-3 pl-2 border-l border-slate-800">
            <button
              onClick={() => setShowSwitchModal(true)}
              className="flex items-center space-x-2.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-left transition"
            >
              <div className="w-7 h-7 rounded-full bg-slate-700 flex items-center justify-center text-indigo-400">
                <UserIcon className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-medium text-slate-200">
                  {currentUser?.displayName || 'Cashier'}
                </div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-indigo-400">
                  {currentUser?.role || 'cashier'}
                </div>
              </div>
              <RotateCcw className="w-3.5 h-3.5 text-slate-400 ml-1" />
            </button>
          </div>
        </div>
      </header>

      {/* Switch User / Cashier Modal */}
      {showSwitchModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-md w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-semibold">Switch Active Cashier / User</h3>
                  <p className="text-xs text-slate-400">Authenticate with local credentials</p>
                </div>
              </div>
              <button
                onClick={() => setShowSwitchModal(false)}
                className="text-slate-400 hover:text-white text-sm px-2 py-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSwitchUser} className="mt-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Select User Account
                </label>
                <select
                  value={selectedUsername}
                  onChange={(e) => setSelectedUsername(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-indigo-500"
                >
                  {allUsers.map((u) => (
                    <option key={u.id} value={u.username}>
                      {u.displayName} ({u.role.toUpperCase()}) - @{u.username}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Account Password
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="password"
                    placeholder="Enter password (e.g., admin123 or cashier123)"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-sm text-slate-200 focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Default test credentials: <span className="text-indigo-300 font-mono">admin / admin123</span> or{' '}
                  <span className="text-indigo-300 font-mono">cashier / cashier123</span>
                </p>
              </div>

              {loginError && (
                <div className="p-2.5 rounded bg-rose-950/60 border border-rose-500/40 text-rose-300 text-xs">
                  {loginError}
                </div>
              )}

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowSwitchModal(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-xs font-medium text-white shadow-sm"
                >
                  {isSubmitting ? 'Authenticating...' : 'Sign In & Switch'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
