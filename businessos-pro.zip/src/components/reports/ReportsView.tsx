import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Calendar,
  Download,
  DollarSign,
  TrendingUp,
  Package,
  Layers,
  FileSpreadsheet,
  HelpCircle,
} from 'lucide-react';
import { BusinessProfile } from '../../types';
import {
  reportingService,
  ProfitLossSummary,
  InventoryValuationSummary,
  ProductPerformanceRow,
} from '../../services/reporting-service';
import { inventoryService } from '../../services/inventory-service';

interface ReportsViewProps {
  business: BusinessProfile | null;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ business }) => {
  const currency = business?.currencySymbol || '$';

  const [activeTab, setActiveTab] = useState<'pnl' | 'valuation' | 'products' | 'movements'>('pnl');

  // Date filters
  const [datePreset, setDatePreset] = useState<'all' | 'today' | '7days' | '30days' | 'custom'>('30days');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Data states
  const [pnl, setPnl] = useState<ProfitLossSummary | null>(null);
  const [valuation, setValuation] = useState<InventoryValuationSummary | null>(null);
  const [productPerformance, setProductPerformance] = useState<ProductPerformanceRow[]>([]);
  const [movements, setMovements] = useState<any[]>([]);

  useEffect(() => {
    // Set default dates for 30 days
    const now = new Date();
    const end = now.toISOString().slice(0, 10);
    const startObj = new Date(now);
    startObj.setDate(startObj.getDate() - 30);
    const start = startObj.toISOString().slice(0, 10);
    setStartDate(start);
    setEndDate(end);
  }, []);

  const loadReports = () => {
    let sDate = startDate;
    let eDate = endDate;

    if (datePreset === 'today') {
      const today = new Date().toISOString().slice(0, 10);
      sDate = today;
      eDate = today;
    } else if (datePreset === 'all') {
      sDate = '';
      eDate = '';
    }

    setPnl(reportingService.getProfitLoss(sDate || undefined, eDate || undefined));
    setValuation(reportingService.getInventoryValuation());
    setProductPerformance(reportingService.getProductPerformance(50));
    setMovements(inventoryService.getStockMovements(undefined, 100));
  };

  useEffect(() => {
    loadReports();
  }, [datePreset, startDate, endDate]);

  const handleExportPnlCsv = () => {
    if (!pnl) return;
    const headers = ['Financial Metric', 'Amount', 'Notes'];
    const rows = [
      ['Gross Sales Revenue', `${currency}${pnl.grossSales.toFixed(2)}`, 'Total item charges before discounts'],
      ['Customer Discounts', `-${currency}${pnl.discounts.toFixed(2)}`, 'Item discounts applied at POS'],
      ['Net Sales Revenue', `${currency}${pnl.netSalesRevenue.toFixed(2)}`, 'Gross Sales minus Discounts'],
      ['Cost of Goods Sold (COGS)', `-${currency}${pnl.cogs.toFixed(2)}`, 'Acquisition cost of items sold'],
      ['Gross Profit', `${currency}${pnl.grossProfit.toFixed(2)}`, `Gross Margin: ${pnl.grossMarginPercent}%`],
      ['Total Operating Expenses', `-${currency}${pnl.totalOperatingExpenses.toFixed(2)}`, 'Utilities, rent, wages, etc.'],
      ['Net Operating Profit', `${currency}${pnl.netProfit.toFixed(2)}`, `Net Margin: ${pnl.netMarginPercent}%`],
    ];
    reportingService.downloadCsv(`profit_and_loss_${pnl.periodLabel.replace(/\s+/g, '_')}.csv`, headers, rows);
  };

  const handleExportValuationCsv = () => {
    if (!valuation) return;
    const headers = ['Inventory Valuation Metric', 'Value'];
    const rows = [
      ['Total Unique SKUs', valuation.totalSkus],
      ['Total Units On Hand', valuation.totalUnitsInStock],
      ['Total Inventory Cost Valuation', `${currency}${valuation.totalCostValue.toFixed(2)}`],
      ['Total Inventory Retail Valuation', `${currency}${valuation.totalRetailValue.toFixed(2)}`],
      ['Potential Gross Profit at Retail', `${currency}${valuation.potentialProfit.toFixed(2)}`],
      ['Potential Gross Margin', `${valuation.potentialMarginPercent}%`],
    ];
    reportingService.downloadCsv('inventory_valuation_summary.csv', headers, rows);
  };

  const handleExportProductPerformanceCsv = () => {
    const headers = ['SKU', 'Product Title', 'Category', 'Units Sold', 'Gross Revenue', 'Cost of Goods', 'Profit', 'Margin %'];
    const rows = productPerformance.map((p) => [
      p.sku,
      p.productName,
      p.categoryName,
      p.unitsSold,
      `${currency}${p.grossRevenue.toFixed(2)}`,
      `${currency}${p.totalCost.toFixed(2)}`,
      `${currency}${p.profit.toFixed(2)}`,
      `${p.profitMarginPercent}%`,
    ]);
    reportingService.downloadCsv('product_performance_ranking.csv', headers, rows);
  };

  return (
    <div className="space-y-6 text-white pb-10">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">Financial Reports & Auditing</h2>
            <p className="text-xs text-slate-400">
              Accrual Profit & Loss statements, inventory valuation, product profitability, and CSV export.
            </p>
          </div>
        </div>

        {/* Date Filter Bar */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <select
            value={datePreset}
            onChange={(e) => setDatePreset(e.target.value as any)}
            className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden"
          >
            <option value="30days">Last 30 Days</option>
            <option value="7days">Last 7 Days</option>
            <option value="today">Today Only</option>
            <option value="all">All Time</option>
            <option value="custom">Custom Date Range</option>
          </select>

          {datePreset === 'custom' && (
            <div className="flex items-center space-x-1.5">
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white"
              />
              <span className="text-slate-400">to</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white"
              />
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
        {[
          { id: 'pnl', label: 'Profit & Loss Statement', icon: TrendingUp },
          { id: 'valuation', label: 'Inventory Valuation', icon: Package },
          { id: 'products', label: 'Product Performance', icon: BarChart3 },
          { id: 'movements', label: 'Stock Movement Audit', icon: Layers },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center space-x-2 transition ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab 1: Profit & Loss Statement */}
      {activeTab === 'pnl' && pnl && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">
              Reporting Period: <strong className="text-slate-200">{pnl.periodLabel}</strong>
            </span>
            <button
              onClick={handleExportPnlCsv}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export P&L to CSV</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-semibold uppercase text-slate-400">Net Sales Revenue</span>
              <div className="text-2xl font-bold font-mono text-slate-100 mt-2">
                {currency}{pnl.netSalesRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Gross sales minus customer discounts</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-semibold uppercase text-slate-400">Gross Profit (COGS Deducted)</span>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-2">
                {currency}{pnl.grossProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Gross Margin: {pnl.grossMarginPercent}%</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-semibold uppercase text-slate-400">Net Operating Profit</span>
              <div
                className={`text-2xl font-bold font-mono mt-2 ${
                  pnl.netProfit >= 0 ? 'text-teal-400' : 'text-rose-400'
                }`}
              >
                {currency}{pnl.netProfit.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Net Margin: {pnl.netMarginPercent}%</p>
            </div>
          </div>

          {/* Detailed Accounting Breakdown Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
            <h3 className="text-base font-bold text-slate-100 mb-4">Accrual Statement Breakdown</h3>

            <div className="space-y-3 font-mono text-xs">
              <div className="flex justify-between py-2 border-b border-slate-800 text-slate-300">
                <span>Gross Product Sales</span>
                <span>{currency}{pnl.grossSales.toFixed(2)}</span>
              </div>

              {pnl.discounts > 0 && (
                <div className="flex justify-between py-2 border-b border-slate-800 text-amber-400">
                  <span>Less: Customer Discounts</span>
                  <span>- {currency}{pnl.discounts.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between py-2 border-b border-slate-800 font-bold text-slate-100">
                <span>Net Sales Revenue</span>
                <span>{currency}{pnl.netSalesRevenue.toFixed(2)}</span>
              </div>

              <div className="flex justify-between py-2 border-b border-slate-800 text-rose-400">
                <span>Less: Cost of Goods Sold (Product Acquisition Costs)</span>
                <span>- {currency}{pnl.cogs.toFixed(2)}</span>
              </div>

              <div className="flex justify-between py-2 border-b border-slate-800 font-bold text-emerald-400 text-sm">
                <span>Gross Profit</span>
                <span>{currency}{pnl.grossProfit.toFixed(2)}</span>
              </div>

              <div className="flex justify-between py-2 border-b border-slate-800 text-rose-400">
                <span>Less: Operating Expenses (Rent, Utilities, Wages, Payouts)</span>
                <span>- {currency}{pnl.totalOperatingExpenses.toFixed(2)}</span>
              </div>

              <div className="flex justify-between py-3 border-t-2 border-slate-700 font-bold text-base">
                <span className="text-slate-100">Net Operating Profit</span>
                <span className={pnl.netProfit >= 0 ? 'text-teal-400' : 'text-rose-400'}>
                  {currency}{pnl.netProfit.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Clear Calculation Method Notice */}
            <div className="mt-6 p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 flex items-start space-x-3">
              <HelpCircle className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-200">Calculation Methodology & Reconciliation Guarantee:</strong>
                <p className="mt-1 leading-relaxed">{pnl.calculationMethod}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Inventory Valuation */}
      {activeTab === 'valuation' && valuation && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">Current On-Hand Inventory Valuation</span>
            <button
              onClick={handleExportValuationCsv}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Valuation CSV</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-semibold uppercase text-slate-400">Active SKUs</span>
              <div className="text-2xl font-bold font-mono text-slate-100 mt-2">
                {valuation.totalSkus}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">{valuation.totalUnitsInStock} total units on hand</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-semibold uppercase text-slate-400">Total Cost Valuation</span>
              <div className="text-2xl font-bold font-mono text-indigo-400 mt-2">
                {currency}{valuation.totalCostValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Capital invested in inventory</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-semibold uppercase text-slate-400">Total Retail Value</span>
              <div className="text-2xl font-bold font-mono text-emerald-400 mt-2">
                {currency}{valuation.totalRetailValue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Expected gross revenue at full price</p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
              <span className="text-xs font-semibold uppercase text-slate-400">Potential Gross Margin</span>
              <div className="text-2xl font-bold font-mono text-teal-400 mt-2">
                {valuation.potentialMarginPercent}%
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Potential Profit: {currency}{valuation.potentialProfit.toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Product Performance Ranking */}
      {activeTab === 'products' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">Ranked by Total Gross Sales Revenue</span>
            <button
              onClick={handleExportProductPerformanceCsv}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Ranking CSV</span>
            </button>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
                  <tr>
                    <th className="px-5 py-3.5">Product Title / SKU</th>
                    <th className="px-5 py-3.5">Category</th>
                    <th className="px-5 py-3.5 text-center">Units Sold</th>
                    <th className="px-5 py-3.5 text-right">Gross Revenue</th>
                    <th className="px-5 py-3.5 text-right">Total Cost</th>
                    <th className="px-5 py-3.5 text-right">Generated Profit</th>
                    <th className="px-5 py-3.5 text-right">Margin %</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-medium">
                  {productPerformance.map((p, idx) => (
                    <tr key={p.productId} className="hover:bg-slate-800/40 transition">
                      <td className="px-5 py-3.5">
                        <div className="font-semibold text-slate-100">{p.productName}</div>
                        <div className="text-[10px] font-mono text-indigo-400">{p.sku}</div>
                      </td>
                      <td className="px-5 py-3.5 text-slate-400">{p.categoryName}</td>
                      <td className="px-5 py-3.5 text-center font-mono font-bold text-slate-200">
                        {p.unitsSold}
                      </td>
                      <td className="px-5 py-3.5 text-right font-mono font-bold text-slate-100">
                        {currency}{p.grossRevenue.toFixed(2)}
                      </td>
                      <td className="px-5 py-3.5 text-right font-mono text-slate-400">
                        {currency}{p.totalCost.toFixed(2)}
                      </td>
                      <td className="px-5 py-3.5 text-right font-mono font-bold text-emerald-400">
                        {currency}{p.profit.toFixed(2)}
                      </td>
                      <td className="px-5 py-3.5 text-right font-mono text-teal-400">
                        {p.profitMarginPercent}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Stock Movement Audit */}
      {activeTab === 'movements' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="px-4 py-3">Timestamp</th>
                  <th className="px-4 py-3">Product Name</th>
                  <th className="px-4 py-3">Movement Type</th>
                  <th className="px-4 py-3 text-center">Change</th>
                  <th className="px-4 py-3 text-center">Stock After</th>
                  <th className="px-4 py-3">Reference / Notes</th>
                  <th className="px-4 py-3">Logged By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {movements.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-800/30">
                    <td className="px-4 py-3 text-slate-400">{new Date(m.createdAt).toLocaleString()}</td>
                    <td className="px-4 py-3 font-semibold text-slate-200">{m.productName}</td>
                    <td className="px-4 py-3 uppercase text-[10px] text-slate-300">
                      {m.movementType.replace('_', ' ')}
                    </td>
                    <td className="px-4 py-3 text-center font-mono font-bold">
                      <span className={m.quantityChange > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                        {m.quantityChange > 0 ? `+${m.quantityChange}` : m.quantityChange}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center font-mono text-slate-200">{m.stockAfter}</td>
                    <td className="px-4 py-3 text-slate-400 truncate max-w-xs">{m.referenceId}: {m.notes}</td>
                    <td className="px-4 py-3 text-slate-400">{m.createdByName}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
