import React, { useState, useEffect } from 'react';
import {
  ReceiptText,
  Plus,
  CircleDollarSign,
  Calendar,
  Layers,
  X,
  CheckCircle,
  AlertCircle,
  ArrowRight,
} from 'lucide-react';
import { BusinessProfile, CashReconciliation, Expense, ExpenseCategory, PaymentMethod, User } from '../../types';
import { expenseService, CreateExpenseInput } from '../../services/expense-service';

interface ExpensesViewProps {
  business: BusinessProfile | null;
  currentUser: User | null;
  defaultTab?: 'expenses' | 'reconciliation';
}

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  business,
  currentUser,
  defaultTab = 'expenses',
}) => {
  const currency = business?.currencySymbol || '$';

  const [activeTab, setActiveTab] = useState<'expenses' | 'reconciliation'>(defaultTab);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [categories, setCategories] = useState<ExpenseCategory[]>([]);

  // Add Expense Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [expCatId, setExpCatId] = useState('');
  const [expAmount, setExpAmount] = useState<number>(0);
  const [expMethod, setExpMethod] = useState<PaymentMethod>('cash');
  const [expDesc, setExpDesc] = useState('');
  const [expPaidTo, setExpPaidTo] = useState('');
  const [expError, setExpError] = useState('');

  // Daily Cash Reconciliation State
  const [reconDate, setReconDate] = useState(new Date().toISOString().slice(0, 10));
  const [openingFloat, setOpeningFloat] = useState<number>(100);
  const [actualCountedCash, setActualCountedCash] = useState<number>(100);
  const [reconNotes, setReconNotes] = useState('');
  const [cashCalc, setCashCalc] = useState<{
    cashSales: number;
    cashPaymentsReceived: number;
    cashExpenses: number;
    netCashMovement: number;
  }>({ cashSales: 0, cashPaymentsReceived: 0, cashExpenses: 0, netCashMovement: 0 });
  const [existingRecon, setExistingRecon] = useState<CashReconciliation | null>(null);

  const refreshExpenses = () => {
    setExpenses(expenseService.getExpenses());
    const cats = expenseService.getExpenseCategories();
    setCategories(cats);
    if (cats.length > 0 && !expCatId) {
      setExpCatId(cats[0].id);
    }
  };

  const refreshReconciliation = () => {
    const calc = expenseService.calculateCashDrawerForDate(reconDate);
    setCashCalc(calc);
    const existing = expenseService.getDailyReconciliation(reconDate);
    setExistingRecon(existing);
    if (existing) {
      setOpeningFloat(existing.openingFloat);
      setActualCountedCash(existing.actualCountedCash);
      setReconNotes(existing.notes || '');
    } else {
      setActualCountedCash(Number((openingFloat + calc.netCashMovement).toFixed(2)));
    }
  };

  useEffect(() => {
    refreshExpenses();
  }, []);

  useEffect(() => {
    refreshReconciliation();
  }, [reconDate, openingFloat]);

  const handleCreateExpense = (e: React.FormEvent) => {
    e.preventDefault();
    setExpError('');
    try {
      const input: CreateExpenseInput = {
        categoryId: expCatId,
        amount: expAmount,
        paymentMethod: expMethod,
        description: expDesc,
        paidTo: expPaidTo,
      };
      expenseService.recordExpense(input, currentUser?.displayName || 'Admin');
      setShowAddModal(false);
      setExpAmount(0);
      setExpDesc('');
      setExpPaidTo('');
      refreshExpenses();
      refreshReconciliation();
    } catch (err: any) {
      setExpError(err.message || 'Failed to record expense.');
    }
  };

  const handleSaveReconciliation = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      expenseService.submitDailyReconciliation(
        reconDate,
        openingFloat,
        actualCountedCash,
        currentUser?.displayName || 'Admin',
        reconNotes
      );
      alert('Daily cash register reconciliation recorded successfully.');
      refreshReconciliation();
    } catch (err: any) {
      alert(err.message || 'Failed to save reconciliation.');
    }
  };

  const expectedCashDrawer = Number((openingFloat + cashCalc.netCashMovement).toFixed(2));
  const cashVariance = Number((actualCountedCash - expectedCashDrawer).toFixed(2));

  return (
    <div className="space-y-6 text-white pb-10">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
            <ReceiptText className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">Expenses & Cash Drawer Reconciliation</h2>
            <p className="text-xs text-slate-400">
              Track operational costs, daily register float, cash inflows, and end-of-day drawer variance.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-semibold text-xs text-white shadow-md shadow-indigo-600/30"
          >
            <Plus className="w-4 h-4" />
            <span>Record New Expense</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('expenses')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition ${
            activeTab === 'expenses'
              ? 'bg-indigo-600 text-white'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          Operating Expenses Ledger
        </button>
        <button
          onClick={() => setActiveTab('reconciliation')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition flex items-center space-x-1.5 ${
            activeTab === 'reconciliation'
              ? 'bg-indigo-600 text-white'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
          }`}
        >
          <CircleDollarSign className="w-3.5 h-3.5" />
          <span>Daily Cash Drawer Reconciliation</span>
        </button>
      </div>

      {/* Tab 1: Expenses List */}
      {activeTab === 'expenses' ? (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="px-5 py-3.5">Date & Time</th>
                  <th className="px-5 py-3.5">Category</th>
                  <th className="px-5 py-3.5">Description</th>
                  <th className="px-5 py-3.5">Paid To</th>
                  <th className="px-5 py-3.5 uppercase">Method</th>
                  <th className="px-5 py-3.5 text-right">Amount</th>
                  <th className="px-5 py-3.5 text-right">Recorded By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {expenses.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-5 py-10 text-center text-slate-400">
                      No expenses recorded yet.
                    </td>
                  </tr>
                ) : (
                  expenses.map((exp) => (
                    <tr key={exp.id} className="hover:bg-slate-800/40 transition">
                      <td className="px-5 py-3.5 text-slate-400">
                        {new Date(exp.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-5 py-3.5 text-indigo-400 font-semibold">{exp.categoryName}</td>
                      <td className="px-5 py-3.5 text-slate-100">{exp.description}</td>
                      <td className="px-5 py-3.5 text-slate-300">{exp.paidTo || '-'}</td>
                      <td className="px-5 py-3.5 uppercase text-[10px] text-slate-400">
                        {exp.paymentMethod}
                      </td>
                      <td className="px-5 py-3.5 text-right font-mono font-bold text-rose-400">
                        {currency}{exp.amount.toFixed(2)}
                      </td>
                      <td className="px-5 py-3.5 text-right text-slate-400">{exp.recordedBy}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Tab 2: Daily Cash Register Reconciliation */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left 2 Cols: Calculation Breakdown & Form */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100">End-of-Day Cash Drawer Audit</h3>
                <p className="text-xs text-slate-400">Verify opening float against cash transactions</p>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4 text-slate-400" />
                <input
                  type="date"
                  value={reconDate}
                  onChange={(e) => setReconDate(e.target.value)}
                  className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200"
                />
              </div>
            </div>

            {/* Reconciliation Math Formula Box */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3 font-mono text-xs">
              <div className="flex justify-between items-center text-slate-300">
                <span>(+) Opening Float in Drawer</span>
                <div className="flex items-center space-x-2">
                  <span className="text-slate-400">{currency}</span>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    value={openingFloat}
                    onChange={(e) => setOpeningFloat(parseFloat(e.target.value) || 0)}
                    className="w-24 bg-slate-900 border border-slate-700 rounded px-2 py-0.5 text-right text-white font-bold"
                  />
                </div>
              </div>

              <div className="flex justify-between items-center text-emerald-400">
                <span>(+) Cash Sales Today (Direct & Splits)</span>
                <span>+ {currency}{cashCalc.cashSales.toFixed(2)}</span>
              </div>

              <div className="flex justify-between items-center text-emerald-400">
                <span>(+) Cash Customer Payments Received</span>
                <span>+ {currency}{cashCalc.cashPaymentsReceived.toFixed(2)}</span>
              </div>

              <div className="flex justify-between items-center text-rose-400">
                <span>(-) Cash Expenses Paid from Drawer</span>
                <span>- {currency}{cashCalc.cashExpenses.toFixed(2)}</span>
              </div>

              <div className="border-t border-slate-800 pt-2 flex justify-between items-center text-sm font-bold text-slate-100">
                <span className="font-sans">Expected Total Cash in Drawer:</span>
                <span className="text-indigo-400">{currency}{expectedCashDrawer.toFixed(2)}</span>
              </div>
            </div>

            {/* Actual Count Form */}
            <form onSubmit={handleSaveReconciliation} className="space-y-4 pt-2">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">
                    Actual Counted Cash in Drawer ({currency}) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={actualCountedCash}
                    onChange={(e) => setActualCountedCash(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-base font-mono font-bold text-white focus:outline-hidden focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">
                    Drawer Variance (Difference)
                  </label>
                  <div
                    className={`w-full rounded-xl px-4 py-2 font-mono font-bold text-base border flex items-center justify-between ${
                      cashVariance === 0
                        ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-400'
                        : cashVariance > 0
                        ? 'bg-amber-950/60 border-amber-500/40 text-amber-400'
                        : 'bg-rose-950/60 border-rose-500/40 text-rose-400'
                    }`}
                  >
                    <span>{cashVariance > 0 ? `+${currency}${cashVariance.toFixed(2)} (Surplus)` : cashVariance < 0 ? `${currency}${cashVariance.toFixed(2)} (Shortage)` : `${currency}0.00 (Balanced)`}</span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">
                  Audit Notes / Reason for Discrepancy
                </label>
                <input
                  type="text"
                  placeholder="e.g., Change discrepancy or counted by shift supervisor"
                  value={reconNotes}
                  onChange={(e) => setReconNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-bold text-xs text-white shadow-md shadow-indigo-600/30"
                >
                  Save Cash Reconciliation Audit
                </button>
              </div>
            </form>
          </div>

          {/* Right Col: Reconciliation Instructions & Status */}
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
            <h4 className="text-sm font-bold text-slate-100 flex items-center">
              <CheckCircle className="w-4 h-4 text-emerald-400 mr-2" />
              Cash Drawer Standard Operating Procedure
            </h4>

            <div className="text-xs text-slate-400 space-y-3 leading-relaxed">
              <p>
                1. <strong className="text-slate-200">Opening Float:</strong> Ensure the starting cash float matches what was left in the till from previous day.
              </p>
              <p>
                2. <strong className="text-slate-200">POS Receipts:</strong> All cash purchases and cash payouts must be recorded in the system immediately.
              </p>
              <p>
                3. <strong className="text-slate-200">Closing Physical Count:</strong> Count all bank notes and coins physically before looking at the system expected total.
              </p>
              <p>
                4. <strong className="text-slate-200">Zero-Loss Discipline:</strong> Any shortage or surplus will be logged in the permanent SQLite database for managerial audit.
              </p>
            </div>

            {existingRecon && (
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                <span className="text-[10px] uppercase font-semibold text-slate-400">Last Reconciled Status</span>
                <div className="font-semibold text-slate-200">Audited by: {existingRecon.reconciledBy}</div>
                <div className="text-slate-400 text-[11px]">{new Date(existingRecon.createdAt).toLocaleString()}</div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Add Expense Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100">Record Operating Expense</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateExpense} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Expense Category *
                </label>
                <select
                  value={expCatId}
                  onChange={(e) => setExpCatId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-hidden"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Amount ({currency}) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  value={expAmount || ''}
                  placeholder="0.00"
                  onChange={(e) => setExpAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm font-mono font-bold text-rose-400 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Payment Source
                </label>
                <select
                  value={expMethod}
                  onChange={(e) => setExpMethod(e.target.value as PaymentMethod)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-hidden"
                >
                  <option value="cash">Cash Paid From Register Till</option>
                  <option value="card">Store Debit / Card</option>
                  <option value="bank_transfer">Direct Bank Transfer</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Expense Description *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Weekly store cleaning supplies & thermal rolls"
                  value={expDesc}
                  onChange={(e) => setExpDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Paid To / Vendor Name
                </label>
                <input
                  type="text"
                  placeholder="e.g., CleanPro Janitorial Services"
                  value={expPaidTo}
                  onChange={(e) => setExpPaidTo(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              {expError && (
                <div className="p-2.5 rounded-xl bg-rose-950/70 border border-rose-500/50 text-rose-300 text-xs">
                  {expError}
                </div>
              )}

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-md shadow-indigo-600/30"
                >
                  Save Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
