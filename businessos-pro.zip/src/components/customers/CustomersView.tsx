import React, { useState, useEffect } from 'react';
import {
  Users,
  Plus,
  Search,
  DollarSign,
  Phone,
  Mail,
  MapPin,
  X,
  CreditCard,
  FileText,
  CheckCircle2,
} from 'lucide-react';
import { BusinessProfile, Customer, CustomerPayment, PaymentMethod, User } from '../../types';
import { customerService, CreateCustomerInput } from '../../services/customer-service';

interface CustomersViewProps {
  business: BusinessProfile | null;
  currentUser: User | null;
}

export const CustomersView: React.FC<CustomersViewProps> = ({ business, currentUser }) => {
  const currency = business?.currencySymbol || '$';

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState('');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custEmail, setCustEmail] = useState('');
  const [custAddress, setCustAddress] = useState('');
  const [custCreditLimit, setCustCreditLimit] = useState<number>(0);

  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMethod, setPayMethod] = useState<PaymentMethod>('cash');
  const [payRef, setPayRef] = useState('');
  const [payNotes, setPayNotes] = useState('');
  const [paymentError, setPaymentError] = useState('');

  const [showStatementModal, setShowStatementModal] = useState(false);
  const [statementPayments, setStatementPayments] = useState<CustomerPayment[]>([]);

  const refresh = () => {
    setCustomers(customerService.getCustomers(search));
  };

  useEffect(() => {
    refresh();
  }, [search]);

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const input: CreateCustomerInput = {
        name: custName,
        phone: custPhone,
        email: custEmail,
        address: custAddress,
        creditLimit: custCreditLimit,
      };
      customerService.createCustomer(input);
      setShowAddModal(false);
      setCustName('');
      setCustPhone('');
      setCustEmail('');
      setCustAddress('');
      setCustCreditLimit(0);
      refresh();
    } catch (err: any) {
      alert(err.message || 'Failed to add customer.');
    }
  };

  const handleOpenPayment = (c: Customer) => {
    setSelectedCustomer(c);
    setPayAmount(c.currentBalance > 0 ? c.currentBalance : 0);
    setPayMethod('cash');
    setPayRef('');
    setPayNotes('');
    setPaymentError('');
    setShowPaymentModal(true);
  };

  const handleOpenStatement = (c: Customer) => {
    setSelectedCustomer(c);
    setStatementPayments(customerService.getCustomerPayments(c.id));
    setShowStatementModal(true);
  };

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;
    setPaymentError('');

    try {
      if (payAmount <= 0) {
        throw new Error('Payment amount must be greater than zero.');
      }

      customerService.recordPayment(
        selectedCustomer.id,
        payAmount,
        payMethod,
        payRef,
        payNotes,
        currentUser?.displayName || 'Admin'
      );

      setShowPaymentModal(false);
      refresh();
    } catch (err: any) {
      setPaymentError(err.message || 'Failed to record payment.');
    }
  };

  const totalDueReceivables = customers.reduce(
    (sum, c) => sum + (c.currentBalance > 0 ? c.currentBalance : 0),
    0
  );

  return (
    <div className="space-y-6 text-white pb-10">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">Customer Directory & Credit Ledger</h2>
            <p className="text-xs text-slate-400">
              Manage accounts, credit limits, sales history, and customer dues.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 flex items-center space-x-2 text-xs">
            <span className="text-slate-400">Total Due Receivables:</span>
            <span className="font-mono font-bold text-rose-400">
              {currency}{totalDueReceivables.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-semibold text-xs text-white shadow-md shadow-indigo-600/30"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add Customer</span>
          </button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
        <div className="w-full md:w-80 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by customer name, phone, or email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 focus:outline-hidden focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
              <tr>
                <th className="px-5 py-3.5">Customer Name</th>
                <th className="px-5 py-3.5">Contact Phone & Email</th>
                <th className="px-5 py-3.5">Address</th>
                <th className="px-5 py-3.5 text-center">Orders</th>
                <th className="px-5 py-3.5 text-right">Lifetime Spent</th>
                <th className="px-5 py-3.5 text-right">Credit Limit</th>
                <th className="px-5 py-3.5 text-right">Current Due Balance</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {customers.map((c) => (
                <tr key={c.id} className="hover:bg-slate-800/40 transition">
                  <td className="px-5 py-3.5 text-slate-100 font-bold">{c.name}</td>
                  <td className="px-5 py-3.5 text-slate-300">
                    <div>{c.phone}</div>
                    <div className="text-[10px] text-slate-400">{c.email || '-'}</div>
                  </td>
                  <td className="px-5 py-3.5 text-slate-400 truncate max-w-xs">{c.address || '-'}</td>
                  <td className="px-5 py-3.5 text-center font-mono text-slate-300">
                    {c.totalSalesCount}
                  </td>
                  <td className="px-5 py-3.5 text-right font-mono text-slate-300">
                    {currency}{c.totalSpent.toFixed(2)}
                  </td>
                  <td className="px-5 py-3.5 text-right font-mono text-slate-400">
                    {c.creditLimit > 0 ? `${currency}${c.creditLimit.toFixed(2)}` : 'None'}
                  </td>
                  <td className="px-5 py-3.5 text-right font-mono font-bold">
                    <span className={c.currentBalance > 0 ? 'text-rose-400' : 'text-emerald-400'}>
                      {currency}{c.currentBalance.toFixed(2)}
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-right space-x-2">
                    {c.currentBalance > 0 && (
                      <button
                        onClick={() => handleOpenPayment(c)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600 text-emerald-400 hover:text-white text-[11px] font-semibold transition"
                      >
                        Receive Payment
                      </button>
                    )}
                    <button
                      onClick={() => handleOpenStatement(c)}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition"
                    >
                      Statement
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100">Add New Customer</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Customer Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={custName}
                  onChange={(e) => setCustName(e.target.value)}
                  placeholder="e.g., Jane Doe"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Phone Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={custPhone}
                    onChange={(e) => setCustPhone(e.target.value)}
                    placeholder="+1 555-4321"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={custEmail}
                    onChange={(e) => setCustEmail(e.target.value)}
                    placeholder="jane@example.com"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Billing / Delivery Address
                </label>
                <input
                  type="text"
                  value={custAddress}
                  onChange={(e) => setCustAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Credit Limit ({currency})
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={custCreditLimit || ''}
                  placeholder="0.00 (No credit allowed)"
                  onChange={(e) => setCustCreditLimit(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white shadow-md shadow-indigo-600/30"
                >
                  Save Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Payment Towards Due Balance Modal */}
      {showPaymentModal && selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 text-white shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100">Receive Customer Payment</h3>
                <p className="text-xs text-slate-400">{selectedCustomer.name}</p>
              </div>
              <button onClick={() => setShowPaymentModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitPayment} className="mt-4 space-y-4">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center text-xs">
                <span className="text-slate-400">Current Outstanding Balance:</span>
                <span className="font-mono font-bold text-base text-rose-400">
                  {currency}{selectedCustomer.currentBalance.toFixed(2)}
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Payment Amount Received ({currency}) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  required
                  value={payAmount || ''}
                  onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm font-mono font-bold text-emerald-400 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Payment Method
                </label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value as PaymentMethod)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-hidden"
                >
                  <option value="cash">Cash Tender</option>
                  <option value="card">Card / Debit</option>
                  <option value="bank_transfer">Bank Wire / Transfer</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1">
                  Reference / Check / Transaction ID
                </label>
                <input
                  type="text"
                  placeholder="Optional reference code"
                  value={payRef}
                  onChange={(e) => setPayRef(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-hidden"
                />
              </div>

              {paymentError && (
                <div className="p-2.5 rounded-xl bg-rose-950/70 border border-rose-500/50 text-rose-300 text-xs">
                  {paymentError}
                </div>
              )}

              <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowPaymentModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white shadow-md shadow-emerald-600/30"
                >
                  Confirm Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Account Statement Modal */}
      {showStatementModal && selectedCustomer && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full p-6 text-white shadow-2xl flex flex-col max-h-[85vh]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-100">Customer Statement Ledger</h3>
                <p className="text-xs text-slate-400">{selectedCustomer.name} • {selectedCustomer.phone}</p>
              </div>
              <button onClick={() => setShowStatementModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center text-xs">
              <span className="text-slate-400">Current Outstanding Balance:</span>
              <span className="font-mono font-bold text-rose-400">
                {currency}{selectedCustomer.currentBalance.toFixed(2)}
              </span>
            </div>

            <div className="flex-1 overflow-y-auto mt-4">
              <h4 className="text-xs font-semibold uppercase text-slate-400 mb-2">Payment Receipts</h4>
              {statementPayments.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  No payment ledger entries recorded yet.
                </div>
              ) : (
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="px-3 py-2">Date</th>
                      <th className="px-3 py-2">Method</th>
                      <th className="px-3 py-2 text-right">Amount</th>
                      <th className="px-3 py-2">Received By</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {statementPayments.map((p) => (
                      <tr key={p.id}>
                        <td className="px-3 py-2 text-slate-400">{new Date(p.createdAt).toLocaleDateString()}</td>
                        <td className="px-3 py-2 uppercase text-[10px] text-slate-300">{p.paymentMethod}</td>
                        <td className="px-3 py-2 text-right font-mono font-bold text-emerald-400">
                          {currency}{p.amount.toFixed(2)}
                        </td>
                        <td className="px-3 py-2 text-slate-400">{p.receivedBy}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setShowStatementModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
