import { sqliteService } from '../db/sqlite-service';
import { User, UserRole, UserWithPassword } from '../types';
import { generateSalt, hashPassword, verifyPassword } from '../utils/crypto';

class AuthService {
  private currentUser: User | null = null;

  public async login(username: string, passwordAttempt: string): Promise<User> {
    const row = sqliteService.queryOne<any>(
      'SELECT id, username, display_name, password_hash, password_salt, role, is_active, created_at, last_login FROM users WHERE username = ?',
      [username.trim().toLowerCase()]
    );

    if (!row) {
      throw new Error('Invalid username or password.');
    }

    if (!row.is_active) {
      throw new Error('This account has been deactivated by an administrator.');
    }

    const isValid = await verifyPassword(passwordAttempt, row.password_hash, row.password_salt);
    if (!isValid) {
      throw new Error('Invalid username or password.');
    }

    // Update last login timestamp
    const nowIso = new Date().toISOString();
    sqliteService.run('UPDATE users SET last_login = ? WHERE id = ?', [nowIso, row.id]);

    const user: User = {
      id: row.id,
      username: row.username,
      displayName: row.display_name,
      role: row.role as UserRole,
      isActive: Boolean(row.is_active),
      createdAt: row.created_at,
      lastLogin: nowIso,
    };

    this.currentUser = user;
    if (typeof window !== 'undefined') {
      localStorage.setItem('businessos_active_user', JSON.stringify(user));
    }

    return user;
  }

  public logout(): void {
    this.currentUser = null;
    if (typeof window !== 'undefined') {
      localStorage.removeItem('businessos_active_user');
    }
  }

  public getCurrentUser(): User | null {
    if (this.currentUser) return this.currentUser;
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('businessos_active_user');
      if (stored) {
        try {
          this.currentUser = JSON.parse(stored);
          return this.currentUser;
        } catch {
          return null;
        }
      }
    }
    // Default to admin for seamless first load
    const admin = sqliteService.queryOne<any>('SELECT id, username, display_name, role, is_active, created_at FROM users WHERE role = "admin" LIMIT 1');
    if (admin) {
      this.currentUser = {
        id: admin.id,
        username: admin.username,
        displayName: admin.display_name,
        role: admin.role,
        isActive: Boolean(admin.is_active),
        createdAt: admin.created_at,
      };
      return this.currentUser;
    }
    return null;
  }

  public listUsers(): User[] {
    const rows = sqliteService.query<any>(
      'SELECT id, username, display_name, role, is_active, created_at, last_login FROM users ORDER BY created_at ASC'
    );
    return rows.map((r) => ({
      id: r.id,
      username: r.username,
      displayName: r.display_name,
      role: r.role,
      isActive: Boolean(r.is_active),
      createdAt: r.created_at,
      lastLogin: r.last_login,
    }));
  }

  public async createUser(
    username: string,
    displayName: string,
    passwordPlain: string,
    role: UserRole
  ): Promise<User> {
    const cleanUsername = username.trim().toLowerCase();
    if (!cleanUsername || cleanUsername.length < 3) {
      throw new Error('Username must be at least 3 characters.');
    }
    if (!passwordPlain || passwordPlain.length < 6) {
      throw new Error('Password must be at least 6 characters.');
    }

    const existing = sqliteService.queryOne('SELECT id FROM users WHERE username = ?', [cleanUsername]);
    if (existing) {
      throw new Error(`Username "${cleanUsername}" is already taken.`);
    }

    const id = 'usr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const salt = generateSalt();
    const hash = await hashPassword(passwordPlain, salt);
    const nowIso = new Date().toISOString();

    sqliteService.run(
      `INSERT INTO users (id, username, display_name, password_hash, password_salt, role, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 1, ?)`,
      [id, cleanUsername, displayName.trim(), hash, salt, role, nowIso]
    );

    return {
      id,
      username: cleanUsername,
      displayName: displayName.trim(),
      role,
      isActive: true,
      createdAt: nowIso,
    };
  }

  public async resetPassword(userId: string, newPasswordPlain: string): Promise<void> {
    if (!newPasswordPlain || newPasswordPlain.length < 6) {
      throw new Error('New password must be at least 6 characters.');
    }
    const salt = generateSalt();
    const hash = await hashPassword(newPasswordPlain, salt);
    sqliteService.run('UPDATE users SET password_hash = ?, password_salt = ? WHERE id = ?', [hash, salt, userId]);
  }

  public updateUserRole(userId: string, role: UserRole): void {
    sqliteService.run('UPDATE users SET role = ? WHERE id = ?', [role, userId]);
  }

  public toggleUserActive(userId: string, isActive: boolean): void {
    // Prevent deactivating the last admin
    if (!isActive) {
      const adminCount = sqliteService.queryOne<{ c: number }>(
        'SELECT count(*) as c FROM users WHERE role = "admin" AND is_active = 1'
      )?.c ?? 0;
      const targetUser = sqliteService.queryOne<any>('SELECT role FROM users WHERE id = ?', [userId]);
      if (targetUser?.role === 'admin' && adminCount <= 1) {
        throw new Error('Cannot deactivate the sole active Administrator account.');
      }
    }
    sqliteService.run('UPDATE users SET is_active = ? WHERE id = ?', [isActive ? 1 : 0, userId]);
  }
}

export const authService = new AuthService();
