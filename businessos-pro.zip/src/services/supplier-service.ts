import { sqliteService } from '../db/sqlite-service';
import { Purchase, PurchaseItem, PurchaseStatus, Supplier } from '../types';

export interface CreateSupplierInput {
  name: string;
  contactPerson?: string;
  email?: string;
  phone: string;
  address?: string;
  taxId?: string;
}

export interface PurchaseLineItemInput {
  productId: string;
  quantity: number;
  unitCost: number;
}

export interface CreatePurchaseInput {
  supplierId: string;
  orderDate: string;
  items: PurchaseLineItemInput[];
  status: PurchaseStatus;
  taxTotal?: number;
  amountPaid?: number;
  notes?: string;
  receivedByName: string;
}

class SupplierService {
  public getSuppliers(search?: string): Supplier[] {
    let sql = `SELECT * FROM suppliers`;
    const params: any[] = [];

    if (search && search.trim()) {
      const q = `%${search.trim().toLowerCase()}%`;
      sql += ' WHERE LOWER(name) LIKE ? OR phone LIKE ? OR LOWER(contact_person) LIKE ?';
      params.push(q, q, q);
    }

    sql += ' ORDER BY name ASC';
    const rows = sqliteService.query<any>(sql, params);
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      contactPerson: r.contact_person,
      email: r.email,
      phone: r.phone,
      address: r.address,
      taxId: r.tax_id,
      totalPurchased: r.total_purchased,
      outstandingBalance: r.outstanding_balance,
      createdAt: r.created_at,
    }));
  }

  public getSupplierById(id: string): Supplier | null {
    const r = sqliteService.queryOne<any>('SELECT * FROM suppliers WHERE id = ?', [id]);
    if (!r) return null;
    return {
      id: r.id,
      name: r.name,
      contactPerson: r.contact_person,
      email: r.email,
      phone: r.phone,
      address: r.address,
      taxId: r.tax_id,
      totalPurchased: r.total_purchased,
      outstandingBalance: r.outstanding_balance,
      createdAt: r.created_at,
    };
  }

  public createSupplier(input: CreateSupplierInput): Supplier {
    const name = input.name.trim();
    const phone = input.phone.trim();
    if (!name) throw new Error('Supplier company name is required.');
    if (!phone) throw new Error('Supplier phone number is required.');

    const id = 'sup_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const nowIso = new Date().toISOString();

    sqliteService.run(
      `INSERT INTO suppliers (
        id, name, contact_person, email, phone, address, tax_id, total_purchased, outstanding_balance, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, ?)`,
      [
        id,
        name,
        input.contactPerson?.trim() || null,
        input.email?.trim() || null,
        phone,
        input.address?.trim() || null,
        input.taxId?.trim() || null,
        nowIso,
      ]
    );

    return {
      id,
      name,
      contactPerson: input.contactPerson,
      email: input.email,
      phone,
      address: input.address,
      taxId: input.taxId,
      totalPurchased: 0,
      outstandingBalance: 0,
      createdAt: nowIso,
    };
  }

  public updateSupplier(id: string, input: Partial<CreateSupplierInput>): void {
    const existing = this.getSupplierById(id);
    if (!existing) throw new Error('Supplier not found.');

    const name = input.name !== undefined ? input.name.trim() : existing.name;
    const contactPerson = input.contactPerson !== undefined ? input.contactPerson.trim() : existing.contactPerson;
    const email = input.email !== undefined ? input.email.trim() : existing.email;
    const phone = input.phone !== undefined ? input.phone.trim() : existing.phone;
    const address = input.address !== undefined ? input.address.trim() : existing.address;
    const taxId = input.taxId !== undefined ? input.taxId.trim() : existing.taxId;

    sqliteService.run(
      `UPDATE suppliers SET name = ?, contact_person = ?, email = ?, phone = ?, address = ?, tax_id = ? WHERE id = ?`,
      [name, contactPerson, email, phone, address, taxId, id]
    );
  }

  public generatePurchaseNumber(): string {
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const prefix = `PO-${today}-`;
    const last = sqliteService.queryOne<any>(
      'SELECT purchase_number FROM purchases WHERE purchase_number LIKE ? ORDER BY purchase_number DESC LIMIT 1',
      [`${prefix}%`]
    );
    let nextSeq = 1;
    if (last?.purchase_number) {
      const parts = last.purchase_number.split('-');
      const parsed = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(parsed)) nextSeq = parsed + 1;
    }
    return `${prefix}${String(nextSeq).padStart(4, '0')}`;
  }

  /**
   * Create a purchase order with items; if status is 'received', replenishes inventory atomically
   */
  public createPurchase(input: CreatePurchaseInput): Purchase {
    if (!input.items || input.items.length === 0) {
      throw new Error('Purchase order must contain at least one line item.');
    }

    const supplier = this.getSupplierById(input.supplierId);
    if (!supplier) throw new Error('Supplier not found.');

    return sqliteService.transaction(() => {
      const purchaseId = 'po_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      const purchaseNumber = this.generatePurchaseNumber();
      const nowIso = new Date().toISOString();

      let subtotal = 0;
      const preparedLines: {
        id: string;
        productId: string;
        productName: string;
        sku: string;
        quantity: number;
        unitCost: number;
        totalCost: number;
      }[] = [];

      for (const item of input.items) {
        if (item.quantity <= 0) throw new Error('Item quantity must be greater than zero.');
        if (item.unitCost < 0) throw new Error('Unit cost cannot be negative.');

        const product = sqliteService.queryOne<any>('SELECT id, name, sku, current_stock FROM products WHERE id = ?', [
          item.productId,
        ]);
        if (!product) throw new Error(`Product not found with ID ${item.productId}`);

        const lineTotal = Number((item.quantity * item.unitCost).toFixed(2));
        subtotal += lineTotal;

        preparedLines.push({
          id: 'pi_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          productId: product.id,
          productName: product.name,
          sku: product.sku,
          quantity: item.quantity,
          unitCost: item.unitCost,
          totalCost: lineTotal,
        });

        // If received immediately, update product stock & cost
        if (input.status === 'received') {
          const newStock = Number((product.current_stock + item.quantity).toFixed(3));
          sqliteService.run(
            'UPDATE products SET current_stock = ?, purchase_cost = ?, updated_at = ? WHERE id = ?',
            [newStock, item.unitCost, nowIso, product.id]
          );

          sqliteService.run(
            `INSERT INTO stock_movements (
              id, product_id, movement_type, quantity_change, stock_after, unit_cost, reference_id, notes, created_by_name, created_at
            ) VALUES (?, ?, 'purchase', ?, ?, ?, ?, 'Stock Received from Supplier', ?, ?)`,
            [
              'sm_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
              product.id,
              item.quantity,
              newStock,
              item.unitCost,
              purchaseNumber,
              input.receivedByName,
              nowIso,
            ]
          );
        }
      }

      const taxTotal = input.taxTotal ?? 0;
      const grandTotal = Number((subtotal + taxTotal).toFixed(2));
      const amountPaid = input.amountPaid ?? 0;
      const due = grandTotal - amountPaid;
      const paymentStatus = due <= 0 ? 'paid' : amountPaid > 0 ? 'partial' : 'unpaid';

      // Insert Purchase record
      sqliteService.run(
        `INSERT INTO purchases (
          id, purchase_number, supplier_id, order_date, received_date, status,
          subtotal, tax_total, grand_total, amount_paid, payment_status, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          purchaseId,
          purchaseNumber,
          input.supplierId,
          input.orderDate,
          input.status === 'received' ? nowIso : null,
          input.status,
          subtotal,
          taxTotal,
          grandTotal,
          amountPaid,
          paymentStatus,
          input.notes || null,
          nowIso,
        ]
      );

      // Insert line items
      for (const line of preparedLines) {
        sqliteService.run(
          `INSERT INTO purchase_items (id, purchase_id, product_id, product_name, sku, quantity, unit_cost, total_cost)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [line.id, purchaseId, line.productId, line.productName, line.sku, line.quantity, line.unitCost, line.totalCost]
        );
      }

      // Update supplier totals
      const unpaidBalanceIncrement = due > 0 ? due : 0;
      sqliteService.run(
        `UPDATE suppliers SET
          total_purchased = total_purchased + ?,
          outstanding_balance = outstanding_balance + ?
         WHERE id = ?`,
        [grandTotal, unpaidBalanceIncrement, input.supplierId]
      );

      return {
        id: purchaseId,
        purchaseNumber,
        supplierId: input.supplierId,
        supplierName: supplier.name,
        orderDate: input.orderDate,
        receivedDate: input.status === 'received' ? nowIso : undefined,
        status: input.status,
        subtotal,
        taxTotal,
        grandTotal,
        amountPaid,
        paymentStatus,
        notes: input.notes,
        items: preparedLines.map((l) => ({ ...l, purchaseId })),
        createdAt: nowIso,
      };
    });
  }

  /**
   * Receive ordered stock and replenish inventory
   */
  public receiveStock(purchaseId: string, receivedByName: string): void {
    const purchase = sqliteService.queryOne<any>('SELECT * FROM purchases WHERE id = ?', [purchaseId]);
    if (!purchase) throw new Error('Purchase order not found.');
    if (purchase.status === 'received') throw new Error('Purchase order has already been received.');

    const items = sqliteService.query<any>('SELECT * FROM purchase_items WHERE purchase_id = ?', [purchaseId]);
    const nowIso = new Date().toISOString();

    sqliteService.transaction(() => {
      for (const item of items) {
        const prod = sqliteService.queryOne<any>('SELECT current_stock FROM products WHERE id = ?', [item.product_id]);
        if (prod) {
          const newStock = Number((prod.current_stock + item.quantity).toFixed(3));
          sqliteService.run(
            'UPDATE products SET current_stock = ?, purchase_cost = ?, updated_at = ? WHERE id = ?',
            [newStock, item.unit_cost, nowIso, item.product_id]
          );

          sqliteService.run(
            `INSERT INTO stock_movements (
              id, product_id, movement_type, quantity_change, stock_after, unit_cost, reference_id, notes, created_by_name, created_at
            ) VALUES (?, ?, 'purchase', ?, ?, ?, ?, 'Stock Received from Purchase Order', ?, ?)`,
            [
              'sm_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
              item.product_id,
              item.quantity,
              newStock,
              item.unit_cost,
              purchase.purchase_number,
              receivedByName,
              nowIso,
            ]
          );
        }
      }

      sqliteService.run(
        'UPDATE purchases SET status = "received", received_date = ? WHERE id = ?',
        [nowIso, purchaseId]
      );
    });
  }

  public getPurchases(limit: number = 50): Purchase[] {
    const rows = sqliteService.query<any>(
      `SELECT p.*, s.name as supplier_name
       FROM purchases p
       LEFT JOIN suppliers s ON p.supplier_id = s.id
       ORDER BY p.order_date DESC, p.created_at DESC
       LIMIT ?`,
      [limit]
    );
    return rows.map((r) => ({
      id: r.id,
      purchaseNumber: r.purchase_number,
      supplierId: r.supplier_id,
      supplierName: r.supplier_name || 'Unknown Supplier',
      orderDate: r.order_date,
      receivedDate: r.received_date,
      status: r.status,
      subtotal: r.subtotal,
      taxTotal: r.tax_total,
      grandTotal: r.grand_total,
      amountPaid: r.amount_paid,
      paymentStatus: r.payment_status,
      notes: r.notes,
      createdAt: r.created_at,
    }));
  }

  public getPurchaseWithItems(purchaseId: string): Purchase | null {
    const p = sqliteService.queryOne<any>(
      `SELECT p.*, s.name as supplier_name
       FROM purchases p
       LEFT JOIN suppliers s ON p.supplier_id = s.id
       WHERE p.id = ?`,
      [purchaseId]
    );
    if (!p) return null;

    const items = sqliteService.query<any>('SELECT * FROM purchase_items WHERE purchase_id = ?', [purchaseId]);
    return {
      id: p.id,
      purchaseNumber: p.purchase_number,
      supplierId: p.supplier_id,
      supplierName: p.supplier_name || 'Unknown Supplier',
      orderDate: p.order_date,
      receivedDate: p.received_date,
      status: p.status,
      subtotal: p.subtotal,
      taxTotal: p.tax_total,
      grandTotal: p.grand_total,
      amountPaid: p.amount_paid,
      paymentStatus: p.payment_status,
      notes: p.notes,
      createdAt: p.created_at,
      items: items.map((i) => ({
        id: i.id,
        purchaseId: i.purchase_id,
        productId: i.product_id,
        productName: i.product_name,
        sku: i.sku,
        quantity: i.quantity,
        unitCost: i.unit_cost,
        totalCost: i.total_cost,
      })),
    };
  }
}

export const supplierService = new SupplierService();
