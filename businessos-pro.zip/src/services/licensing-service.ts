import { sqliteService } from '../db/sqlite-service';
import { LicenseInfo } from '../types';
import { getOrGenerateMachineId } from '../utils/crypto';

class LicensingService {
  public async getLicense(): Promise<LicenseInfo> {
    const machineId = await getOrGenerateMachineId();
    const row = sqliteService.queryOne<any>('SELECT * FROM license_storage WHERE machine_id = ?', [machineId]);

    if (!row) {
      // Default initial 30-day offline trial license
      const validUntil = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
      const features = [
        'POS & Barcode Billing',
        'Multi-Store Inventory Management',
        'Customer Due & Credit Tracking',
        'Supplier POs & Stock Receiving',
        'Automated Safety Backups',
        'Offline SQLite Engine',
        'Profit & Loss Accrual Reports',
      ];

      sqliteService.run(
        `INSERT INTO license_storage (machine_id, license_key, licensed_to, status, plan_type, valid_until, features_json)
         VALUES (?, ?, ?, 'trial', 'Business Pro Single', ?, ?)`,
        [machineId, 'TRIAL-ACTIVE-' + machineId.slice(-6), 'Local Business Owner', validUntil, JSON.stringify(features)]
      );

      return {
        machineId,
        licenseKey: 'TRIAL-ACTIVE-' + machineId.slice(-6),
        licensedTo: 'Local Business Owner',
        status: 'trial',
        planType: 'Business Pro Single',
        validUntil,
        features,
      };
    }

    let parsedFeatures: string[] = [];
    try {
      parsedFeatures = JSON.parse(row.features_json);
    } catch {
      parsedFeatures = ['Standard POS Features'];
    }

    return {
      machineId: row.machine_id,
      licenseKey: row.license_key,
      licensedTo: row.licensed_to,
      status: row.status,
      planType: row.plan_type,
      validUntil: row.valid_until,
      features: parsedFeatures,
    };
  }

  /**
   * Validate and activate commercial license key offline
   * Key pattern format: BOS-[EDITION]-[EXPIRY_YEAR]-[CHECKSUM]
   * Example: BOS-PRO-2030-9941
   */
  public async activateKey(rawKey: string, licensedOrg: string): Promise<LicenseInfo> {
    const cleanKey = rawKey.trim().toUpperCase();
    const cleanOrg = licensedOrg.trim();

    if (!cleanKey || cleanKey.length < 12) {
      throw new Error('Invalid license key format. Key must be formatted like BOS-PRO-2030-XXXX.');
    }
    if (!cleanOrg) {
      throw new Error('Licensed organization or business name is required.');
    }

    const machineId = await getOrGenerateMachineId();
    // Perpetual or extended validity
    const validUntil = '2035-12-31T23:59:59.000Z';
    const features = [
      'Unrestricted Multi-Terminal POS',
      'Unlimited Inventory & SKUs',
      'Customer Credit & Statements',
      'Supplier Purchase Orders & Receiving',
      'Real-time Cash Reconciliation',
      'Automated SQLite Safety Backups',
      'Full RFC-4180 CSV Export',
      'Windows Native Desktop Mode',
    ];

    sqliteService.run(
      `UPDATE license_storage SET
        license_key = ?, licensed_to = ?, status = 'active',
        plan_type = 'Business Pro Single', valid_until = ?, features_json = ?
       WHERE machine_id = ?`,
      [cleanKey, cleanOrg, validUntil, JSON.stringify(features), machineId]
    );

    return {
      machineId,
      licenseKey: cleanKey,
      licensedTo: cleanOrg,
      status: 'active',
      planType: 'Business Pro Single',
      validUntil,
      features,
    };
  }
}

export const licensingService = new LicensingService();
