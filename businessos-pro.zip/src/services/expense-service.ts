import { sqliteService } from '../db/sqlite-service';
import { CashReconciliation, Expense, ExpenseCategory, PaymentMethod } from '../types';

export interface CreateExpenseInput {
  categoryId: string;
  amount: number;
  paymentMethod: PaymentMethod;
  description: string;
  paidTo?: string;
}

class ExpenseService {
  public getExpenseCategories(): ExpenseCategory[] {
    const rows = sqliteService.query<any>('SELECT * FROM expense_categories ORDER BY name ASC');
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      description: r.description,
    }));
  }

  public createExpenseCategory(name: string, description: string = ''): ExpenseCategory {
    const cleanName = name.trim();
    if (!cleanName) throw new Error('Category name cannot be empty.');

    const existing = sqliteService.queryOne('SELECT id FROM expense_categories WHERE name = ? COLLATE NOCASE', [
      cleanName,
    ]);
    if (existing) throw new Error(`Expense category "${cleanName}" already exists.`);

    const id = 'expcat_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    sqliteService.run('INSERT INTO expense_categories (id, name, description) VALUES (?, ?, ?)', [
      id,
      cleanName,
      description.trim(),
    ]);

    return { id, name: cleanName, description };
  }

  public getExpenses(dateFilter?: { start?: string; end?: string; categoryId?: string }): Expense[] {
    let sql = `
      SELECT e.*, c.name as category_name
      FROM expenses e
      LEFT JOIN expense_categories c ON e.category_id = c.id
      WHERE 1=1
    `;
    const params: any[] = [];

    if (dateFilter?.start) {
      sql += ' AND e.created_at >= ?';
      params.push(dateFilter.start);
    }

    if (dateFilter?.end) {
      sql += ' AND e.created_at <= ?';
      params.push(dateFilter.end + 'T23:59:59.999Z');
    }

    if (dateFilter?.categoryId && dateFilter.categoryId !== 'all') {
      sql += ' AND e.category_id = ?';
      params.push(dateFilter.categoryId);
    }

    sql += ' ORDER BY e.created_at DESC';

    const rows = sqliteService.query<any>(sql, params);
    return rows.map((r) => ({
      id: r.id,
      categoryId: r.category_id,
      categoryName: r.category_name || 'General Expense',
      amount: r.amount,
      paymentMethod: r.payment_method as PaymentMethod,
      description: r.description,
      paidTo: r.paid_to,
      recordedBy: r.recorded_by,
      receiptUrl: r.receipt_url,
      createdAt: r.created_at,
    }));
  }

  public recordExpense(input: CreateExpenseInput, recordedByName: string): Expense {
    if (input.amount <= 0) {
      throw new Error('Expense amount must be greater than zero.');
    }
    if (!input.description.trim()) {
      throw new Error('Expense description is required.');
    }

    const id = 'exp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const nowIso = new Date().toISOString();

    sqliteService.run(
      `INSERT INTO expenses (id, category_id, amount, payment_method, description, paid_to, recorded_by, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        input.categoryId,
        input.amount,
        input.paymentMethod,
        input.description.trim(),
        input.paidTo?.trim() || null,
        recordedByName,
        nowIso,
      ]
    );

    const category = sqliteService.queryOne<any>('SELECT name FROM expense_categories WHERE id = ?', [
      input.categoryId,
    ]);

    return {
      id,
      categoryId: input.categoryId,
      categoryName: category?.name || 'General Expense',
      amount: input.amount,
      paymentMethod: input.paymentMethod,
      description: input.description.trim(),
      paidTo: input.paidTo,
      recordedBy: recordedByName,
      createdAt: nowIso,
    };
  }

  /**
   * Calculate daily cash drawer expected total and reconcile actual cash count
   */
  public calculateCashDrawerForDate(dateIso: string): {
    cashSales: number;
    cashPaymentsReceived: number;
    cashExpenses: number;
    netCashMovement: number;
  } {
    const dayStart = dateIso.slice(0, 10) + 'T00:00:00.000Z';
    const dayEnd = dateIso.slice(0, 10) + 'T23:59:59.999Z';

    // 1. Cash sales: direct cash sales or split payments with cash
    const cashSalesRow = sqliteService.queryOne<any>(
      `SELECT coalesce(sum(amount_paid), 0) as s
       FROM sales
       WHERE payment_method = 'cash' AND status != 'cancelled' AND created_at BETWEEN ? AND ?`,
      [dayStart, dayEnd]
    );
    const cashSales = cashSalesRow?.s ?? 0;

    // 2. Customer payments received in cash
    const cashPaymentsRow = sqliteService.queryOne<any>(
      `SELECT coalesce(sum(amount), 0) as p
       FROM customer_payments
       WHERE payment_method = 'cash' AND created_at BETWEEN ? AND ?`,
      [dayStart, dayEnd]
    );
    const cashPaymentsReceived = cashPaymentsRow?.p ?? 0;

    // 3. Cash expenses paid from register
    const cashExpensesRow = sqliteService.queryOne<any>(
      `SELECT coalesce(sum(amount), 0) as e
       FROM expenses
       WHERE payment_method = 'cash' AND created_at BETWEEN ? AND ?`,
      [dayStart, dayEnd]
    );
    const cashExpenses = cashExpensesRow?.e ?? 0;

    const netCashMovement = Number((cashSales + cashPaymentsReceived - cashExpenses).toFixed(2));

    return {
      cashSales: Number(cashSales.toFixed(2)),
      cashPaymentsReceived: Number(cashPaymentsReceived.toFixed(2)),
      cashExpenses: Number(cashExpenses.toFixed(2)),
      netCashMovement,
    };
  }

  public getDailyReconciliation(dateString: string): CashReconciliation | null {
    const dayKey = dateString.slice(0, 10);
    const row = sqliteService.queryOne<any>('SELECT * FROM cash_reconciliations WHERE date = ?', [dayKey]);
    if (!row) return null;
    return {
      id: row.id,
      date: row.date,
      openingFloat: row.opening_float,
      cashSalesTotal: row.cash_sales_total,
      cashPaymentsReceivedTotal: row.cash_payments_received_total,
      cashExpensesTotal: row.cash_expenses_total,
      expectedCashTotal: row.expected_cash_total,
      actualCountedCash: row.actual_counted_cash,
      variance: row.variance,
      reconciledBy: row.reconciled_by,
      notes: row.notes,
      createdAt: row.created_at,
    };
  }

  public submitDailyReconciliation(
    dateString: string,
    openingFloat: number,
    actualCountedCash: number,
    reconciledBy: string,
    notes?: string
  ): CashReconciliation {
    const dayKey = dateString.slice(0, 10);
    const calc = this.calculateCashDrawerForDate(dayKey);
    const expectedCashTotal = Number((openingFloat + calc.netCashMovement).toFixed(2));
    const variance = Number((actualCountedCash - expectedCashTotal).toFixed(2));

    const id = 'reconcile_' + dayKey;
    const nowIso = new Date().toISOString();

    sqliteService.run(
      `INSERT OR REPLACE INTO cash_reconciliations (
        id, date, opening_float, cash_sales_total, cash_payments_received_total,
        cash_expenses_total, expected_cash_total, actual_counted_cash, variance,
        reconciled_by, notes, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        dayKey,
        openingFloat,
        calc.cashSales,
        calc.cashPaymentsReceived,
        calc.cashExpenses,
        expectedCashTotal,
        actualCountedCash,
        variance,
        reconciledBy,
        notes || null,
        nowIso,
      ]
    );

    return {
      id,
      date: dayKey,
      openingFloat,
      cashSalesTotal: calc.cashSales,
      cashPaymentsReceivedTotal: calc.cashPaymentsReceived,
      cashExpensesTotal: calc.cashExpenses,
      expectedCashTotal,
      actualCountedCash,
      variance,
      reconciledBy,
      notes,
      createdAt: nowIso,
    };
  }
}

export const expenseService = new ExpenseService();
