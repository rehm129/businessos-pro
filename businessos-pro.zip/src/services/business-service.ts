import { sqliteService } from '../db/sqlite-service';
import { BusinessProfile } from '../types';

class BusinessService {
  public getProfile(): BusinessProfile {
    const row = sqliteService.queryOne<any>('SELECT * FROM business_profile LIMIT 1');
    if (!row) {
      throw new Error('Business profile has not been initialized.');
    }
    return {
      id: row.id,
      name: row.name,
      legalName: row.legal_name,
      tagline: row.tagline,
      businessType: row.business_type,
      phone: row.phone,
      email: row.email,
      address: row.address,
      currencyCode: row.currency_code,
      currencySymbol: row.currency_symbol,
      taxRatePercent: row.tax_rate_percent,
      taxNumber: row.tax_number,
      enableTax: Boolean(row.enable_tax),
      receiptFooterMessage: row.receipt_footer_message,
      allowNegativeStock: Boolean(row.allow_negative_stock),
      enableSplitPayments: Boolean(row.enable_split_payments),
      barcodeScannerPrefix: row.barcode_scanner_prefix,
      lowStockThresholdDefault: row.low_stock_threshold_default,
      updatedAt: row.updated_at,
    };
  }

  public updateProfile(input: Partial<BusinessProfile>): BusinessProfile {
    const current = this.getProfile();
    const nowIso = new Date().toISOString();

    const name = input.name !== undefined ? input.name.trim() : current.name;
    const legalName = input.legalName !== undefined ? input.legalName.trim() : current.legalName;
    const tagline = input.tagline !== undefined ? input.tagline.trim() : current.tagline;
    const businessType = input.businessType !== undefined ? input.businessType : current.businessType;
    const phone = input.phone !== undefined ? input.phone.trim() : current.phone;
    const email = input.email !== undefined ? input.email.trim() : current.email;
    const address = input.address !== undefined ? input.address.trim() : current.address;
    const currencyCode = input.currencyCode !== undefined ? input.currencyCode.trim().toUpperCase() : current.currencyCode;
    const currencySymbol = input.currencySymbol !== undefined ? input.currencySymbol.trim() : current.currencySymbol;
    const taxRatePercent = input.taxRatePercent !== undefined ? input.taxRatePercent : current.taxRatePercent;
    const taxNumber = input.taxNumber !== undefined ? input.taxNumber.trim() : current.taxNumber;
    const enableTax = input.enableTax !== undefined ? (input.enableTax ? 1 : 0) : current.enableTax ? 1 : 0;
    const receiptFooterMessage =
      input.receiptFooterMessage !== undefined ? input.receiptFooterMessage.trim() : current.receiptFooterMessage;
    const allowNegativeStock =
      input.allowNegativeStock !== undefined
        ? input.allowNegativeStock
          ? 1
          : 0
        : current.allowNegativeStock
        ? 1
        : 0;
    const enableSplitPayments =
      input.enableSplitPayments !== undefined
        ? input.enableSplitPayments
          ? 1
          : 0
        : current.enableSplitPayments
        ? 1
        : 0;
    const barcodeScannerPrefix =
      input.barcodeScannerPrefix !== undefined ? input.barcodeScannerPrefix.trim() : current.barcodeScannerPrefix;
    const lowStockThresholdDefault =
      input.lowStockThresholdDefault !== undefined
        ? input.lowStockThresholdDefault
        : current.lowStockThresholdDefault;

    sqliteService.run(
      `UPDATE business_profile SET
        name = ?, legal_name = ?, tagline = ?, business_type = ?, phone = ?, email = ?,
        address = ?, currency_code = ?, currency_symbol = ?, tax_rate_percent = ?,
        tax_number = ?, enable_tax = ?, receipt_footer_message = ?, allow_negative_stock = ?,
        enable_split_payments = ?, barcode_scanner_prefix = ?, low_stock_threshold_default = ?,
        updated_at = ?
       WHERE id = ?`,
      [
        name,
        legalName,
        tagline,
        businessType,
        phone,
        email,
        address,
        currencyCode,
        currencySymbol,
        taxRatePercent,
        taxNumber,
        enableTax,
        receiptFooterMessage,
        allowNegativeStock,
        enableSplitPayments,
        barcodeScannerPrefix,
        lowStockThresholdDefault,
        nowIso,
        current.id,
      ]
    );

    return this.getProfile();
  }
}

export const businessService = new BusinessService();
