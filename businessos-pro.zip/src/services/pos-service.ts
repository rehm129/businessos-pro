import { sqliteService } from '../db/sqlite-service';
import { PaymentMethod, Sale, SaleItem, SalePaymentSplit, SaleReturn } from '../types';

export interface CartItemInput {
  productId: string;
  quantity: number;
  unitPrice: number;
  discountPercent?: number;
}

export interface CheckoutInput {
  customerId?: string;
  items: CartItemInput[];
  paymentMethod: PaymentMethod;
  splits?: SalePaymentSplit[];
  amountPaid: number;
  notes?: string;
  cashierId: string;
  cashierName: string;
}

export interface ReturnItemInput {
  productId: string;
  quantity: number;
}

export interface ProcessReturnInput {
  saleId: string;
  items: ReturnItemInput[];
  reason: string;
  restockItems: boolean;
  processedBy: string;
}

class PosService {
  /**
   * Generate next sequential receipt number (e.g., REC-20261016-0001)
   */
  public generateReceiptNumber(): string {
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const prefix = `REC-${today}-`;
    const lastSale = sqliteService.queryOne<any>(
      'SELECT receipt_number FROM sales WHERE receipt_number LIKE ? ORDER BY receipt_number DESC LIMIT 1',
      [`${prefix}%`]
    );

    let nextSeq = 1;
    if (lastSale?.receipt_number) {
      const parts = lastSale.receipt_number.split('-');
      const lastSeq = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(lastSeq)) {
        nextSeq = lastSeq + 1;
      }
    }

    return `${prefix}${String(nextSeq).padStart(4, '0')}`;
  }

  /**
   * Process and finalize a complete sale with atomic transaction safety
   */
  public checkout(input: CheckoutInput): Sale {
    if (!input.items || input.items.length === 0) {
      throw new Error('Cart cannot be empty for checkout.');
    }

    const profile = sqliteService.queryOne<any>('SELECT * FROM business_profile LIMIT 1');
    const allowNegativeStock = Boolean(profile?.allow_negative_stock);
    const taxRate = profile?.enable_tax ? (profile?.tax_rate_percent ?? 0) / 100 : 0;

    return sqliteService.transaction(() => {
      const saleId = 'sale_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
      const receiptNumber = this.generateReceiptNumber();
      const nowIso = new Date().toISOString();

      let subtotal = 0;
      let discountTotal = 0;
      let taxTotal = 0;
      let costTotal = 0;

      const preparedItems: {
        id: string;
        productId: string;
        productName: string;
        sku: string;
        quantity: number;
        unitCost: number;
        unitPrice: number;
        discountPercent: number;
        discountAmount: number;
        taxAmount: number;
        total: number;
      }[] = [];

      // 1. Validate all products and stock availability before writing
      for (const item of input.items) {
        if (item.quantity <= 0) {
          throw new Error('Item quantity must be greater than zero.');
        }

        const product = sqliteService.queryOne<any>(
          'SELECT id, name, sku, purchase_cost, selling_price, current_stock, is_archived FROM products WHERE id = ?',
          [item.productId]
        );

        if (!product) {
          throw new Error(`Product with ID "${item.productId}" does not exist.`);
        }

        if (product.is_archived) {
          throw new Error(`Product "${product.name}" is archived and cannot be sold.`);
        }

        const newStock = Number((product.current_stock - item.quantity).toFixed(3));
        if (newStock < 0 && !allowNegativeStock) {
          throw new Error(
            `Insufficient stock for "${product.name}". Available: ${product.current_stock}, requested: ${item.quantity}.`
          );
        }

        const discPercent = item.discountPercent ?? 0;
        const lineGross = item.unitPrice * item.quantity;
        const discAmount = Number(((lineGross * discPercent) / 100).toFixed(2));
        const lineNet = lineGross - discAmount;
        const lineTax = Number((lineNet * taxRate).toFixed(2));
        const lineTotal = Number((lineNet + lineTax).toFixed(2));
        const lineCost = Number((product.purchase_cost * item.quantity).toFixed(2));

        subtotal += lineNet;
        discountTotal += discAmount;
        taxTotal += lineTax;
        costTotal += lineCost;

        preparedItems.push({
          id: 'si_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
          productId: product.id,
          productName: product.name,
          sku: product.sku,
          quantity: item.quantity,
          unitCost: product.purchase_cost,
          unitPrice: item.unitPrice,
          discountPercent: discPercent,
          discountAmount: discAmount,
          taxAmount: lineTax,
          total: lineTotal,
        });

        // Deduct inventory
        sqliteService.run('UPDATE products SET current_stock = ?, updated_at = ? WHERE id = ?', [
          newStock,
          nowIso,
          product.id,
        ]);

        // Record stock movement
        sqliteService.run(
          `INSERT INTO stock_movements (
            id, product_id, movement_type, quantity_change, stock_after, unit_cost, reference_id, notes, created_by_name, created_at
          ) VALUES (?, ?, 'sale', ?, ?, ?, ?, 'POS Sale Checkout', ?, ?)`,
          [
            'sm_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
            product.id,
            -item.quantity,
            newStock,
            product.purchase_cost,
            receiptNumber,
            input.cashierName,
            nowIso,
          ]
        );
      }

      const grandTotal = Number((subtotal + taxTotal).toFixed(2));
      const estimatedProfit = Number((subtotal - costTotal).toFixed(2));
      const amountPaid = input.amountPaid;
      const changeGiven = amountPaid > grandTotal ? Number((amountPaid - grandTotal).toFixed(2)) : 0;

      // Customer info lookup
      let customerName = 'Walk-in Retail Customer';
      if (input.customerId) {
        const cust = sqliteService.queryOne<any>('SELECT name FROM customers WHERE id = ?', [input.customerId]);
        if (cust) customerName = cust.name;
      }

      const paymentDetailsJson = input.splits && input.splits.length > 0 ? JSON.stringify(input.splits) : null;

      // Insert Sale
      sqliteService.run(
        `INSERT INTO sales (
          id, receipt_number, customer_id, subtotal, discount_total, tax_total, grand_total,
          cost_total, estimated_profit, payment_method, payment_details, amount_paid, change_given,
          status, cashier_id, cashier_name, notes, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', ?, ?, ?, ?)`,
        [
          saleId,
          receiptNumber,
          input.customerId || null,
          subtotal,
          discountTotal,
          taxTotal,
          grandTotal,
          costTotal,
          estimatedProfit,
          input.paymentMethod,
          paymentDetailsJson,
          amountPaid,
          changeGiven,
          input.cashierId,
          input.cashierName,
          input.notes || null,
          nowIso,
        ]
      );

      // Insert Sale Items
      for (const line of preparedItems) {
        sqliteService.run(
          `INSERT INTO sale_items (
            id, sale_id, product_id, product_name, sku, quantity, unit_cost, unit_price,
            discount_percent, discount_amount, tax_amount, total
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            line.id,
            saleId,
            line.productId,
            line.productName,
            line.sku,
            line.quantity,
            line.unitCost,
            line.unitPrice,
            line.discountPercent,
            line.discountAmount,
            line.taxAmount,
            line.total,
          ]
        );
      }

      // Customer store credit / ledger adjustment if partial or credit sale
      if (input.customerId && input.paymentMethod === 'store_credit') {
        const unpaidDifference = grandTotal - amountPaid;
        if (unpaidDifference > 0) {
          sqliteService.run(
            'UPDATE customers SET current_balance = current_balance + ? WHERE id = ?',
            [unpaidDifference, input.customerId]
          );
        }
      }

      return {
        id: saleId,
        receiptNumber,
        customerId: input.customerId,
        customerName,
        subtotal,
        discountTotal,
        taxTotal,
        grandTotal,
        costTotal,
        estimatedProfit,
        paymentMethod: input.paymentMethod,
        paymentDetails: paymentDetailsJson || undefined,
        amountPaid,
        changeGiven,
        status: 'completed',
        cashierId: input.cashierId,
        cashierName: input.cashierName,
        notes: input.notes,
        items: preparedItems.map((pi) => ({ ...pi, saleId })),
        createdAt: nowIso,
      };
    });
  }

  /**
   * Process return and refund for a completed sale
   */
  public processReturn(input: ProcessReturnInput): SaleReturn {
    if (!input.items || input.items.length === 0) {
      throw new Error('Must specify at least one item to return.');
    }

    const sale = sqliteService.queryOne<any>('SELECT * FROM sales WHERE id = ?', [input.saleId]);
    if (!sale) throw new Error('Sale not found.');
    if (sale.status === 'cancelled') throw new Error('Cannot process return for a cancelled sale.');

    const originalItems = sqliteService.query<any>('SELECT * FROM sale_items WHERE sale_id = ?', [input.saleId]);

    return sqliteService.transaction(() => {
      let refundTotal = 0;
      const returnedLineItems: any[] = [];
      const nowIso = new Date().toISOString();

      for (const returnItem of input.items) {
        if (returnItem.quantity <= 0) continue;

        const origLine = originalItems.find((oi) => oi.product_id === returnItem.productId);
        if (!origLine) {
          throw new Error(`Product ${returnItem.productId} was not part of this sale.`);
        }

        if (returnItem.quantity > origLine.quantity) {
          throw new Error(
            `Return quantity (${returnItem.quantity}) exceeds sold quantity (${origLine.quantity}) for ${origLine.product_name}.`
          );
        }

        const unitRefund = origLine.total / origLine.quantity;
        const lineRefund = Number((unitRefund * returnItem.quantity).toFixed(2));
        refundTotal += lineRefund;

        returnedLineItems.push({
          productId: origLine.product_id,
          productName: origLine.product_name,
          quantity: returnItem.quantity,
          unitPrice: origLine.unit_price,
          refundAmount: lineRefund,
        });

        // Restock inventory if requested
        if (input.restockItems) {
          const currentProd = sqliteService.queryOne<any>('SELECT current_stock, purchase_cost FROM products WHERE id = ?', [
            origLine.product_id,
          ]);
          if (currentProd) {
            const restoredStock = Number((currentProd.current_stock + returnItem.quantity).toFixed(3));
            sqliteService.run('UPDATE products SET current_stock = ?, updated_at = ? WHERE id = ?', [
              restoredStock,
              nowIso,
              origLine.product_id,
            ]);

            sqliteService.run(
              `INSERT INTO stock_movements (
                id, product_id, movement_type, quantity_change, stock_after, unit_cost, reference_id, notes, created_by_name, created_at
              ) VALUES (?, ?, 'sale_return', ?, ?, ?, ?, ?, ?, ?)`,
              [
                'sm_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
                origLine.product_id,
                returnItem.quantity,
                restoredStock,
                currentProd.purchase_cost,
                sale.receipt_number,
                `Customer Return: ${input.reason}`,
                input.processedBy,
                nowIso,
              ]
            );
          }
        }
      }

      // Record in sale_returns
      const returnId = 'ret_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
      sqliteService.run(
        `INSERT INTO sale_returns (
          id, sale_id, receipt_number, refund_total, restock_items, reason, processed_by, created_at, items_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          returnId,
          sale.id,
          sale.receipt_number,
          refundTotal,
          input.restockItems ? 1 : 0,
          input.reason,
          input.processedBy,
          nowIso,
          JSON.stringify(returnedLineItems),
        ]
      );

      // Determine if fully or partially refunded
      const isTotalRefund = refundTotal >= sale.grand_total;
      const newStatus = isTotalRefund ? 'refunded' : 'partially_refunded';
      sqliteService.run('UPDATE sales SET status = ? WHERE id = ?', [newStatus, sale.id]);

      return {
        id: returnId,
        saleId: sale.id,
        receiptNumber: sale.receipt_number,
        refundTotal,
        restockItems: input.restockItems,
        reason: input.reason,
        processedBy: input.processedBy,
        createdAt: nowIso,
        items: returnedLineItems,
      };
    });
  }

  public getSales(limit: number = 50, dateFilter?: string): Sale[] {
    let sql = `
      SELECT s.*, c.name as customer_name
      FROM sales s
      LEFT JOIN customers c ON s.customer_id = c.id
    `;
    const params: any[] = [];

    if (dateFilter) {
      sql += ' WHERE s.created_at >= ?';
      params.push(dateFilter);
    }

    sql += ' ORDER BY s.created_at DESC LIMIT ?';
    params.push(limit);

    const rows = sqliteService.query<any>(sql, params);
    return rows.map((r) => ({
      id: r.id,
      receiptNumber: r.receipt_number,
      customerId: r.customer_id,
      customerName: r.customer_name || 'Walk-in Retail Customer',
      subtotal: r.subtotal,
      discountTotal: r.discount_total,
      taxTotal: r.tax_total,
      grandTotal: r.grand_total,
      costTotal: r.cost_total,
      estimatedProfit: r.estimated_profit,
      paymentMethod: r.payment_method as PaymentMethod,
      paymentDetails: r.payment_details,
      amountPaid: r.amount_paid,
      changeGiven: r.change_given,
      status: r.status,
      cashierId: r.cashier_id,
      cashierName: r.cashier_name,
      notes: r.notes,
      createdAt: r.created_at,
    }));
  }

  public getSaleWithItems(saleId: string): Sale | null {
    const s = sqliteService.queryOne<any>(
      `SELECT s.*, c.name as customer_name
       FROM sales s
       LEFT JOIN customers c ON s.customer_id = c.id
       WHERE s.id = ?`,
      [saleId]
    );
    if (!s) return null;

    const items = sqliteService.query<any>('SELECT * FROM sale_items WHERE sale_id = ?', [saleId]);
    return {
      id: s.id,
      receiptNumber: s.receipt_number,
      customerId: s.customer_id,
      customerName: s.customer_name || 'Walk-in Retail Customer',
      subtotal: s.subtotal,
      discountTotal: s.discount_total,
      taxTotal: s.tax_total,
      grandTotal: s.grand_total,
      costTotal: s.cost_total,
      estimatedProfit: s.estimated_profit,
      paymentMethod: s.payment_method,
      paymentDetails: s.payment_details,
      amountPaid: s.amount_paid,
      changeGiven: s.change_given,
      status: s.status,
      cashierId: s.cashier_id,
      cashierName: s.cashier_name,
      notes: s.notes,
      createdAt: s.created_at,
      items: items.map((i) => ({
        id: i.id,
        saleId: i.sale_id,
        productId: i.product_id,
        productName: i.product_name,
        sku: i.sku,
        quantity: i.quantity,
        unitCost: i.unit_cost,
        unitPrice: i.unit_price,
        discountPercent: i.discount_percent,
        discountAmount: i.discount_amount,
        taxAmount: i.tax_amount,
        total: i.total,
      })),
    };
  }
}

export const posService = new PosService();
