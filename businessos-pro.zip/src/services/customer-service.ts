import { sqliteService } from '../db/sqlite-service';
import { Customer, CustomerPayment, PaymentMethod } from '../types';

export interface CreateCustomerInput {
  name: string;
  phone: string;
  email?: string;
  address?: string;
  creditLimit?: number;
}

class CustomerService {
  public getCustomers(search?: string): Customer[] {
    let sql = `
      SELECT c.*,
             (SELECT count(*) FROM sales s WHERE s.customer_id = c.id) as sales_count,
             (SELECT coalesce(sum(s.grand_total), 0) FROM sales s WHERE s.customer_id = c.id) as total_spent
      FROM customers c
    `;
    const params: any[] = [];

    if (search && search.trim()) {
      const q = `%${search.trim().toLowerCase()}%`;
      sql += ' WHERE (LOWER(c.name) LIKE ? OR c.phone LIKE ? OR LOWER(c.email) LIKE ?)';
      params.push(q, q, q);
    }

    sql += ' ORDER BY c.name ASC';

    const rows = sqliteService.query<any>(sql, params);
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      phone: r.phone,
      email: r.email,
      address: r.address,
      creditLimit: r.credit_limit,
      currentBalance: r.current_balance,
      totalSalesCount: r.sales_count,
      totalSpent: r.total_spent,
      createdAt: r.created_at,
    }));
  }

  public getCustomerById(id: string): Customer | null {
    const r = sqliteService.queryOne<any>(
      `SELECT c.*,
             (SELECT count(*) FROM sales s WHERE s.customer_id = c.id) as sales_count,
             (SELECT coalesce(sum(s.grand_total), 0) FROM sales s WHERE s.customer_id = c.id) as total_spent
       FROM customers c WHERE c.id = ?`,
      [id]
    );
    if (!r) return null;
    return {
      id: r.id,
      name: r.name,
      phone: r.phone,
      email: r.email,
      address: r.address,
      creditLimit: r.credit_limit,
      currentBalance: r.current_balance,
      totalSalesCount: r.sales_count,
      totalSpent: r.total_spent,
      createdAt: r.created_at,
    };
  }

  public createCustomer(input: CreateCustomerInput): Customer {
    const name = input.name.trim();
    const phone = input.phone.trim();
    if (!name) throw new Error('Customer name is required.');
    if (!phone) throw new Error('Customer contact phone is required.');

    const id = 'cust_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const nowIso = new Date().toISOString();
    const creditLimit = input.creditLimit ?? 0;

    sqliteService.run(
      `INSERT INTO customers (id, name, phone, email, address, credit_limit, current_balance, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 0, ?)`,
      [id, name, phone, input.email?.trim() || null, input.address?.trim() || null, creditLimit, nowIso]
    );

    return {
      id,
      name,
      phone,
      email: input.email,
      address: input.address,
      creditLimit,
      currentBalance: 0,
      totalSalesCount: 0,
      totalSpent: 0,
      createdAt: nowIso,
    };
  }

  public updateCustomer(id: string, input: Partial<CreateCustomerInput>): void {
    const existing = this.getCustomerById(id);
    if (!existing) throw new Error('Customer not found.');

    const name = input.name !== undefined ? input.name.trim() : existing.name;
    const phone = input.phone !== undefined ? input.phone.trim() : existing.phone;
    const email = input.email !== undefined ? input.email.trim() : existing.email;
    const address = input.address !== undefined ? input.address.trim() : existing.address;
    const creditLimit = input.creditLimit !== undefined ? input.creditLimit : existing.creditLimit;

    sqliteService.run(
      `UPDATE customers SET name = ?, phone = ?, email = ?, address = ?, credit_limit = ? WHERE id = ?`,
      [name, phone, email, address, creditLimit, id]
    );
  }

  /**
   * Receive payment from customer against outstanding account balance
   */
  public recordPayment(
    customerId: string,
    amount: number,
    method: PaymentMethod,
    referenceNumber: string = '',
    notes: string = '',
    receivedBy: string
  ): CustomerPayment {
    if (amount <= 0) {
      throw new Error('Payment amount must be greater than zero.');
    }

    return sqliteService.transaction(() => {
      const customer = sqliteService.queryOne<any>('SELECT name, current_balance FROM customers WHERE id = ?', [
        customerId,
      ]);
      if (!customer) throw new Error('Customer not found.');

      const paymentId = 'cpay_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
      const nowIso = new Date().toISOString();

      // Insert customer payment record
      sqliteService.run(
        `INSERT INTO customer_payments (id, customer_id, amount, payment_method, reference_number, notes, received_by, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [paymentId, customerId, amount, method, referenceNumber.trim() || null, notes.trim() || null, receivedBy, nowIso]
      );

      // Reduce customer outstanding due balance
      const newBalance = Number((customer.current_balance - amount).toFixed(2));
      sqliteService.run('UPDATE customers SET current_balance = ? WHERE id = ?', [newBalance, customerId]);

      return {
        id: paymentId,
        customerId,
        customerName: customer.name,
        amount,
        paymentMethod: method,
        referenceNumber,
        notes,
        receivedBy,
        createdAt: nowIso,
      };
    });
  }

  public getCustomerPayments(customerId: string): CustomerPayment[] {
    const rows = sqliteService.query<any>(
      `SELECT cp.*, c.name as customer_name
       FROM customer_payments cp
       LEFT JOIN customers c ON cp.customer_id = c.id
       WHERE cp.customer_id = ?
       ORDER BY cp.created_at DESC`,
      [customerId]
    );
    return rows.map((r) => ({
      id: r.id,
      customerId: r.customer_id,
      customerName: r.customer_name,
      amount: r.amount,
      paymentMethod: r.payment_method,
      referenceNumber: r.reference_number,
      notes: r.notes,
      receivedBy: r.received_by,
      createdAt: r.created_at,
    }));
  }
}

export const customerService = new CustomerService();
