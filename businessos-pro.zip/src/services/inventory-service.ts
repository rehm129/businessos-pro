import { sqliteService } from '../db/sqlite-service';
import { Category, Product, StockMovement, StockMovementType } from '../types';

export interface CreateProductInput {
  name: string;
  sku: string;
  barcode: string;
  categoryId: string;
  unit?: string;
  purchaseCost: number;
  sellingPrice: number;
  initialStock?: number;
  minStockThreshold?: number;
}

export interface UpdateProductInput {
  name?: string;
  sku?: string;
  barcode?: string;
  categoryId?: string;
  unit?: string;
  purchaseCost?: number;
  sellingPrice?: number;
  minStockThreshold?: number;
  isArchived?: boolean;
}

class InventoryService {
  public getCategories(): Category[] {
    const rows = sqliteService.query<any>(`
      SELECT c.id, c.name, c.description, c.color,
             (SELECT count(*) FROM products p WHERE p.category_id = c.id AND p.is_archived = 0) as item_count
      FROM categories c
      ORDER BY c.name ASC
    `);
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      description: r.description,
      color: r.color,
      itemCount: r.item_count,
    }));
  }

  public createCategory(name: string, description: string = '', color: string = '#3b82f6'): Category {
    const cleanName = name.trim();
    if (!cleanName) throw new Error('Category name cannot be empty.');

    const existing = sqliteService.queryOne('SELECT id FROM categories WHERE name = ? COLLATE NOCASE', [cleanName]);
    if (existing) throw new Error(`Category "${cleanName}" already exists.`);

    const id = 'cat_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    sqliteService.run('INSERT INTO categories (id, name, description, color) VALUES (?, ?, ?, ?)', [
      id,
      cleanName,
      description.trim(),
      color,
    ]);

    return { id, name: cleanName, description, color, itemCount: 0 };
  }

  public updateCategory(id: string, name: string, description: string = '', color: string = '#3b82f6'): void {
    const cleanName = name.trim();
    if (!cleanName) throw new Error('Category name cannot be empty.');

    const existing = sqliteService.queryOne('SELECT id FROM categories WHERE name = ? COLLATE NOCASE AND id != ?', [
      cleanName,
      id,
    ]);
    if (existing) throw new Error(`Category "${cleanName}" already exists.`);

    sqliteService.run('UPDATE categories SET name = ?, description = ?, color = ? WHERE id = ?', [
      cleanName,
      description.trim(),
      color,
      id,
    ]);
  }

  public deleteCategory(id: string): void {
    const inUse = sqliteService.queryOne<{ c: number }>('SELECT count(*) as c FROM products WHERE category_id = ?', [id]);
    if (inUse && inUse.c > 0) {
      throw new Error(`Cannot delete category: ${inUse.c} product(s) are assigned to it. Reassign products first.`);
    }
    sqliteService.run('DELETE FROM categories WHERE id = ?', [id]);
  }

  public getProducts(options?: {
    search?: string;
    categoryId?: string;
    lowStockOnly?: boolean;
    includeArchived?: boolean;
  }): Product[] {
    let sql = `
      SELECT p.id, p.name, p.sku, p.barcode, p.category_id, p.unit, p.purchase_cost,
             p.selling_price, p.current_stock, p.min_stock_threshold, p.is_archived,
             p.created_at, p.updated_at, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE 1=1
    `;
    const params: any[] = [];

    if (!options?.includeArchived) {
      sql += ' AND p.is_archived = 0';
    }

    if (options?.categoryId && options.categoryId !== 'all') {
      sql += ' AND p.category_id = ?';
      params.push(options.categoryId);
    }

    if (options?.lowStockOnly) {
      sql += ' AND p.current_stock <= p.min_stock_threshold';
    }

    if (options?.search && options.search.trim()) {
      const q = `%${options.search.trim().toLowerCase()}%`;
      sql += ' AND (LOWER(p.name) LIKE ? OR LOWER(p.sku) LIKE ? OR LOWER(p.barcode) LIKE ?)';
      params.push(q, q, q);
    }

    sql += ' ORDER BY p.name ASC';

    const rows = sqliteService.query<any>(sql, params);
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      sku: r.sku,
      barcode: r.barcode,
      categoryId: r.category_id,
      categoryName: r.category_name || 'Uncategorized',
      unit: r.unit,
      purchaseCost: r.purchase_cost,
      sellingPrice: r.selling_price,
      currentStock: r.current_stock,
      minStockThreshold: r.min_stock_threshold,
      isArchived: Boolean(r.is_archived),
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    }));
  }

  public getProductById(id: string): Product | null {
    const r = sqliteService.queryOne<any>(
      `SELECT p.*, c.name as category_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.id = ?`,
      [id]
    );
    if (!r) return null;
    return {
      id: r.id,
      name: r.name,
      sku: r.sku,
      barcode: r.barcode,
      categoryId: r.category_id,
      categoryName: r.category_name,
      unit: r.unit,
      purchaseCost: r.purchase_cost,
      sellingPrice: r.selling_price,
      currentStock: r.current_stock,
      minStockThreshold: r.min_stock_threshold,
      isArchived: Boolean(r.is_archived),
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    };
  }

  public getProductByBarcodeOrSku(code: string): Product | null {
    const clean = code.trim();
    if (!clean) return null;
    const r = sqliteService.queryOne<any>(
      `SELECT p.*, c.name as category_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       WHERE (p.barcode = ? OR p.sku = ?) AND p.is_archived = 0
       LIMIT 1`,
      [clean, clean]
    );
    if (!r) return null;
    return {
      id: r.id,
      name: r.name,
      sku: r.sku,
      barcode: r.barcode,
      categoryId: r.category_id,
      categoryName: r.category_name,
      unit: r.unit,
      purchaseCost: r.purchase_cost,
      sellingPrice: r.selling_price,
      currentStock: r.current_stock,
      minStockThreshold: r.min_stock_threshold,
      isArchived: Boolean(r.is_archived),
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    };
  }

  public createProduct(input: CreateProductInput, createdByName: string): Product {
    const name = input.name.trim();
    const sku = input.sku.trim();
    const barcode = input.barcode.trim();

    if (!name) throw new Error('Product title/name is required.');
    if (!sku) throw new Error('SKU identifier is required.');
    if (!barcode) throw new Error('Barcode identifier is required.');
    if (input.sellingPrice < 0) throw new Error('Selling price cannot be negative.');
    if (input.purchaseCost < 0) throw new Error('Purchase cost cannot be negative.');

    // Duplicate check
    const existingSku = sqliteService.queryOne('SELECT id FROM products WHERE sku = ? COLLATE NOCASE', [sku]);
    if (existingSku) throw new Error(`Product with SKU "${sku}" already exists.`);

    const existingBarcode = sqliteService.queryOne('SELECT id FROM products WHERE barcode = ? COLLATE NOCASE', [barcode]);
    if (existingBarcode) throw new Error(`Product with Barcode "${barcode}" already exists.`);

    const id = 'prod_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const initialStock = input.initialStock ?? 0;
    const minThreshold = input.minStockThreshold ?? 5;
    const unit = input.unit?.trim() || 'pcs';
    const nowIso = new Date().toISOString();

    return sqliteService.transaction(() => {
      sqliteService.run(
        `INSERT INTO products (
          id, name, sku, barcode, category_id, unit, purchase_cost, selling_price,
          current_stock, min_stock_threshold, is_archived, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`,
        [
          id,
          name,
          sku,
          barcode,
          input.categoryId,
          unit,
          input.purchaseCost,
          input.sellingPrice,
          initialStock,
          minThreshold,
          nowIso,
          nowIso,
        ]
      );

      if (initialStock > 0) {
        sqliteService.run(
          `INSERT INTO stock_movements (
            id, product_id, movement_type, quantity_change, stock_after, unit_cost, reference_id, notes, created_by_name, created_at
          ) VALUES (?, ?, 'opening_stock', ?, ?, ?, 'INIT', 'Initial product creation opening balance', ?, ?)`,
          [
            'sm_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
            id,
            initialStock,
            initialStock,
            input.purchaseCost,
            createdByName,
            nowIso,
          ]
        );
      }

      return {
        id,
        name,
        sku,
        barcode,
        categoryId: input.categoryId,
        unit,
        purchaseCost: input.purchaseCost,
        sellingPrice: input.sellingPrice,
        currentStock: initialStock,
        minStockThreshold: minThreshold,
        isArchived: false,
        createdAt: nowIso,
        updatedAt: nowIso,
      };
    });
  }

  public updateProduct(id: string, input: UpdateProductInput): void {
    const existing = this.getProductById(id);
    if (!existing) throw new Error('Product not found.');

    if (input.sku && input.sku.trim() !== existing.sku) {
      const dup = sqliteService.queryOne('SELECT id FROM products WHERE sku = ? COLLATE NOCASE AND id != ?', [
        input.sku.trim(),
        id,
      ]);
      if (dup) throw new Error(`SKU "${input.sku}" is already assigned to another product.`);
    }

    if (input.barcode && input.barcode.trim() !== existing.barcode) {
      const dup = sqliteService.queryOne('SELECT id FROM products WHERE barcode = ? COLLATE NOCASE AND id != ?', [
        input.barcode.trim(),
        id,
      ]);
      if (dup) throw new Error(`Barcode "${input.barcode}" is already assigned to another product.`);
    }

    const name = input.name !== undefined ? input.name.trim() : existing.name;
    const sku = input.sku !== undefined ? input.sku.trim() : existing.sku;
    const barcode = input.barcode !== undefined ? input.barcode.trim() : existing.barcode;
    const categoryId = input.categoryId !== undefined ? input.categoryId : existing.categoryId;
    const unit = input.unit !== undefined ? input.unit.trim() : existing.unit;
    const purchaseCost = input.purchaseCost !== undefined ? input.purchaseCost : existing.purchaseCost;
    const sellingPrice = input.sellingPrice !== undefined ? input.sellingPrice : existing.sellingPrice;
    const minThreshold = input.minStockThreshold !== undefined ? input.minStockThreshold : existing.minStockThreshold;
    const isArchived = input.isArchived !== undefined ? (input.isArchived ? 1 : 0) : existing.isArchived ? 1 : 0;
    const nowIso = new Date().toISOString();

    sqliteService.run(
      `UPDATE products SET
        name = ?, sku = ?, barcode = ?, category_id = ?, unit = ?,
        purchase_cost = ?, selling_price = ?, min_stock_threshold = ?,
        is_archived = ?, updated_at = ?
       WHERE id = ?`,
      [name, sku, barcode, categoryId, unit, purchaseCost, sellingPrice, minThreshold, isArchived, nowIso, id]
    );
  }

  /**
   * Adjust stock level with mandatory audit log & reason
   */
  public adjustStock(
    productId: string,
    quantityDelta: number,
    type: StockMovementType,
    notes: string,
    createdByName: string
  ): void {
    if (quantityDelta === 0) return;

    sqliteService.transaction(() => {
      const p = sqliteService.queryOne<any>('SELECT current_stock, purchase_cost, name FROM products WHERE id = ?', [
        productId,
      ]);
      if (!p) throw new Error('Product not found for adjustment.');

      // Check negative stock policy
      const profile = sqliteService.queryOne<any>('SELECT allow_negative_stock FROM business_profile LIMIT 1');
      const allowNegative = Boolean(profile?.allow_negative_stock);
      const newStock = Number((p.current_stock + quantityDelta).toFixed(3));

      if (newStock < 0 && !allowNegative) {
        throw new Error(
          `Stock adjustment rejected: Available stock for "${p.name}" is ${p.current_stock}. Resulting stock would be negative (${newStock}), which is prohibited by business settings.`
        );
      }

      const nowIso = new Date().toISOString();

      // Update product current_stock
      sqliteService.run('UPDATE products SET current_stock = ?, updated_at = ? WHERE id = ?', [
        newStock,
        nowIso,
        productId,
      ]);

      // Record movement
      const movementId = 'sm_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
      sqliteService.run(
        `INSERT INTO stock_movements (
          id, product_id, movement_type, quantity_change, stock_after, unit_cost, reference_id, notes, created_by_name, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'ADJUST', ?, ?, ?)`,
        [movementId, productId, type, quantityDelta, newStock, p.purchase_cost, notes.trim(), createdByName, nowIso]
      );
    });
  }

  public getStockMovements(productId?: string, limit: number = 100): StockMovement[] {
    let sql = `
      SELECT sm.id, sm.product_id, sm.movement_type, sm.quantity_change, sm.stock_after,
             sm.unit_cost, sm.reference_id, sm.notes, sm.created_by_name, sm.created_at,
             p.name as product_name, p.sku as product_sku
      FROM stock_movements sm
      LEFT JOIN products p ON sm.product_id = p.id
    `;
    const params: any[] = [];

    if (productId) {
      sql += ' WHERE sm.product_id = ?';
      params.push(productId);
    }

    sql += ' ORDER BY sm.created_at DESC LIMIT ?';
    params.push(limit);

    const rows = sqliteService.query<any>(sql, params);
    return rows.map((r) => ({
      id: r.id,
      productId: r.product_id,
      productName: r.product_name || 'Deleted Product',
      productSku: r.product_sku || '',
      movementType: r.movement_type as StockMovementType,
      quantityChange: r.quantity_change,
      stockAfter: r.stock_after,
      unitCost: r.unit_cost,
      referenceId: r.reference_id,
      notes: r.notes,
      createdByName: r.created_by_name,
      createdAt: r.created_at,
    }));
  }
}

export const inventoryService = new InventoryService();
