/**
 * BusinessOS Pro - Cryptographic Security Utilities
 * PBKDF2-HMAC-SHA256 password hashing with salt (zero plaintext storage)
 * Machine ID generation for licensing architecture
 */

function bufToHex(buffer: ArrayBuffer | Uint8Array): string {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

function hexToBuf(hex: string): Uint8Array {
  const pairs = hex.match(/.{1,2}/g) || [];
  return new Uint8Array(pairs.map(byte => parseInt(byte, 16)));
}

/**
 * Generate random 16-byte cryptographic salt
 */
export function generateSalt(): string {
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);
  return bufToHex(salt);
}

/**
 * Hash password with PBKDF2 using SHA-256 and 100,000 iterations
 */
export async function hashPassword(password: string, saltHex: string): Promise<string> {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits', 'deriveKey']
  );

  const saltBuf = hexToBuf(saltHex);
  const derivedBits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: saltBuf as unknown as ArrayBuffer,
      iterations: 100000,
      hash: 'SHA-256',
    },
    keyMaterial,
    256
  );

  return bufToHex(derivedBits);
}

/**
 * Verify password against stored PBKDF2 hash and salt
 */
export async function verifyPassword(
  attempt: string,
  storedHash: string,
  storedSalt: string
): Promise<boolean> {
  const attemptHash = await hashPassword(attempt, storedSalt);
  return attemptHash === storedHash;
}

/**
 * Generate unique Hardware/Installation Machine Identifier
 */
export async function getOrGenerateMachineId(): Promise<string> {
  const key = 'businessos_machine_id';
  let stored = typeof window !== 'undefined' ? localStorage.getItem(key) : null;
  if (stored) return stored;

  const rawBytes = new Uint8Array(16);
  crypto.getRandomValues(rawBytes);
  const generated = 'BOS-' + bufToHex(rawBytes).toUpperCase().slice(0, 16).match(/.{4}/g)?.join('-')!;
  if (typeof window !== 'undefined') {
    localStorage.setItem(key, generated);
  }
  return generated;
}
